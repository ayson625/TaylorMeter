#include "cv_bridge.h"
#include "recognition.h"
#include "tm.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL %d: %s\n", __LINE__, #x);                                        \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)

static int run(const uint8_t *g, int w, int h, int stride, double length, int count,
               const double *seams, const char *name) {
    TM_State *s = calloc(1, sizeof(*s));
    CHECK(s);
    s->channel = (TM_Channel){{0, 0}, {length, 0}, (h - 1) * .5, 1};
    s->sensitivity = 50;
    s->min_length_px = 3;
    TM_RecognitionReport report;
    int n = tm_detect_checked(g, w, h, stride, s, &report);
    printf("Close caps %s: %d/%d; repeatability %d..%d\n", name, n, count, report.min_count,
           report.max_count);
    CHECK(n == count);
    for (int i = 0; i < n; i++) {
        CHECK(s->bubbles[i].left < s->bubbles[i].right);
        if (i + 1 < n) {
            CHECK(s->bubbles[i].right <= s->bubbles[i + 1].left);
            CHECK(fabs(s->bubbles[i].right - seams[i]) <= 5);
            CHECK(fabs(s->bubbles[i + 1].left - seams[i]) <= 5);
            CHECK(s->bubbles[i].flags & TM_UNCERTAIN);
        }
    }
    free(s);
    return 0;
}
int main(int argc, char **argv) {
    CHECK(argc == 2);
    const char *files[] = {"three.png", "two.png", "four.png"};
    const int counts[] = {3, 2, 4};
    const double seams[3][3] = {{75, 135, 0}, {48, 0, 0}, {55, 99, 153}};
    for (int c = 0; c < 3; c++) {
        char path[4096];
        snprintf(path, sizeof(path), "%s/%s", argv[1], files[c]);
        int w, h, st;
        void *image = cvb_load(path, &w, &h);
        CHECK(image);
        const uint8_t *g = cvb_gray(image, &w, &h, &st);
        CHECK(g);
        CHECK(!run(g, w, h, st, w - 1, counts[c], seams[c], files[c]));
        uint8_t *p = malloc((size_t)w * h);
        CHECK(p);
        unsigned rng = 34;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                rng = rng * 1664525u + 1013904223u;
                p[y * w + x] = (uint8_t)fmax(
                    0, fmin(255, g[y * st + x] * .85 + 7 + (int)((rng >> 16) % 5) - 2));
            }
        CHECK(!run(p, w, h, w, w - 1, counts[c], seams[c], "illumination + noise"));
        free(p);
        for (int k = 0; k < 2; k++) {
            double scale = k ? 1.5 : .75;
            int nw = (int)lround(w * scale), nh = (int)lround(h * scale), ns;
            void *resized = cvb_resize(image, nw, nh);
            CHECK(resized);
            const uint8_t *pixels = cvb_gray(resized, &nw, &nh, &ns);
            CHECK(pixels);
            CHECK(!run(pixels, nw, nh, ns, w - 1, counts[c], seams[c], k ? "150%" : "75%"));
            cvb_free(resized);
        }
        cvb_free(image);
    }
    /* A single reflective capsule with a straight scratch must not turn into
       a chain. This image is defined geometrically, not from detector peaks. */
    enum { W = 360, H = 85 };
    uint8_t *g = malloc(W * H);
    TM_State *s = calloc(1, sizeof(*s));
    CHECK(g && s);
    for (int scratch = 0; scratch < 3; scratch++) {
        memset(g, 115, W * H);
        for (int y = 5; y < 80; y++) {
            double t = (y - 42) / 37.0, d = 20 * (1 - sqrt(fmax(0, 1 - t * t)));
            for (int x = 0; x < W; x++) {
                double edge = fmin(x - (25 + d), 330 - d - x);
                if (edge >= 0)
                    g[y * W + x] = 145;
                if (fabs(edge) < 1.6)
                    g[y * W + x] = 220;
                if (edge >= 0 && (y < 10 || y > 75))
                    g[y * W + x] = 230;
            }
        }
        if (scratch)
            for (int y = 0; y < H; y++)
                for (int dx = -1; dx <= 1; dx++)
                    g[y * W + 180 + dx] = scratch == 1 ? 245 : 40;
        memset(s, 0, sizeof(*s));
        s->channel = (TM_Channel){{0, 42}, {W - 1, 42}, 42, 1};
        s->sensitivity = 50;
        s->min_length_px = 3;
        int n = tm_detect(g, W, H, W, s);
        printf("Single capsule / straight scratch %d: %d\n", scratch, n);
        CHECK(n >= 0 && n <= 1);
    }
    free(g);
    free(s);
    puts("Close menisci, no invented gap, negative controls: PASS");
    return 0;
}
