#!/usr/bin/env python3
"""Compare the public CLI with independently marked visible image endpoints.

Only the Python standard library is needed. The PNGs and truth.json must be
beside this script in fixtures/. No generated prediction is used as the truth.
Exit status is 0 only if every marked bubble has one distinct prediction,
both endpoints are within the tolerance, and there are no extra predictions.
"""
import argparse
import csv
import io
import json
import math
from pathlib import Path
import re
import subprocess
import sys


def match_endpoints(truth, predictions, tolerance):
    """Maximum-cardinality bipartite matching, with nearest candidates first."""
    edges = []
    for expected in truth:
        possible = []
        for j, actual in enumerate(predictions):
            errors = [abs(a - b) for a, b in zip(expected, actual)]
            if max(errors) <= tolerance:
                possible.append((sum(errors), j))
        edges.append([j for _, j in sorted(possible)])
    owner = {}

    def augment(i, seen):
        for j in edges[i]:
            if j in seen:
                continue
            seen.add(j)
            if j not in owner or augment(owner[j], seen):
                owner[j] = i
                return True
        return False

    for i in range(len(truth)):
        augment(i, set())
    return sorted((i, j) for j, i in owner.items())


def evaluate(executable, folder, case, tolerance):
    x, y, width, height = case['crop_source_xywh']
    command = [str(executable), '--headless', str(folder / case['image']),
               '--rect', f'0,0,{width},{height}', '--px-per-mm', '1']
    run = subprocess.run(command, capture_output=True, text=True, timeout=120)
    if run.returncode:
        raise RuntimeError(f"{case['name']}: CLI exited {run.returncode}\n{run.stdout}\n{run.stderr}")
    channel = re.search(r'Channel: ([\d.+-]+),([\d.+-]+) to ([\d.+-]+),([\d.+-]+);',
                        run.stdout)
    if not channel:
        raise RuntimeError(f"{case['name']}: missing channel geometry\n{run.stdout}")
    ax, ay, bx, by = map(float, channel.groups())
    length = math.hypot(bx - ax, by - ay)
    if length <= 0:
        raise RuntimeError('Invalid channel axis')
    dx = (bx - ax) / length
    header = 'index,left_px,right_px,bubble_mm,slug_after_mm,confidence'
    if header not in run.stdout:
        raise RuntimeError(f"{case['name']}: missing result CSV\n{run.stdout}")
    rows = list(csv.DictReader(io.StringIO(header + run.stdout.split(header, 1)[1])))
    predictions = [[x + ax + float(row['left_px']) * dx,
                    x + ax + float(row['right_px']) * dx] for row in rows]
    if not all(math.isfinite(v) for pair in predictions for v in pair):
        raise RuntimeError('Non-finite detection coordinates')
    truth = case['expected_endpoints_source_x']
    matched = match_endpoints(truth, predictions, tolerance)
    errors = [abs(truth[i][k] - predictions[j][k])
              for i, j in matched for k in (0, 1)]
    used_truth = {i for i, _ in matched}
    used_prediction = {j for _, j in matched}
    slug_rows = sum(bool(row['slug_after_mm']) for row in rows)
    all_slugs = slug_rows == max(0, len(rows) - 1)
    okay = len(matched) == len(truth) == len(predictions) and all_slugs
    return {
        'name': case['name'], 'pass': okay, 'expected': len(truth),
        'detected': len(predictions), 'matched': len(matched),
        'missing_or_bad_endpoints': [i + 1 for i in range(len(truth)) if i not in used_truth],
        'extra_or_bad_endpoints': [j + 1 for j in range(len(predictions)) if j not in used_prediction],
        'mean_matched_endpoint_error_px': sum(errors) / len(errors) if errors else None,
        'max_matched_endpoint_error_px': max(errors) if errors else None,
        'prediction_endpoints_source_x': predictions,
        'matched_pairs_1based': [[i + 1, j + 1] for i, j in matched],
        'slug_rows': slug_rows, 'all_n_minus_one_slugs': all_slugs,
        'stdout': run.stdout,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('executable', type=Path)
    parser.add_argument('--dataset', type=Path, default=Path(__file__).resolve().parent / 'fixtures')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    truth = json.loads((args.dataset / 'truth.json').read_text(encoding='utf-8'))
    results = [evaluate(args.executable.resolve(), args.dataset.resolve(), case, truth['tolerance_px'])
               for case in truth['cases']]
    report = {'tolerance_px': truth['tolerance_px'], 'annotation': truth['annotation'],
              'all_pass': all(result['pass'] for result in results), 'cases': results}
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for result in results:
        average = result['mean_matched_endpoint_error_px']
        text_error = f'{average:.2f} px' if average is not None else 'n/a'
        print(f"{result['name']}: expected {result['expected']}, detected {result['detected']}, "
              f"matched {result['matched']}, endpoint MAE {text_error}: "
              f"{'PASS' if result['pass'] else 'FAIL'}")
    return 0 if report['all_pass'] else 1


if __name__ == '__main__':
    sys.exit(main())
