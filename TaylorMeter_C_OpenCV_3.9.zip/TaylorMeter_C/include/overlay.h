#ifndef TM_OVERLAY_H
#define TM_OVERLAY_H
#include "tm.h"

#define TM_DROP_COLOR 0xff4747
#define TM_SLUG_COLOR 0x429bff
enum { TM_HOVER_NONE, TM_HOVER_BUBBLE, TM_HOVER_SLUG };
typedef struct {
    int kind, index;
} TM_Hover;
typedef struct {
    TM_Point origin, axis, normal;
    double along_scale, half_width, zoom, panx, pany;
} TM_Overlay;

/* strip_width == 0: original photograph; otherwise the 80..220 channel strip.
   The same geometry drives exported dimensions and screen hit testing. */
void tm_overlay_init(TM_Overlay *layout, const TM_Channel *channel, int strip_width);
void tm_overlay_draw(void *image, const TM_State *state, const TM_Overlay *layout, int labels);
TM_Hover tm_overlay_hit(const TM_State *state, const TM_Overlay *layout, double x, double y,
                        double tolerance);
void tm_overlay_highlight(void *image, const TM_State *state, const TM_Overlay *layout,
                          TM_Hover hit);
void tm_overlay_value(const TM_State *state, TM_Hover hit, char *text, size_t capacity);
#endif
