#include "tm.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static double dot(TM_Point p, TM_Point q) { return p.x * q.x + p.y * q.y; }
static uint8_t sample(const uint8_t *g, int w, int h, int stride, double x, double y) {
    int xx = (int)lround(x), yy = (int)lround(y);
    if (xx < 0)
        xx = 0;
    if (yy < 0)
        yy = 0;
    if (xx >= w)
        xx = w - 1;
    if (yy >= h)
        yy = h - 1;
    return g[yy * stride + xx];
}
TM_Rect tm_channel_bounds(const TM_Channel *c, int w, int h) {
    double len = tm_channel_length(c), xmin = w, xmax = 0, ymin = h, ymax = 0;
    if (!c->valid || len <= 0)
        return (TM_Rect){0};
    for (int end = 0; end < 2; end++)
        for (int side = -1; side <= 1; side += 2) {
            TM_Point p = tm_channel_point(c, end ? len : 0, side * c->half_width);
            xmin = fmin(xmin, p.x);
            xmax = fmax(xmax, p.x);
            ymin = fmin(ymin, p.y);
            ymax = fmax(ymax, p.y);
        }
    int x0 = (int)fmax(0, floor(xmin)), y0 = (int)fmax(0, floor(ymin));
    int x1 = (int)fmin(w, ceil(xmax) + 1), y1 = (int)fmin(h, ceil(ymax) + 1);
    return (TM_Rect){x0, y0, x1 - x0, y1 - y0, x1 > x0 && y1 > y0, 0};
}
static double peak_position(const uint8_t *g, int w, int h, int row, double x, double radius,
                            double *strength) {
    (void)h;
    int a = (int)fmax(1, floor(x - radius)), b = (int)fmin(w - 2, ceil(x + radius));
    double best = 0, pos = x;
    for (int k = a; k <= b; k++) {
        double gradient = fabs((double)g[row * w + k + 1] - g[row * w + k - 1]);
        if (gradient > best) {
            best = gradient;
            pos = k;
        }
    }
    *strength = best;
    return pos;
}
static int curved_cap(const uint8_t *g, int w, int h, double x, int side) {
    double a, b, c, radius = fmax(2, h * .35);
    double mid = peak_position(g, w, h, h / 2, x, radius, &a);
    double top = peak_position(g, w, h, (int)(h * .22), x, radius, &b);
    double low = peak_position(g, w, h, (int)(h * .78), x, radius, &c);
    double sign = side ? -1 : 1;
    return a > 7 && b > 7 && c > 7 && sign * ((top + low) * .5 - mid) >= .5 &&
           fabs(top - low) <= fmax(3, h * .25);
}
static double wall_support(const uint8_t *g, int w, int h, int stride, TM_Point u, TM_Point v,
                           double normal, double lo, double hi, double radius) {
    int supported = 0;
    for (int i = 0; i < 128; i++) {
        double along = lo + (hi - lo) * (i + .5) / 128, gradient = 0;
        for (double d = -radius; d <= radius; d += 1) {
            double x = u.x * along + v.x * (normal + d);
            double y = u.y * along + v.y * (normal + d);
            gradient =
                fmax(gradient, fabs((double)sample(g, w, h, stride, x + v.x * 2, y + v.y * 2) -
                                    sample(g, w, h, stride, x - v.x * 2, y - v.y * 2)));
        }
        supported += gradient > 12;
    }
    return supported / 128.0;
}
static int trim_bounds(TM_Point u, TM_Point v, double center, double hw, TM_Rect r, double *lo,
                       double *hi) {
    const double d[2] = {u.x, u.y}, origin[2] = {v.x * center, v.y * center};
    const double a[2] = {r.x + fabs(v.x) * hw, r.y + fabs(v.y) * hw};
    const double b[2] = {r.x + r.w - 1 - fabs(v.x) * hw, r.y + r.h - 1 - fabs(v.y) * hw};
    for (int k = 0; k < 2; k++) {
        if (fabs(d[k]) < 1e-9) {
            if (origin[k] < a[k] || origin[k] > b[k])
                return 0;
        } else {
            double t0 = (a[k] - origin[k]) / d[k], t1 = (b[k] - origin[k]) / d[k];
            *lo = fmax(*lo, fmin(t0, t1));
            *hi = fmin(*hi, fmax(t0, t1));
        }
    }
    return *hi - *lo >= 20;
}
int tm_find_channel(const uint8_t *g, int w, int h, int stride, const TM_Segment *lines, int count,
                    const TM_Rect *constraint, TM_Channel *out, TM_Rect *region) {
    if (!g || w < 30 || h < 10 || stride < w || count < 2)
        return 0;
    TM_Rect bounds = constraint ? *constraint : (TM_Rect){0, 0, w, h, 1, 1};
    double reference = 0;
    int histogram[256] = {0}, total = 0;
    for (int y = 0; y < h; y += 8)
        for (int x = 0; x < w; x += 8) {
            histogram[g[y * stride + x]]++;
            total++;
        }
    int accumulated = 0;
    for (int i = 0; i < 256; i++) {
        accumulated += histogram[i];
        if (accumulated >= total / 2) {
            reference = i;
            break;
        }
    }
    double minimum_mean = fmin(145, fmax(45, reference * .7)), best_score = -1;
    TM_State *s = (TM_State *)calloc(1, sizeof(TM_State));
    uint8_t *strip = (uint8_t *)malloc(1201 * 81);
    struct {
        TM_Point u, mid;
        double hw;
    } tested[160];
    int tested_count = 0;
    if (!s || !strip) {
        free(s);
        free(strip);
        return 0;
    }
    for (int i = 0; i < count && tested_count < 160; i++) {
        TM_Point p = {lines[i].b.x - lines[i].a.x, lines[i].b.y - lines[i].a.y};
        double plen = hypot(p.x, p.y);
        if (plen < 20)
            continue;
        p.x /= plen;
        p.y /= plen;
        for (int j = i + 1; j < count && tested_count < 160; j++) {
            TM_Point q = {lines[j].b.x - lines[j].a.x, lines[j].b.y - lines[j].a.y};
            double qlen = hypot(q.x, q.y);
            if (qlen < 20)
                continue;
            q.x /= qlen;
            q.y /= qlen;
            if (dot(p, q) < 0) {
                q.x = -q.x;
                q.y = -q.y;
            }
            if (dot(p, q) < .999)
                continue;
            TM_Point u = {p.x + q.x, p.y + q.y};
            double norm = hypot(u.x, u.y);
            u.x /= norm;
            u.y /= norm;
            if ((fabs(u.x) >= fabs(u.y) && u.x < 0) || (fabs(u.y) > fabs(u.x) && u.y < 0)) {
                u.x = -u.x;
                u.y = -u.y;
            }
            TM_Point v = {-u.y, u.x};
            double a0 = dot(lines[i].a, u), a1 = dot(lines[i].b, u), b0 = dot(lines[j].a, u),
                   b1 = dot(lines[j].b, u);
            double amin = fmin(a0, a1), amax = fmax(a0, a1), bmin = fmin(b0, b1),
                   bmax = fmax(b0, b1);
            double overlap = fmin(amax, bmax) - fmax(amin, bmin);
            double extent = fabs(u.x) >= fabs(u.y) ? bounds.w : bounds.h;
            if (overlap < extent * .28)
                continue;
            double c1 = (dot(lines[i].a, v) + dot(lines[i].b, v)) * .5;
            double c2 = (dot(lines[j].a, v) + dot(lines[j].b, v)) * .5;
            double hw = fabs(c1 - c2) * .5, center = (c1 + c2) * .5;
            double thick_limit = constraint ? fmax(bounds.w, bounds.h) * .2 : fmin(w, h) * .14;
            if (hw < 2 || (!constraint && 2 * hw < fmax(6, extent * .006)) ||
                2 * hw > thick_limit || overlap < hw * 12)
                continue;
            if (fabs(p.x * q.y - p.y * q.x) * overlap > hw * 1.1)
                continue;
            double lo = fmin(amin, bmin), hi = fmax(amax, bmax);
            if (constraint) {
                lo = -1e9;
                hi = 1e9;
            }
            if (!trim_bounds(u, v, center, hw, bounds, &lo, &hi))
                continue;
            double radius = fmin(hw * .45, fmax(2, extent / 1000 * 2.5));
            double top_support = wall_support(g, w, h, stride, u, v, center - hw, lo, hi, radius);
            double lower_support = wall_support(g, w, h, stride, u, v, center + hw, lo, hi, radius);
            /* Numbers and short ruler strokes do not form two continuous walls. */
            if (!constraint && fmin(top_support, lower_support) < .42)
                continue;
            TM_Point midpoint = {u.x * (lo + hi) * .5 + v.x * center,
                                 u.y * (lo + hi) * .5 + v.y * center};
            int duplicate = 0;
            for (int k = 0; k < tested_count; k++) {
                TM_Point d = {midpoint.x - tested[k].mid.x, midpoint.y - tested[k].mid.y};
                if (dot(u, tested[k].u) > .9999 && fabs(dot(d, v)) < fmax(2, hw * .1) &&
                    fabs(hw - tested[k].hw) < fmax(2, hw * .15)) {
                    duplicate = 1;
                    break;
                }
            }
            if (duplicate)
                continue;
            tested[tested_count].u = u;
            tested[tested_count].mid = midpoint;
            tested[tested_count++].hw = hw;
            double length = hi - lo, factor = fmin(1, 1200 / length);
            int sw = (int)lround(length * factor) + 1,
                sh = (int)fmin(80, fmax(5, lround(2 * hw * factor) + 1));
            double mean = 0;
            for (int y = 0; y < sh; y++)
                for (int x = 0; x < sw; x++) {
                    double along = lo + length * x / (sw - 1),
                           across = center + 2 * hw * (y / (double)(sh - 1) - .5);
                    uint8_t value = sample(g, w, h, stride, u.x * along + v.x * across,
                                           u.y * along + v.y * across);
                    strip[y * sw + x] = value;
                    if (y >= sh / 3 && y <= 2 * sh / 3)
                        mean += value;
                }
            mean /= sw * (2 * sh / 3 - sh / 3 + 1);
            if (mean < minimum_mean && !constraint)
                continue;
            int left = 0, right = sw - 1;
            if (!constraint) {
                /* Long opaque straps split the observation; choose one visible run. */
                int begin = 0, dark = -1, best_len = 0;
                for (int x = 0; x <= sw; x++) {
                    double value = 0;
                    if (x < sw) {
                        for (int y = sh / 3; y <= 2 * sh / 3; y++)
                            value += strip[y * sw + x];
                        value /= 2 * sh / 3 - sh / 3 + 1;
                    }
                    if (x < sw && value < mean * .78) {
                        if (dark < 0)
                            dark = x;
                    } else if (dark >= 0) {
                        if (x - dark > fmax(10, sh * 2.5)) {
                            if (dark - begin > best_len) {
                                best_len = dark - begin;
                                left = begin;
                                right = dark - 1;
                            }
                            begin = x;
                        }
                        dark = -1;
                    }
                    if (x == sw && sw - begin > best_len) {
                        left = begin;
                        right = sw - 1;
                    }
                }
            }
            int cw = right - left + 1;
            if (cw < sw * .35)
                continue;
            if (left || cw != sw)
                for (int y = 0; y < sh; y++)
                    memmove(strip + y * cw, strip + y * sw + left, (size_t)cw);
            memset(s, 0, sizeof(*s));
            s->channel =
                (TM_Channel){{0, (sh - 1) * .5}, {cw - 1, (sh - 1) * .5}, (sh - 1) * .5, 1};
            s->sensitivity = 50;
            s->min_length_px = 3;
            /* A dense regular sequence of short strokes is the ruler, not a
               train of elongated bubbles. */
            if (!constraint && sh >= 8 && tm_find_ruler(strip, cw, sh, cw, 0, &s->calibration) &&
                1 / s->calibration.mm_per_px < sh * 1.4)
                continue;
            int n = tm_detect(strip, cw, sh, cw, s), curves = 0, strong = 0, elongated = 0;
            double confidence = 0;
            if (n < (constraint ? 1 : 2))
                continue;
            for (int k = 0; k < n; k++) {
                confidence += s->bubbles[k].confidence;
                strong += s->bubbles[k].confidence >= .75;
                elongated += s->bubbles[k].right - s->bubbles[k].left >= sh * 1.1;
                curves += curved_cap(strip, cw, sh, s->bubbles[k].left, 0);
                curves += curved_cap(strip, cw, sh, s->bubbles[k].right, 1);
            }
            double fraction = curves / (2.0 * n);
            confidence /= n;
            if (!constraint && (curves < 2 || fraction < .15 || strong < 2 || confidence < .7 ||
                                elongated * 2 < n))
                continue;
            double score = curves + fraction * 8 + 4 * length / extent + mean / 60 +
                           5 * fmin(top_support, lower_support) + confidence * 8;
            if (score <= best_score)
                continue;
            best_score = score;
            double t0 = lo + length * left / (sw - 1), t1 = lo + length * right / (sw - 1);
            out->a = (TM_Point){u.x * t0 + v.x * center, u.y * t0 + v.y * center};
            out->b = (TM_Point){u.x * t1 + v.x * center, u.y * t1 + v.y * center};
            out->half_width = hw;
            out->valid = 1;
            *region = constraint ? *constraint : tm_channel_bounds(out, w, h);
            region->valid = 1;
            region->automatic = !constraint;
        }
    }
    free(s);
    free(strip);
    return best_score >= 0;
}
