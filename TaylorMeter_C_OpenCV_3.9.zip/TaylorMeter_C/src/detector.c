/* All inference is C11. OpenCV supplies decoded, straightened image pixels.
   A bubble needs two independently observed curved menisci. There is no
   synthetic splitting by expected spacing and no clustering of neighbours. */
#include "tm.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>

static int cmp_double(const void *a, const void *b) {
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}
static double quantile(const double *p, int n, double q) {
    double *v = (double *)malloc((size_t)n * sizeof(double)), r = 0;
    if (!v || n < 1) {
        free(v);
        return 0;
    }
    memcpy(v, p, (size_t)n * sizeof(double));
    qsort(v, (size_t)n, sizeof(double), cmp_double);
    r = v[(int)((n - 1) * q)];
    free(v);
    return r;
}
static void smooth(double *p, int n, double sigma) {
    int radius = (int)ceil(sigma * 2.5);
    double *v = (double *)malloc((size_t)n * sizeof(double));
    if (!v)
        return;
    for (int x = 0; x < n; x++) {
        double a = 0, b = 0;
        for (int j = -radius; j <= radius; j++) {
            int k = x + j;
            if (k < 0)
                k = 0;
            if (k >= n)
                k = n - 1;
            double w = exp(-(j * j) / (2 * sigma * sigma));
            a += p[k] * w;
            b += w;
        }
        v[x] = a / b;
    }
    memcpy(p, v, (size_t)n * sizeof(double));
    free(v);
}
typedef struct {
    double x, strength, bend;
    int kind;
} Edge;
static int peak(const double *p, int x, int n) {
    return x > 0 && x < n - 1 && p[x] >= p[x - 1] && p[x] > p[x + 1];
}

static int histogram_q(const int *hist, int count, double fraction) {
    int target = (int)(count * fraction), sum = 0;
    for (int i = 0; i < 256; i++) {
        sum += hist[i];
        if (sum > target)
            return i;
    }
    return 255;
}
static double cap_near(const double *profile, int width, double position, int height, int side,
                       double *support) {
    int a = (int)floor(position - (side ? height * .12 : height * .22));
    int b = (int)ceil(position + (side ? height * .22 : height * .12));
    if (a < 2)
        a = 2;
    if (b > width - 3)
        b = width - 3;
    int best = -1;
    double score = 0;
    for (int x = a; x <= b; x++)
        if (peak(profile, x, width) && profile[x] > score) {
            score = profile[x];
            best = x;
        }
    /* Weak RAW menisci can have less than three gray levels of response.
       Compare the coherent curved peak with its local noise floor instead of
       dropping it by a fixed brightness threshold. */
    double noise = b >= a ? quantile(profile + a, b - a + 1, .50) : 0;
    *support = 0;
    if (best < 0 || score < fmax(.8, noise * 1.8))
        return position;
    *support = fmin(1, score / 5);
    double den = profile[best - 1] - 2 * profile[best] + profile[best + 1];
    double sub = fabs(den) > 1e-9 ? 0.5 * (profile[best - 1] - profile[best + 1]) / den : 0;
    return best + fmax(-.5, fmin(.5, sub));
}
/* On reflective microchannels the dark upper rim is more stable than the
   almost transparent middle. Local contrast adapts to illumination, while
   observed cap profiles refine each endpoint. No horizontal closing is used:
   even a one-pixel liquid segment separates two bubbles. */
static int rim_segments(const uint8_t *g, int w, int h, int stride, const double *left,
                        const double *right, TM_State *s) {
    double *signal = (double *)calloc((size_t)w * 2, sizeof(double));
    uint8_t *levels = (uint8_t *)malloc((size_t)w);
    if (!signal || !levels) {
        free(signal);
        free(levels);
        return 0;
    }
    double *threshold = signal + w;
    int top0 = (int)(h * .03), top1 = (int)(h * .23), mid0 = (int)(h * .35), mid1 = (int)(h * .65);
    if (top1 <= top0 || mid1 <= mid0) {
        free(signal);
        free(levels);
        return 0;
    }
    for (int x = 0; x < w; x++) {
        double top = 0, mid = 0;
        for (int y = top0; y <= top1; y++)
            top += g[y * stride + x];
        for (int y = mid0; y <= mid1; y++)
            mid += g[y * stride + x];
        signal[x] = mid / (mid1 - mid0 + 1) - top / (top1 - top0 + 1);
    }
    smooth(signal, w, .65);
    for (int x = 0; x < w; x++)
        levels[x] = (uint8_t)fmax(0, fmin(255, lround(signal[x] + 128)));
    int radius = h * 5;
    if (radius < 60)
        radius = 60;
    int hist[256] = {0}, a = 0, b = 0;
    for (int x = 0; x < w; x++) {
        int newa = x - radius;
        if (newa < 0)
            newa = 0;
        int newb = x + radius;
        if (newb >= w)
            newb = w - 1;
        while (b <= newb)
            hist[levels[b++]]++;
        while (a < newa)
            hist[levels[a++]]--;
        double lo = histogram_q(hist, b - a, .15) - 128, hi = histogram_q(hist, b - a, .85) - 128;
        threshold[x] = hi - lo >= 6 ? lo + (hi - lo) * (.56 - .003 * s->sensitivity) : INFINITY;
    }
    double factor = tm_channel_length(&s->channel) / (w - 1),
           minw = fmax(h * .28, s->min_length_px / factor);
    int start = -1;
    s->count = 0;
    for (int x = 0; x <= w; x++) {
        int active = x < w && signal[x] > threshold[x];
        if (active && start < 0)
            start = x;
        if (!active && start >= 0) {
            int end = x;
            if (start > 1 && end < w - 2 && end - start >= minw) {
                double ls, rs;
                double l = cap_near(left, w, start, h, 0, &ls),
                       r = cap_near(right, w, end - 1, h, 1, &rs);
                /* Refinement must not consume a neighbouring observed liquid gap. */
                if (s->count && l < s->bubbles[s->count - 1].right / factor)
                    l = start;
                if (r >= end + h * .45)
                    r = end - 1;
                if (l < r && r - l >= minw) {
                    double confidence = fmin(
                        1, (signal[(start + end) / 2] - threshold[(start + end) / 2]) / 20 + .55);
                    confidence = fmin(confidence, .5 + .5 * fmin(ls, rs));
                    tm_add_bubble(s, l * factor, r * factor, confidence < .75 ? TM_UNCERTAIN : 0,
                                  confidence);
                }
            }
            start = -1;
        }
    }
    int count = s->count;
    free(signal);
    free(levels);
    return count;
}

static double subpixel_peak(const double *p, int x, int w) {
    if (x < 1 || x >= w - 1)
        return x;
    double den = p[x - 1] - 2 * p[x] + p[x + 1];
    double d = fabs(den) > 1e-9 ? .5 * (p[x - 1] - p[x + 1]) / den : 0;
    return x + fmax(-.5, fmin(.5, d));
}

/* Compare curvature after removing the column-wise straight-edge response.
   A drawn vertical line or a scratch must not vote for the phase of a cap.
   Fit both orientations in a small neighbourhood so subpixel sampling cannot
   flip the decision by selecting a different peak of the same contour. */
static double cap_polarity(const uint8_t *g, int w, int h, int stride, int node,
                            const double *straight) {
    double scores[2] = {0, 0};
    int y0 = (int)(h * .17), y1 = (int)(h * .83), center = h / 2;
    int step = (int)lround(h / 45.0);
    if (step < 1) step = 1;
    if (step > 8) step = 8;
    const double vertical[] = {.375, .50, .62}, horizontal[] = {.12, .25, .375, .50};
    for (int side = 0; side < 2; side++)
        for (int v = 0; v < 3; v++)
            for (int k = 0; k < 4; k++)
                for (double x = node - h * .06; x <= node + h * .06; x += .5) {
                    double sum = 0, weight = 0;
                    double radius = fmax(2, (h - 1) * vertical[v]);
                    for (int y = y0; y <= y1; y++) {
                        double t = (y - center) / radius;
                        if (fabs(t) > .95)
                            continue;
                        double d = (h - 1) * horizontal[k] * (1 - sqrt(fmax(0, 1 - t * t)));
                        int xx = (int)lround(x + (side ? -d : d));
                        if (xx < step || xx >= w - step)
                            continue;
                        double gradient = fabs((double)g[y * stride + xx + step] -
                                               g[y * stride + xx - step]);
                        double wt = .25 + fabs(t);
                        sum += fmax(0, gradient - straight[xx]) * wt;
                        weight += wt;
                    }
                    if (weight)
                        scores[side] = fmax(scores[side], sum / weight);
                }
    return (scores[0] - scores[1]) / (fmax(scores[0], scores[1]) + 1e-9);
}

/* Two almost touching menisci can produce one derivative peak. In that case
   choosing only the stronger orientation loses a bubble. Keep both sides of
   such a junction, but require a curved reflective roof on EACH adjacent
   bubble. A vertical overlay/scratch or a flat highlight alone is not a roof.
   This is a local addition: unconnected intervals from the existing detector
   are kept, and no spacing, bubble count or physical gap is assumed. */
static void separate_reflective_caps(const uint8_t *g, int w, int h, int stride, const double *left,
                                     const double *right, TM_State *s) {
    if (h < 12 || w < 24)
        return;
    double *v = (double *)calloc((size_t)w * 6, sizeof(double));
    int *nodes = (int *)malloc((size_t)w * sizeof(int));
    uint8_t *arcs = (uint8_t *)calloc((size_t)w * 2, 1);
    uint8_t *liquid = arcs ? arcs + w : NULL;
    TM_State *trial = (TM_State *)malloc(sizeof(*trial));
    if (!v || !nodes || !arcs || !trial) {
        free(v);
        free(nodes);
        free(arcs);
        free(trial);
        return;
    }
    double *best = v, *roof = v + w, *contrast = v + 2 * w;
    double *leading = v + 3 * w, *trailing = v + 4 * w, *straight = v + 5 * w;
    int limit = (int)(h * .32), mid0 = (int)(h * .35), mid1 = (int)(h * .65);
    for (int x = 0; x < w; x++) {
        best[x] = fmax(left[x], right[x]);
        double strongest = 0, top = 0, middle = 0;
        for (int y = 1; y <= limit && y + 2 < h; y++) {
            int ym2 = y > 1 ? y - 2 : 0;
            double d = .25 * g[ym2 * stride + x] + .5 * g[(y - 1) * stride + x] -
                       .5 * g[(y + 1) * stride + x] - .25 * g[(y + 2) * stride + x];
            if (d > strongest) {
                strongest = d;
                roof[x] = y;
            }
            top = fmax(top, g[y * stride + x]);
        }
        for (int y = mid0; y <= mid1; y++)
            middle += g[y * stride + x];
        contrast[x] = strongest >= 4 ? top - middle / (mid1 - mid0 + 1) : 0;
    }
    smooth(roof, w, .8);
    double threshold = fmax(1.6, fmax(quantile(best, w, .5) * 3, quantile(best, w, .9) * .2));
    double spacing = fmax(2, h * .15);
    double roof_contrast = fmax(12, quantile(contrast, w, .85) * .5);
    int n = 0;
    for (int x = 2; x < w - 2; x++) {
        if (!peak(best, x, w) || best[x] < threshold)
            continue;
        /* This clusters a junction for roof validation, NOT its two bounds.
           Leading/trailing positions are refined independently below. */
        if (n && x - nodes[n - 1] < spacing) {
            if (best[x] > best[nodes[n - 1]])
                nodes[n - 1] = x;
        } else
            nodes[n++] = x;
    }
    /* A weak shoulder immediately beside a strong cap is not an extra cap.
       Keep isolated weak junctions: they can separate nearly touching drops. */
    for (int i = 1; i + 1 < n;) {
        if (best[nodes[i]] < .25 * fmin(best[nodes[i - 1]], best[nodes[i + 1]]) &&
            fmin(nodes[i] - nodes[i - 1], nodes[i + 1] - nodes[i]) < h * .35) {
            memmove(nodes + i, nodes + i + 1, (size_t)(n - i - 1) * sizeof(*nodes));
            n--;
            if (i > 1) i--;
        } else
            i++;
    }
    int step = (int)lround(h / 45.0);
    if (step < 1) step = 1;
    if (step > 8) step = 8;
    int y0 = (int)(h * .17), y1 = (int)(h * .83);
    for (int x = step; x < w - step; x++) {
        int hist[256] = {0};
        for (int y = y0; y <= y1; y++)
            hist[abs(g[y * stride + x + step] - g[y * stride + x - step])]++;
        straight[x] = histogram_q(hist, y1 - y0 + 1, .5);
    }
    /* leading[] is temporarily the independent curvature vote; afterwards it
       stores the refined coordinates, so there is no extra per-node buffer. */
    for (int i = 0; i < n; i++)
        leading[i] = cap_polarity(g, w, h, stride, nodes[i], straight);
    double factor = tm_channel_length(&s->channel) / (w - 1);
    double minw = fmax(h * .28, s->min_length_px / factor);
    for (int i = 0; i + 1 < n; i++) {
        int l = nodes[i], r = nodes[i + 1];
        if (r - l < minw)
            continue;
        int near = (int)lround(fmin(h * .07, (r - l) * .12));
        int far = (int)lround(fmin(h * .28, (r - l) * .35));
        if (near < 1)
            near = 1;
        if (far < near || r - far < l + far)
            continue;
        double middle = quantile(roof + l + far, r - l - 2 * far + 1, .5);
        double a = 0, b = 0;
        for (int x = l + near; x <= l + far; x++)
            a = fmax(a, roof[x] - middle);
        for (int x = r - far; x <= r - near; x++)
            b = fmax(b, roof[x] - middle);
        /* A trailing cap followed by a leading cap encloses liquid, not a
           capsule. Bright reflections can make that gap resemble a roof. */
        double lp = leading[i], rp = leading[i + 1];
        /* If removing the straight component leaves no directional vote,
           use the original curved response. A clear cleaned vote wins. */
        if (fabs(lp) < .05 && fmax(left[l], right[l]) > 1.5 * fmin(left[l], right[l]))
            lp = (left[l] - right[l]) / (fmax(left[l], right[l]) + 1e-9);
        if (fabs(rp) < .05 && fmax(left[r], right[r]) > 1.5 * fmin(left[r], right[r]))
            rp = (left[r] - right[r]) / (fmax(left[r], right[r]) + 1e-9);
        liquid[i] = lp < -.03 && rp > .03 && rp - lp > .20;
        arcs[i] = !liquid[i] && a >= fmax(.5, h * .006) && b >= fmax(.5, h * .006) &&
                  fmax(a, b) >= fmax(1.5, h * .035) && fmax(a, b) <= h * .22 &&
                  fmax(a, b) <= 12 * fmin(a, b) && a + b >= fmax(3, h * .055) &&
                  quantile(contrast + l + near, r - l - 2 * near + 1, .5) >= roof_contrast;
    }
    for (int i = 0; i < n; i++) {
        int radius = (int)fmax(1, h * .05), l = nodes[i], r = nodes[i];
        int a = nodes[i] - radius, b = nodes[i] + radius;
        if (a < 2)
            a = 2;
        if (b > w - 3)
            b = w - 3;
        for (int x = a; x <= b; x++) {
            if (left[x] > left[l])
                l = x;
            if (right[x] > right[r])
                r = x;
        }
        leading[i] = subpixel_peak(left, l, w);
        trailing[i] = subpixel_peak(right, r, w);
        /* Overlapping fits mean an unresolved gap, not a negative distance or
           evidence for an invented positive micrometre-sized liquid segment. */
        if (i > 0 && i + 1 < n && arcs[i - 1] && arcs[i] && leading[i] < trailing[i]) {
            double mid = (leading[i] + trailing[i]) * .5;
            leading[i] = trailing[i] = mid;
        }
    }
    /* Reconcile the observed phase locally. Do not keep a rim-only candidate
       that occupies a positively identified liquid interval or bridges a
       capsule and that liquid. Independent, disjoint candidates are retained. */
    *trial = *s;
    int accepted = 0;
    for (int i = 0; i + 1 < n; i++)
        accepted += arcs[i] != 0;
    if (accepted) {
        for (int j = trial->count - 1; j >= 0; j--) {
            TM_Bubble old = trial->bubbles[j];
            int replace = 0;
            for (int i = 0; i + 1 < n && !replace; i++) {
                if (!arcs[i] && !liquid[i])
                    continue;
                double lo = (arcs[i] ? leading[i] : trailing[i]) * factor,
                       hi = (arcs[i] ? trailing[i + 1] : leading[i + 1]) * factor;
                double overlap = fmin(old.right, hi) - fmax(old.left, lo);
                double allowance = fmax(1, h * .06) * factor;
                if (overlap > allowance)
                    replace = 1;
            }
            if (replace)
                tm_delete_bubble(trial, j);
        }
        for (int i = 0; i + 1 < n; i++) {
            if (!arcs[i])
                continue;
            double l = leading[i] * factor, r = trailing[i + 1] * factor;
            /* A retained neighbour may use a slightly different fit to the
               same cap. Reconcile only this sub-cap overlap, never a measured
               positive liquid interval between distinct nodes. */
            double join = fmax(1, h * .08) * factor;
            for (int j = 0; j < trial->count; j++) {
                TM_Bubble *old = trial->bubbles + j;
                if (old->left < l - join && old->right > l && old->right <= l + join) {
                    l = old->right;
                    old->flags |= TM_UNCERTAIN;
                    old->confidence = fmin(old->confidence, .7);
                }
                if (old->right > r + join && old->left < r && old->left >= r - join) {
                    r = old->left;
                    old->flags |= TM_UNCERTAIN;
                    old->confidence = fmin(old->confidence, .7);
                }
            }
            if (r - l < minw * factor)
                continue;
            tm_add_bubble(trial, l, r, TM_UNCERTAIN, .7);
        }
        *s = *trial;
    }
    free(v);
    free(nodes);
    free(arcs);
    free(trial);
}

static int detect_strip(const uint8_t *g, int w, int h, int stride, TM_State *s) {
    if (!g || w < 12 || h < 5 || !s->channel.valid)
        return -1;
    double *body = (double *)calloc((size_t)w * 4, sizeof(double));
    Edge *edges = (Edge *)calloc((size_t)w, sizeof(Edge));
    if (!body || !edges) {
        free(body);
        free(edges);
        return -1;
    }
    double *left = body + w, *right = body + 2 * w;
    int y0 = (int)(h * 0.17), y1 = (int)(h * 0.83), center = h / 2;
    for (int x = 0; x < w; x++) {
        double sum = 0;
        for (int y = y0; y <= y1; y++)
            sum += g[y * stride + x];
        body[x] = sum / (y1 - y0 + 1);
    }
    /* Curved derivative templates: a cap is displaced inward at the walls.
       A straight screw/old overlay line has near-zero curvature and is not
       accepted as a high-confidence meniscus. */
    int derivative_step = (int)lround(h / 45.0);
    if (derivative_step < 1)
        derivative_step = 1;
    if (derivative_step > 8)
        derivative_step = 8;
    for (int x = derivative_step + 1; x < w - derivative_step - 1; x++) {
        /* Menisci may be flattened ellipses. Match several geometries against
           the same observed pixels, rather than assume a semicircular cap. */
        const double vertical[] = {0.375, 0.50, 0.62};
        const double horizontal[] = {0.12, 0.25, 0.375, 0.50};
        for (int v = 0; v < 3; v++)
            for (int k = 0; k < 4; k++) {
                double radius = fmax(2, (h - 1) * vertical[v]), bow = (h - 1) * horizontal[k];
                double a = 0, b = 0;
                int count = 0, support_l = 0, support_r = 0;
                for (int y = y0; y <= y1; y++) {
                    double t = (y - center) / radius;
                    if (fabs(t) > 0.95)
                        continue;
                    double d = bow * (1 - sqrt(fmax(0, 1 - t * t)));
                    int xl = (int)lround(x + d), xr = (int)lround(x - d);
                    if (xl <= derivative_step || xl >= w - derivative_step - 1 ||
                        xr <= derivative_step || xr >= w - derivative_step - 1)
                        continue;
                    double gl = fabs((double)g[y * stride + xl + derivative_step] -
                                     g[y * stride + xl - derivative_step]);
                    double gr = fabs((double)g[y * stride + xr + derivative_step] -
                                     g[y * stride + xr - derivative_step]);
                    a += gl;
                    b += gr;
                    support_l += gl > 4;
                    support_r += gr > 4;
                    count++;
                }
                if (count) {
                    double sl = (double)support_l / count, sr = (double)support_r / count;
                    if (sl >= 0.25)
                        left[x] = fmax(left[x], a / count * sl * sl);
                    if (sr >= 0.25)
                        right[x] = fmax(right[x], b / count * sr * sr);
                }
            }
    }
    smooth(body, w, 0.65);
    smooth(left, w, 0.6);
    smooth(right, w, 0.6);
    s->reviewed = 0;
    s->partial_count = 0;
    if (rim_segments(g, w, h, stride, left, right, s) >= 2) {
        separate_reflective_caps(g, w, h, stride, left, right, s);
        int count = s->count;
        free(body);
        free(edges);
        return count;
    }
    /* Unstructured sensor noise has strong local derivatives but no
       longitudinal body signal. It must not turn into invented cap pairs. */
    if (quantile(body, w, .90) - quantile(body, w, .10) < 3) {
        s->count = 0;
        free(body);
        free(edges);
        return 0;
    }
    double *best = (double *)malloc((size_t)w * sizeof(double));
    if (!best) {
        free(body);
        free(edges);
        return -1;
    }
    for (int x = 0; x < w; x++)
        best[x] = fmax(left[x], right[x]);
    double floor = quantile(best, w, 0.35), high = quantile(best, w, 0.90);
    double threshold = fmax(2.2, floor + (high - floor) * (0.36 - 0.0022 * s->sensitivity));
    int n = 0;
    double separation = fmax(1.5, h * 0.08);
    for (int x = 2; x < w - 2; x++) {
        if (!peak(best, x, w) || best[x] < threshold)
            continue;
        int kind = left[x] > right[x] ? 0 : 1;
        double bend = fabs(left[x] - right[x]) / (best[x] + 1e-6);
        /* NMS merges only duplicate responses to the same cap, never intervals. */
        if (n && x - edges[n - 1].x < separation) {
            if (best[x] > edges[n - 1].strength)
                edges[n - 1] = (Edge){(double)x, best[x], bend, kind};
            continue;
        }
        double denom = best[x - 1] - 2 * best[x] + best[x + 1], sub = 0;
        if (fabs(denom) > 1e-9)
            sub = 0.5 * (best[x - 1] - best[x + 1]) / denom;
        if (sub < -0.5)
            sub = -0.5;
        if (sub > 0.5)
            sub = 0.5;
        edges[n++] = (Edge){x + sub, best[x], bend, kind};
    }
    s->count = 0;
    s->partial_count = 0;
    s->reviewed = 0;
    double scale = tm_channel_length(&s->channel) / (w - 1),
           minw = fmax(h * 0.28, s->min_length_px / scale);
    /* Left cap points right at the walls; right cap points left. Every accepted
       pair is closed before the next pair, preserving narrow liquid slugs. */
    for (int i = 0; i < n;) {
        if (edges[i].kind != 0) {
            i++;
            continue;
        }
        int j = i + 1;
        while (j < n && (edges[j].kind != 1 || edges[j].x - edges[i].x < minw)) {
            /* A new well-supported leading cap starts a new candidate. Never bridge
               several observed leading caps into one bubble. */
            if (edges[j].kind == 0 && edges[j].x - edges[i].x >= minw)
                i = j;
            j++;
        }
        if (j == n)
            break;
        double l = edges[i].x, r = edges[j].x;
        if (r - l >= minw) {
            double conf = fmin(1, fmin(edges[i].strength, edges[j].strength) / (threshold * 2));
            if (edges[i].bend < 0.06 || edges[j].bend < 0.06 || j != i + 1)
                conf *= 0.6;
            tm_add_bubble(s, l * scale, r * scale, conf < 0.7 ? TM_UNCERTAIN : 0, conf);
        }
        i = j + 1;
    }
    if (n && (edges[0].kind == 1 || edges[n - 1].kind == 0))
        s->partial_count++;
    separate_reflective_caps(g, w, h, stride, left, right, s);
    free(best);
    free(body);
    free(edges);
    return s->count;
}

/* A user's rectangle is a search area, not an estimate of the channel
   diameter. Estimate the horizontal wall alignment first, then find the
   reflective rims and the dark inner lower wall. This prevents background and
   holder bars from setting cap size or suppressing short bubbles. Sampling is
   bounded independently of source image size; no image-specific coordinates,
   expected bubble counts or expected bubble spacing are used. */
static double sample_y(const uint8_t *g, int w, int h, int stride, int x, double y) {
    (void)w;
    if (y < 0)
        y = 0;
    if (y > h - 1)
        y = h - 1;
    int iy = (int)y, next = iy + 1 < h ? iy + 1 : iy;
    return g[iy * stride + x] + (y - iy) * (g[next * stride + x] - g[iy * stride + x]);
}
static double wall_profile(const uint8_t *g, int w, int h, int stride, double slope,
                           double *profile) {
    int samples = w < 128 ? w : 128;
    double margin = fabs(slope) * (w - 1) * .5, energy = 0;
    for (int y = 0; y < h; y++) {
        double sum = 0;
        for (int j = 0; j < samples; j++) {
            int x = (int)((double)j * (w - 1) / (samples - 1));
            sum += sample_y(g, w, h, stride, x, y + slope * (x - (w - 1) * .5));
        }
        profile[y] = sum / samples;
    }
    /* Two-pixel derivatives suppress sensor noise without smoothing away a
       narrow bright reflection. Boundary padding never contributes evidence. */
    for (int y = 2 + (int)ceil(margin); y < h - 2 - (int)ceil(margin); y++) {
        double d = (profile[y + 1] - profile[y - 1]) * .5;
        energy += d * d;
    }
    return energy;
}
static int working_band(const uint8_t *g, int w, int h, int stride, int *top, int *bottom,
                        double *slope) {
    *top = 0;
    *bottom = h - 1;
    *slope = 0;
    if (h < 16 || h > 1200 || w < 40)
        return 0;
    double *profile = (double *)malloc((size_t)h * 2 * sizeof(double));
    if (!profile)
        return 0;
    double *trial = profile + h;
    double initial = wall_profile(g, w, h, stride, 0, profile), best = initial, angle = 0;
    /* Search a total end-to-end vertical displacement, then refine at one
       pixel resolution. Narrow already-straight strips remain unchanged. */
    double max_delta = fmin(w * .12, h * .55), step = fmax(1, max_delta / 15);
    for (double delta = -max_delta; delta <= max_delta; delta += step) {
        double energy = wall_profile(g, w, h, stride, delta / (w - 1), trial);
        if (energy > best) {
            best = energy;
            angle = delta / (w - 1);
        }
    }
    double center_delta = angle * (w - 1);
    for (double delta = center_delta - step; delta <= center_delta + step; delta += 1) {
        double energy = wall_profile(g, w, h, stride, delta / (w - 1), trial);
        if (energy > best) {
            best = energy;
            angle = delta / (w - 1);
        }
    }
    if (best > initial * 1.08 && best > 100)
        *slope = angle;
    wall_profile(g, w, h, stride, *slope, profile);
    smooth(profile, h, .65);
    int margin = (int)ceil(fabs(*slope) * (w - 1) * .5) + 2;
    int radius = (int)(h * .06);
    if (radius < 4)
        radius = 4;
    if (radius > 45)
        radius = 45;
    int peaks[64], n = 0;
    double prominence[64];
    for (int y = margin + 1; y < h - margin - 1; y++) {
        if (!peak(profile, y, h))
            continue;
        int a = y - radius > margin ? y - radius : margin;
        int b = y + radius < h - margin - 1 ? y + radius : h - margin - 1;
        double left = profile[y], right = profile[y];
        for (int i = a; i < y; i++)
            left = fmin(left, profile[i]);
        for (int i = y + 1; i <= b; i++)
            right = fmin(right, profile[i]);
        double prom = profile[y] - fmax(left, right);
        if (prom >= 4.5 && n < 64) {
            peaks[n] = y;
            prominence[n++] = prom;
        }
    }
    double score = 0;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++) {
            int a = peaks[i], b = peaks[j], distance = b - a;
            if (distance < 12 || distance > w * .90 || prominence[j] < 15)
                continue;
            /* The lower bright reflection lies outside the liquid. Stop at
               the observed dark wall before it, rather than include the rail. */
            int wall = a + distance / 2;
            for (int y = wall + 1; y < b - 1; y++)
                if (profile[y] < profile[wall])
                    wall = y;
            int first = a + (int)fmax(1, distance * .025), last = wall + 1;
            if (last - first < 10 || last - first < distance * .50)
                continue;
            double inside = quantile(profile + first, last - first + 1, .70);
            if (profile[a] + 8 < inside || profile[b] < inside + 12)
                continue;
            /* Prefer the pair with evidence for both rims. The subsequent
               detector still requires distinct caps/rims along the channel. */
            double contrast = fmin(prominence[i], prominence[j]);
            double candidate = contrast + distance * .08;
            if (candidate > score) {
                score = candidate;
                *top = first;
                *bottom = last;
            }
        }
    free(profile);
    return score > 0;
}

int tm_detect(const uint8_t *g, int w, int h, int stride, TM_State *s) {
    if (!g || !s || w < 12 || h < 5 || stride < w || !s->channel.valid)
        return -1;
    int top, bottom;
    double slope;
    int narrowed = working_band(g, w, h, stride, &top, &bottom, &slope);
    if (!narrowed && fabs(slope) * (w - 1) < 1.5)
        return detect_strip(g, w, h, stride, s);
    int height = bottom - top + 1;
    uint8_t *work = (uint8_t *)malloc((size_t)w * height);
    if (!work)
        return -1;
    for (int y = 0; y < height; y++)
        for (int x = 0; x < w; x++)
            work[y * w + x] =
                (uint8_t)lround(sample_y(g, w, h, stride, x, top + y + slope * (x - (w - 1) * .5)));
    /* A vertical shear keeps the original longitudinal coordinates; do not
       rewrite the user's region, calibration, or channel during detection. */
    int result = detect_strip(work, w, height, w, s);
    free(work);
    return result;
}

/* Ruler finder looks for sequences of dark vertical ticks in many row bands.
   Tick spacing is 1 mm; long centimetre ticks are not a different scale. */
int tm_find_ruler(const uint8_t *g, int w, int h, int stride, double origin, TM_Calibration *out) {
    if (!g || w < 60 || h < 8)
        return 0;
    double *p = (double *)calloc((size_t)w * 2, sizeof(double));
    double *ticks = (double *)calloc((size_t)w, sizeof(double));
    TM_Calibration *best = (TM_Calibration *)calloc(1, sizeof(TM_Calibration));
    if (!p || !ticks || !best) {
        free(p);
        free(ticks);
        free(best);
        return 0;
    }
    double *baseline = p + w, best_score = 0;
    int bh = h / 25;
    if (bh < 6)
        bh = 6;
    if (bh > 45)
        bh = 45;
    int step = bh / 2;
    if (step < 2)
        step = 2;
    for (int y0 = 0; y0 + bh <= h; y0 += step) {
        for (int x = 0; x < w; x++) {
            double a = 0;
            for (int y = y0; y < y0 + bh; y++)
                a += g[y * stride + x];
            p[x] = a / bh;
            baseline[x] = p[x];
        }
        smooth(baseline, w, 8);
        for (int x = 0; x < w; x++)
            p[x] = baseline[x] - p[x];
        smooth(p, w, 0.55);
        double q = quantile(p, w, 0.92), threshold = fmax(4, q * 0.38);
        int nt = 0;
        for (int x = 2; x < w - 2; x++)
            if (peak(p, x, w) && p[x] > threshold) {
                double den = p[x - 1] - 2 * p[x] + p[x + 1],
                       sub = fabs(den) > 1e-9 ? 0.5 * (p[x - 1] - p[x + 1]) / den : 0;
                ticks[nt++] = x + fmax(-0.5, fmin(0.5, sub));
            }
        if (nt < 12)
            continue;
        /* RANSAC over adjacent differences rejects numbers, clamps and missing
         * ticks. */
        for (int seed = 1; seed < nt; seed++) {
            double pitch = ticks[seed] - ticks[seed - 1];
            if (pitch < 3 || pitch > w / 12.0 || pitch > 150)
                continue;
            int a = seed - 1, b = seed;
            double err = 0;
            while (a > 0) {
                double d = ticks[a] - ticks[a - 1];
                if (fabs(d - pitch) > pitch * 0.22)
                    break;
                a--;
            }
            while (b + 1 < nt) {
                double d = ticks[b + 1] - ticks[b];
                if (fabs(d - pitch) > pitch * 0.22)
                    break;
                b++;
            }
            int num = b - a + 1;
            if (num < 12)
                continue;
            double xm = 0, im = (num - 1) * 0.5, xx = 0, xy = 0;
            for (int i = a; i <= b; i++)
                xm += ticks[i];
            xm /= num;
            for (int i = a; i <= b; i++) {
                double dx = (i - a) - im;
                xx += dx * dx;
                xy += dx * (ticks[i] - xm);
            }
            pitch = xy / xx;
            double start = xm - pitch * im;
            for (int i = a; i <= b; i++) {
                double d = ticks[i] - (start + pitch * (i - a));
                err += d * d;
            }
            err = sqrt(err / num);
            if (err > fmax(0.75, pitch * 0.1))
                continue;
            double score = num / (1 + err / pitch * 15);
            if (score <= best_score)
                continue;
            best_score = score;
            memset(best, 0, sizeof(*best));
            best->valid = 1;
            best->mm_per_px = 1 / pitch;
            best->residual_px = err;
            /* Robust global fit limits per-tick pixel noise. Quadratic fit captures
               perspective only when supported by >=30 marks. */
            double quad = 0;
            if (num >= 30) {
                double z2 = 0, zr = 0, mean2 = (num * num - 1) / 12.0;
                for (int i = 0; i < num; i++) {
                    double z = i - im, t = z * z - mean2;
                    z2 += t * t;
                    zr += t * (ticks[a + i] - (start + pitch * i));
                }
                if (z2 > 0)
                    quad = zr / z2;
            }
            best->drift_percent = fabs(2 * quad * (num - 1) / pitch) * 100;
            if (best->drift_percent > 20) {
                best->valid = 0;
                continue;
            }
            best->count = num < TM_MAX_TICKS ? num : TM_MAX_TICKS;
            for (int i = 0; i < best->count; i++)
                best->ticks[i] =
                    (TM_Tick){origin + start + pitch * i +
                                  quad * ((i - im) * (i - im) - (num * num - 1) / 12.0),
                              i};
        }
    }
    int found = best->valid;
    if (found) {
        double ax = out->axis_x, ay = out->axis_y;
        *out = *best;
        out->axis_x = ax;
        out->axis_y = ay;
    }
    free(p);
    free(ticks);
    free(best);
    return found;
}
