#include "cv_bridge.h"
#include "history.h"
#include "overlay.h"
#include "recognition.h"
#include "tm.h"
#include "ui.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define T(ru, en) ru, en
#define TITLE "TaylorMeter"
#define CW 1280
#define CH 800
#define VX 20
#define VY 130
#define VW 880
#define VH 430
#define PX 920
#define PW 340
#define TABLE_Y 624
#define TABLE_ROWS 6
#define ROW_H 21
#define HISTORY_LIMIT 100
#define BG 0x131a25
#define FG 0xe6eef8
#define BLUE 0x62b7fa
#define RED 0xff4747
#define GREEN 0x5fd3b8
enum { EDIT = 0, CHANNEL, RULER, CALIBRATE, DISTANCE, ADD, FLOW };
enum {
    OPEN = 1,
    PREV,
    NEXT,
    PHOTO_VIEW,
    CHANNEL_VIEW,
    SELECT_CHANNEL,
    AUTO_RULER,
    MANUAL_RULER,
    DETECT,
    ADD_BUBBLE,
    DELETE_BUBBLE,
    REVIEW,
    EXPORT,
    SAVE_PROJECT,
    OPEN_PROJECT,
    UNDO_EDIT,
    CANCEL,
    FIT_VIEW,
    ZOOM_IN,
    ZOOM_OUT,
    LABELS,
    HELP,
    SENS_DOWN,
    SENS_UP,
    TABLE_UP,
    TABLE_DOWN,
    DISTANCE_OK,
    DISTANCE_CANCEL,
    REDO_EDIT,
    AUTO_CHANNEL,
    CLEAR_CHANNEL,
    TRAIN_DETECTOR, CLOSE_PHOTO, SET_FLOW, FLOW_OK, FLOW_CANCEL
};
typedef struct {
    int id, x, y, w, h;
    const char *label, *english;
} Button;
static const Button buttons[] = {
    {OPEN, 20, 50, 138, 32, T("Открыть фото", "Open photo")},
    {OPEN_PROJECT, 166, 50, 146, 32, T("Открыть проект", "Open project")},
    {SAVE_PROJECT, 320, 50, 152, 32, T("Сохранить проект", "Save project")},
    {UNDO_EDIT, 480, 50, 102, 32, T("Отменить", "Undo")},
    {REDO_EDIT, 590, 50, 102, 32, T("Повторить", "Redo")},
    {CANCEL, 700, 50, 100, 32, T("Сброс ввода", "Cancel")},
    {HELP, 808, 50, 92, 32, T("Справка", "Help")},
    {PREV, PX, 50, 46, 32, T("<", "<")},
    {NEXT, PX + 294, 50, 46, 32, T(">", ">")},
    {PHOTO_VIEW, 20, 92, 124, 30, T("Всё фото", "Full photo")},
    {CHANNEL_VIEW, 152, 92, 116, 30, T("Канал", "Channel")},
    {FIT_VIEW, 276, 92, 154, 30, T("Показать целиком", "Fit image")},
    {ZOOM_OUT, 438, 92, 38, 30, T("-", "-")},
    {ZOOM_IN, 484, 92, 38, 30, T("+", "+")},
    {LABELS, 530, 92, 124, 30, T("Размеры", "Labels")},
    {AUTO_CHANNEL, PX, 122, 110, 34, T("Авто", "Auto")},
    {SELECT_CHANNEL, PX + 118, 122, 222, 34, T("Выделить прямоугольник", "Draw rectangle")},
    {CLEAR_CHANNEL, PX, 162, 146, 28, T("Снять область", "Clear region")},
    {AUTO_RULER, PX, 222, 164, 34, T("Авто по линейке", "Auto ruler")},
    {MANUAL_RULER, PX + 172, 222, 168, 34, T("Вручную: 2 штриха", "Manual: 2 ticks")},
    {DETECT, PX, 302, PW, 34, T("Распознать и проверить", "Detect + self-check")},
    {SENS_DOWN, PX + 238, 342, 46, 28, T("-", "-")},
    {SENS_UP, PX + 292, 342, 48, 28, T("+", "+")},
    {TRAIN_DETECTOR, PX, 376, PW, 24,
     T("Подобрать по проверенной разметке", "Fit to reviewed boundaries")},
    {ADD_BUBBLE, PX, 406, 184, 30, T("Добавить пузырёк", "Add bubble")},
    {DELETE_BUBBLE, PX + 192, 406, 148, 30, T("Удалить пузырёк", "Delete selected")},
    {REVIEW, PX, 462, PW, 32, T("Границы и масштаб проверены", "Mark boundaries + scale reviewed")},
    {EXPORT, PX, 506, PW, 32, T("Сохранить Excel и разметку", "Save Excel + images")},
    {TABLE_UP, 792, 574, 50, 28, T("<", "<")},
    {TABLE_DOWN, 850, 574, 50, 28, T(">", ">")},
    {CLOSE_PHOTO, 770, 92, 130, 30, T("Закрыть фото", "Close photo")},
    {SET_FLOW, PX, 696, PW, 32, T("Задать расход", "Set flow")},
    {FLOW_OK, 355, 370, 110, 34, T("Применить", "Apply")},
    {FLOW_CANCEL, 480, 370, 110, 34, T("Отмена", "Cancel")},
    {DISTANCE_OK, 476, 312, 102, 34, T("Применить", "Apply")},
    {DISTANCE_CANCEL, 586, 312, 106, 34, T("Отмена", "Cancel")}};
#undef T
#define T(ru, en) tm_text(ru, en)
typedef struct {
    TM_Photo *photos;
    int count, index, mode, view, selected, side, drag, panning, dirty, help, labels, table_offset;
    int busy, hover;
    double default_flow[2];
    int default_flow_valid, flow_field;
    char flow_input[2][32];
    TM_Hover measure_hover;
    double zoom, panx, pany, mousex, mousey, start_panx, start_pany, start_mx, start_my;
    TM_Point points[3];
    int point_count;
    char input[32], status[384], project_path[TM_PATH];
    TM_History history;
    TM_State *pending;
    int pending_active, pending_index, rubber;
    TM_Point rectangle_start, rectangle_end;
    void *display;
    int display_w, display_h;
} App;
static void draw(App *a);
static void choose_automatic_channel(App *a);
static void update_measure_hover(App *a);
static void edit_flow(App *a);
static TM_Photo *photo(App *a) {
    return a->index >= 0 && a->index < a->count && !a->photos[a->index].state.excluded
               ? a->photos + a->index : NULL;
}
static int next_open(App *a, int from, int direction) {
    for (int i = from + direction; i >= 0 && i < a->count; i += direction)
        if (!a->photos[i].state.excluded) return i;
    return -1;
}
static void status(App *a, const char *s) {
    size_t n = strlen(s);
    if (n >= sizeof(a->status))
        n = sizeof(a->status) - 1;
    memcpy(a->status, s, n);
    a->status[n] = 0;
    a->dirty = 1;
}
static void working(App *a, const char *message) {
    a->busy = 1;
    tmui_busy(1);
    status(a, message);
    if (tmui_alive())
        draw(a);
}
static void finished(App *a) {
    a->busy = 0;
    tmui_busy(0);
    a->dirty = 1;
}
static int export_ready(App *a, char *reason, size_t cap) {
    int ready = 0;
    for (int i = 0; i < a->count; i++) {
        const TM_State *s = &a->photos[i].state;
        if (!s->count || s->excluded)
            continue;
        char error[256];
        if (!s->calibration.valid || !s->reviewed || !tm_validate(s, error, sizeof(error))) {
            snprintf(reason, cap,
                     T("Фото %d: задайте масштаб и отметьте проверку границ.",
                       "Photo %d: set the scale and mark boundaries reviewed."),
                     i + 1);
            return 0;
        }
        ready++;
    }
    if (!ready)
        snprintf(reason, cap, "%s",
                 T("Сначала отметьте пузырьки, масштаб и проверку границ.",
                   "First mark bubbles, set the scale and review boundaries."));
    return ready > 0;
}
static int button_visible(App *a, int id) {
    if (id == FLOW_OK || id == FLOW_CANCEL) return a->mode == FLOW && !a->help;
    return id == DISTANCE_OK || id == DISTANCE_CANCEL ? a->mode == DISTANCE && !a->help : 1;
}
static int button_enabled(App *a, int id) {
    TM_Photo *p = photo(a);
    if (a->busy) return 0;
    if (a->mode == FLOW) return id == FLOW_OK || id == FLOW_CANCEL || id == CANCEL;
    if (id == SAVE_PROJECT) return a->count > 0;
    if (id == EXPORT) { char why[256]; return export_ready(a, why, sizeof(why)); }
    if (id == HELP || id == OPEN || id == OPEN_PROJECT)
        return 1;
    if (id == CANCEL || id == DISTANCE_CANCEL)
        return a->mode != EDIT || a->help || a->drag || a->rubber;
    if (id == DISTANCE_OK)
        return a->mode == DISTANCE;
    if (id == UNDO_EDIT)
        return a->history.cursor > 0 || a->pending_active || a->rubber ||
               (a->mode == ADD && a->point_count);
    if (id == REDO_EDIT)
        return a->history.cursor < a->history.count;
    if (!p)
        return 0;
    if (!p->image && id != SAVE_PROJECT && id != PREV && id != NEXT && id != CLOSE_PHOTO && id != SET_FLOW)
        return 0;
    switch (id) {
    case PREV:
        return next_open(a, a->index, -1) >= 0;
    case NEXT:
        return next_open(a, a->index, 1) >= 0;
    case UNDO_EDIT:
        return a->history.cursor > 0 || a->pending_active || a->rubber ||
               (a->mode == ADD && a->point_count);
    case REDO_EDIT:
        return a->history.cursor < a->history.count;
    case CLEAR_CHANNEL:
        return p->state.channel.valid;
    case CHANNEL_VIEW:
    case AUTO_RULER:
    case MANUAL_RULER:
    case DETECT:
    case ADD_BUBBLE:
        return p->state.channel.valid;
    case SENS_DOWN:
        return p->state.channel.valid && p->state.sensitivity > 0;
    case SENS_UP:
        return p->state.channel.valid && p->state.sensitivity < 100;
    case DELETE_BUBBLE:
        return a->selected >= 0 && a->selected < p->state.count;
    case REVIEW:
        return p->state.channel.valid && p->state.calibration.valid && p->state.count > 0;
    case TRAIN_DETECTOR:
        return p->state.channel.valid && p->state.reviewed && p->state.count >= 3;
    case TABLE_UP:
        return a->table_offset > 0;
    case TABLE_DOWN:
        return a->table_offset + TABLE_ROWS < p->state.count;
    case EXPORT: {
        char reason[256];
        return export_ready(a, reason, sizeof(reason));
    }
    default:
        return p->image != NULL || id == SAVE_PROJECT || id == CLOSE_PHOTO || id == SET_FLOW;
    }
}
static void unavailable(App *a, int id) {
    if (id == EXPORT) {
        char reason[256];
        export_ready(a, reason, sizeof(reason));
        status(a, reason);
    } else if (id == UNDO_EDIT)
        status(a, T("Нет правок для отмены.", "No edits to undo."));
    else if (id == REDO_EDIT)
        status(a, T("Нет отменённых правок для повторения.", "No edits to redo."));
    else if (id == DELETE_BUBBLE)
        status(a, T("Выберите пузырёк в таблице или щёлкните по красному торцу.",
                    "Select a table row or click a red meniscus first."));
    else if (id == PREV || id == NEXT)
        status(a, T("Это крайний кадр. Добавьте ещё фото кнопкой «Открыть фото».",
                    "This is the first/last photo. Use Open photo to add another."));
    else if (id == TABLE_UP || id == TABLE_DOWN)
        status(a, T("Показана первая или последняя страница таблицы.",
                    "This is the first or last page of measurements."));
    else if (id == CANCEL || id == DISTANCE_CANCEL)
        status(a, T("Нет незавершённого выбора для отмены.", "No pending selection to cancel."));
    else if ((id == SENS_DOWN || id == SENS_UP) && photo(a) && photo(a)->state.channel.valid)
        status(a, T("Достигнута граница чувствительности: от 0 до 100.",
                    "Sensitivity is limited to 0 through 100."));
    else if (id == REVIEW)
        status(a, T("Для проверки нужны пузырьки и масштаб по линейке.",
                    "Review needs marked bubbles and a ruler scale."));
    else if (id == TRAIN_DETECTOR)
        status(a,
               T("Исправьте все торцы минимум трёх пузырьков и отметьте проверку кадра.",
                 "Correct all boundaries of at least three bubbles and mark the photo reviewed."));
    else if (!photo(a))
        status(a, T("Сначала нажмите «Открыть фото» или «Открыть проект».",
                    "Click Open photo or Open project first."));
    else if (!photo(a)->image)
        status(a, T("Исходное фото недоступно. Верните файл по сохранённому пути и откройте его.",
                    "Source photograph is missing. Restore it at its saved path and open it."));
    else
        status(a, T("Сначала выделите канал прямоугольником или нажмите «Авто».",
                    "Draw a rectangle around the channel or click Auto first."));
}
static void push(App *a) {
    TM_Photo *p = photo(a);
    if (!p || a->pending_active)
        return;
    *a->pending = p->state;
    a->pending_index = a->index;
    a->pending_active = 1;
}
static void commit_edit(App *a) {
    if (!a->pending_active || a->drag || a->rubber)
        return;
    TM_State *current = &a->photos[a->pending_index].state;
    if (memcmp(a->pending, current, sizeof(*current))) {
        tm_history_record(&a->history, a->pending_index, a->pending, current);
        a->dirty = 1;
    }
    a->pending_active = 0;
}
static void rollback_edit(App *a) {
    if (a->pending_active) {
        a->photos[a->pending_index].state = *a->pending;
        a->pending_active = 0;
    }
    a->drag = a->rubber = 0;
}

static void fit(App *a) {
    if (a->display_w <= 0 || a->display_h <= 0)
        return;
    a->zoom = fmin((double)VW / a->display_w, (double)VH / a->display_h);
    a->panx = (a->display_w - VW / a->zoom) * 0.5;
    a->pany = (a->display_h - VH / a->zoom) * 0.5;
    a->dirty = 1;
}
static int make_strip(TM_Photo *p) {
    cvb_free(p->strip);
    p->strip = NULL;
    if (!p->image || !p->state.channel.valid)
        return 0;
    int w, h;
    p->strip = cvb_strip(p->image, &p->state.channel, &w, &h);
    return p->strip != NULL;
}
static void *annotate(TM_Photo *p, int channel_view, int labels, int *width, int *height) {
    if (!p || !p->image)
        return NULL;
    TM_State *s = &p->state;
    void *out;
    double len = tm_channel_length(&s->channel);
    if (channel_view) {
        if (!p->strip)
            return NULL;
        int w, h, st;
        cvb_gray(p->strip, &w, &h, &st);
        *width = w;
        *height = 300;
        out = cvb_create(w, 300, BG);
        void *stretch = cvb_resize(p->strip, w, 140);
        if (!out || !stretch) {
            cvb_free(out);
            cvb_free(stretch);
            return NULL;
        }
        cvb_blit(out, stretch, 1, 0, 0, 0, 80, w, 140);
        cvb_free(stretch);
    } else {
        out = cvb_clone(p->image);
        *width = p->width;
        *height = p->height;
    }
    if (!out)
        return NULL;
    if (s->channel.valid && !channel_view) {
        if (s->region.valid)
            cvb_rect(out, s->region.x, s->region.y, s->region.w, s->region.h, BLUE, 1);
        for (int wall = -1; wall <= 1; wall += 2) {
            TM_Point a = tm_channel_point(&s->channel, 0, wall * s->channel.half_width),
                     b = tm_channel_point(&s->channel, len, wall * s->channel.half_width);
            cvb_line(out, a.x, a.y, b.x, b.y, BLUE, 1);
        }
    }
    TM_Overlay layout;
    tm_overlay_init(&layout, &s->channel, channel_view ? *width : 0);
    tm_overlay_draw(out, s, &layout, labels);
    return out;
}
static void rebuild(App *a, int do_fit) {
    cvb_free(a->display);
    a->display = NULL;
    TM_Photo *p = photo(a);
    if (p) {
        if (a->view && !p->state.channel.valid)
            a->view = 0;
        a->display = annotate(p, a->view, a->labels, &a->display_w, &a->display_h);
    }
    if (do_fit) {
        fit(a);
        if (a->view && a->zoom < 1) {
            a->zoom = 1;
            a->panx = 0;
            a->pany = (a->display_h - VH) * .5;
        }
    }
    a->dirty = 1;
}
static void switch_photo(App *a, int index) {
    if (index < 0 || index >= a->count || a->photos[index].state.excluded) {
        int pivot = index < 0 ? 0 : index;
        index = next_open(a, pivot - 1, 1);
        if (index < 0) index = next_open(a, pivot, -1);
    }
    a->index = index;
    if (index < 0) {
        a->mode = EDIT;
        a->point_count = a->rubber = a->drag = 0;
        a->selected = -1;
        rebuild(a, 0);
        return;
    }
    a->mode = EDIT;
    a->point_count = 0;
    a->selected = -1;
    a->drag = a->rubber = 0;
    a->table_offset = 0;
    TM_Photo *p = photo(a);
    if (!p->image) {
        int w, h;
        p->image = cvb_load(p->path, &w, &h);
        if (!p->image) {
            status(a, cvb_error());
            rebuild(a, 1);
            return;
        }
        if (p->width && p->height && (p->width != w || p->height != h)) {
            double flow0 = p->state.flow[0], flow1 = p->state.flow[1];
            int valid_flow = p->state.flow_valid;
            memset(&p->state, 0, sizeof(p->state));
            p->state.flow[0] = flow0; p->state.flow[1] = flow1;
            p->state.flow_valid = valid_flow;
            p->state.sensitivity = 50;
            p->state.min_length_px = 3;
            status(a, T("Размер исходника изменился: выделите канал заново.",
                        "Source dimensions changed: choose channel again."));
        }
        p->width = w;
        p->height = h;
        make_strip(p);
    }
    a->view = 0;
    rebuild(a, 1);
    status(a, p->state.channel.valid ? T("Перетащите красные торцы; колесо — масштаб; H — помощь.",
                                         "Drag red caps; wheel to zoom; H for help.")
                                     : T("Выделите канал прямоугольником или нажмите «Авто».",
                                         "Draw a channel rectangle or click Auto."));
}
static void open_photo(App *a, const char *path) {
    for (int i = 0; i < a->count; i++)
        if (!strcmp(a->photos[i].path, path)) {
            if (a->photos[i].state.excluded) {
                *a->pending = a->photos[i].state;
                a->photos[i].state.excluded = 0;
                tm_history_record(&a->history, i, a->pending, &a->photos[i].state);
            }
            switch_photo(a, i);
            return;
        }
    if (a->count >= TM_MAX_PHOTOS) {
        status(a, T("Не более 128 фотографий в одном проекте.", "Maximum 128 photographs per project."));
        return;
    }
    double sensitivity = photo(a) ? photo(a)->state.sensitivity : 50;
    TM_Photo *p = a->photos + a->count;
    memset(p, 0, sizeof(*p));
    snprintf(p->path, sizeof(p->path), "%s", path);
    p->state.flow_valid = a->default_flow_valid;
    p->state.flow[0] = a->default_flow[0]; p->state.flow[1] = a->default_flow[1];
    p->state.sensitivity = sensitivity;
    p->state.min_length_px = 3;
    p->image = cvb_load(path, &p->width, &p->height);
    if (!p->image) {
        status(a, cvb_error());
        return;
    }
    a->count++;
    switch_photo(a, a->count - 1);
    choose_automatic_channel(a);
    commit_edit(a);
    if (!p->state.flow_valid) edit_flow(a);
}
static int auto_ruler(App *a, int x, int y, int w, int h) {
    TM_Photo *p = photo(a);
    if (!p || !p->state.channel.valid)
        return 0;
    double origin, len = tm_channel_length(&p->state.channel);
    void *r = cvb_ruler_roi(p->image, &p->state.channel, x, y, w, h, &origin);
    if (!r)
        return 0;
    TM_Calibration *c = (TM_Calibration *)calloc(1, sizeof(TM_Calibration));
    if (!c) {
        cvb_free(r);
        return 0;
    }
    c->axis_x = (p->state.channel.b.x - p->state.channel.a.x) / len;
    c->axis_y = (p->state.channel.b.y - p->state.channel.a.y) / len;
    if (c->axis_x < 0) {
        c->axis_x = -c->axis_x;
        c->axis_y = -c->axis_y;
    }
    int rw, rh, st;
    const uint8_t *g = cvb_gray(r, &rw, &rh, &st);
    int found = tm_find_ruler(g, rw, rh, st, origin, c);
    cvb_free(r);
    if (found) {
        p->state.calibration = *c;
        p->state.reviewed = 0;
    }
    free(c);
    return found;
}
static void detect(App *a) {
    TM_Photo *p = photo(a);
    if (!p || !p->state.channel.valid) {
        status(a, T("Сначала выберите канал: C.", "Choose the channel first (C)."));
        return;
    }
    if (!p->strip && !make_strip(p)) {
        status(a, cvb_error());
        return;
    }
    push(a);
    int w, h, st;
    const uint8_t *g = cvb_gray(p->strip, &w, &h, &st);
    TM_RecognitionReport report;
    int n = tm_detect_checked(g, w, h, st, &p->state, &report);
    if (n < 0) {
        status(a, T("Ошибка распознавания. Прежняя разметка сохранена.",
                    "Detection failed. Previous boundaries were preserved."));
        return;
    }
    a->selected = -1;
    a->view = 1;
    rebuild(a, 1);
    char text[384];
    if (!n) {
        status(a, T("Пузырьки не найдены. Приблизьте канал, проверьте рамку и видимые торцы. "
                    "Измените область или добавьте пары вручную.",
                    "No bubbles found. Zoom in and check the region and visible caps. "
                    "Adjust the rectangle or add pairs manually."));
        return;
    }
    snprintf(text, sizeof(text),
             T("Найдено %d пузырьков, %d слагов. Самопроверка: %d–%d пузырьков; "
               "неустойчивых пар %d. Проверьте торцы.",
               "Found %d bubbles, %d slugs. Self-check: %d..%d bubbles; "
               "%d unstable pairs. Inspect the boundaries."),
             n, n - 1, report.min_count, report.max_count, report.unstable);
    status(a, text);
}
static void train_detector(App *a) {
    TM_Photo *p = photo(a);
    if (!p || (!p->strip && !make_strip(p)))
        return;
    working(a, T("Подбираю параметры по проверенным торцам…",
                 "Fitting parameters to reviewed boundaries..."));
    int w, h, stride;
    const uint8_t *g = cvb_gray(p->strip, &w, &h, &stride);
    TM_TrainingReport report;
    int ok = tm_tune_recognition(g, w, h, stride, &p->state, &report);
    char message[384];
    if (ok <= 0)
        status(a, T("Подбор не выполнен. Нужны проверенные торцы минимум трёх пузырьков.",
                    "Fit failed. At least three reviewed bubbles are required."));
    else if (!report.accepted) {
        snprintf(message, sizeof(message),
                 T("Подбор не принят: совпало %d из %d, лишних %d. Параметры и торцы сохранены. "
                   "Оставьте ручную разметку этого кадра.",
                   "Fit rejected: %d of %d matched, %d extra. Parameters and boundaries "
                   "were preserved. Keep this photo's manual marks."),
                 report.matched, p->state.count, report.extra);
        status(a, message);
    } else {
        push(a);
        p->state.sensitivity = report.sensitivity;
        snprintf(message, sizeof(message),
                 T("Подбор: %.0f; совпало %d/%d; ошибка %.2f px на этом кадре. "
                   "Торцы сохранены. Новые фото используют этот параметр; отмена: Ctrl+Z.",
                   "Fit: %.0f; %d/%d matched; error %.2f px on this photo. Boundaries preserved. "
                   "New photos use this setting; Undo restores it."),
                 report.sensitivity, report.matched, p->state.count, report.mean_error_px);
        status(a, message);
    }
    finished(a);
}
static int apply_region(App *a, TM_Rect region, const TM_Channel *axis) {
    TM_Photo *p = photo(a);
    if (!p || !p->image)
        return 0;
    push(a);
    int valid;
    if (axis && axis->valid) {
        TM_Point wall = tm_channel_point(axis, 0, -axis->half_width);
        valid = tm_set_channel(&p->state, axis->a, axis->b, wall);
        if (valid)
            p->state.region = region;
    } else
        valid = tm_set_channel_rect(&p->state, region, p->width, p->height);
    if (!valid || !make_strip(p)) {
        rollback_edit(a);
        make_strip(p);
        rebuild(a, 0);
        status(a, T("Область слишком мала. Выделите канал длинным прямоугольником.",
                    "Region too small. Draw a long rectangle around the channel."));
        return 0;
    }
    TM_Calibration *c = &p->state.calibration;
    double length = tm_channel_length(&p->state.channel);
    double ux = (p->state.channel.b.x - p->state.channel.a.x) / length;
    double uy = (p->state.channel.b.y - p->state.channel.a.y) / length;
    if (c->valid && fabs(ux * c->axis_x + uy * c->axis_y) < .98)
        memset(c, 0, sizeof(*c));
    if (!c->valid)
        auto_ruler(a, 0, 0, p->width, p->height);
    detect(a);
    a->view = 0;
    a->mode = EDIT;
    a->point_count = a->rubber = 0;
    rebuild(a, 1);
    return 1;
}
static void choose_automatic_channel(App *a) {
    TM_Photo *p = photo(a);
    if (!p || !p->image)
        return;
    a->help = 0;
    working(a, T("Ищу канал с пузырьками…", "Finding the bubble channel..."));
    TM_Channel axis = {0};
    TM_Rect region = {0};
    if (tm_image_channel(p->image, NULL, &axis, &region))
        apply_region(a, region, &axis);
    else {
        if (!p->state.channel.valid) {
            a->mode = CHANNEL;
            a->view = 0;
            a->point_count = a->rubber = 0;
            rebuild(a, 1);
        }
        status(a, T("Уверенная область не найдена. Зажмите левую кнопку и выделите канал "
                    "прямоугольником.",
                    "No reliable automatic region. Hold the left mouse button and draw a channel "
                    "rectangle."));
    }
    finished(a);
}
static TM_Point image_point(App *a, TM_Photo *p, int x, int y) {
    x = (int)fmax(VX, fmin(VX + VW - 1, x));
    y = (int)fmax(VY, fmin(VY + VH - 1, y));
    TM_Point point = {(x - VX) / a->zoom + a->panx, (y - VY) / a->zoom + a->pany};
    point.x = fmax(0, fmin(p->width - 1, point.x));
    point.y = fmax(0, fmin(p->height - 1, point.y));
    return point;
}
static void finish_rectangle(App *a) {
    TM_Photo *p = photo(a);
    int ruler = a->mode == RULER;
    TM_Point start = a->rectangle_start, end = a->rectangle_end;
    TM_Rect r;
    r.x = (int)floor(fmin(start.x, end.x));
    r.y = (int)floor(fmin(start.y, end.y));
    r.w = (int)ceil(fmax(start.x, end.x)) - r.x + 1;
    r.h = (int)ceil(fmax(start.y, end.y)) - r.y + 1;
    r.valid = 1;
    r.automatic = 0;
    a->rubber = 0;
    if (!p || r.w < 5 || r.h < 5 || fmax(r.w, r.h) < 12) {
        status(a, T("Прямоугольник слишком мал. Протяните область ещё раз.",
                    "Rectangle too small. Drag another region."));
        return;
    }
    working(a, ruler ? T("Определяю масштаб в прямоугольнике…",
                         "Calibrating the selected ruler region...")
                     : T("Применяю область канала…", "Applying the channel rectangle..."));
    if (ruler) {
        push(a);
        int found = auto_ruler(a, r.x, r.y, r.w, r.h);
        a->mode = EDIT;
        rebuild(a, 0);
        status(a, found
                      ? T("Масштаб найден. Его изменение можно отменить.",
                          "Scale found. Undo restores the previous scale.")
                      : T("Штрихи не найдены. Выделите другой участок или задайте масштаб вручную.",
                          "No reliable ruler ticks. Select another region or calibrate manually."));
    } else {
        /* The user chose this entire region. The detector locates the working
           band inside it; a second Hough search could replace it with a thin
           bright reflection and discard the actual bubble pixels. */
        if (!apply_region(a, r, NULL))
            a->mode = CHANNEL;
    }
    finished(a);
}
static void set_mode(App *a, int mode) {
    if (!photo(a))
        return;
    if ((mode == RULER || mode == CALIBRATE || mode == ADD) && !photo(a)->state.channel.valid) {
        status(a, T("Сначала выделите канал: C.", "Select the channel first (C)."));
        return;
    }
    int keep_view = mode == ADD && a->view;
    a->mode = mode;
    a->help = 0;
    a->point_count = 0;
    a->rubber = a->drag = 0;
    a->selected = -1;
    if (mode == CHANNEL || mode == RULER || mode == CALIBRATE)
        a->view = 0;
    else if (mode == ADD)
        a->view = 1;
    rebuild(a, !keep_view);
    if (mode == CHANNEL)
        status(a,
               T("Зажмите левую кнопку мыши, протяните прямоугольник вокруг канала и отпустите.",
                 "Hold the left mouse button, drag a rectangle around the channel and release."));
    if (mode == RULER)
        status(a, T("Протяните прямоугольник вокруг участка линейки минимум с 12 малыми делениями.",
                    "Drag a rectangle around at least 12 small ruler divisions."));
    if (mode == CALIBRATE)
        status(a, T("Выберите центры 2 штрихов линейки; затем введите расстояние в мм.",
                    "Click the centres of 2 ruler ticks, then enter distance in mm."));
    if (mode == ADD)
        status(a, T("Добавляйте пары торцов подряд. Esc или «Завершить» — выход; Ctrl+Z — отмена.",
                    "Keep clicking pairs of caps. Esc or Finish exits; Undo removes the last edit."));
}
static void release_photos(App *a) {
    for (int i = 0; i < a->count; i++) {
        cvb_free(a->photos[i].image);
        cvb_free(a->photos[i].strip);
    }
    memset(a->photos, 0, TM_MAX_PHOTOS * sizeof(TM_Photo));
    a->count = 0;
}
static void load_project(App *a, const char *path) {
    TM_Photo *tmp = (TM_Photo *)calloc(TM_MAX_PHOTOS, sizeof(TM_Photo));
    if (!tmp)
        return;
    char error[300];
    int n = tm_load_project(path, tmp, TM_MAX_PHOTOS, error, sizeof(error));
    if (n < 0) {
        status(a, error);
        free(tmp);
        return;
    }
    release_photos(a);
    tm_history_clear(&a->history);
    a->pending_active = 0;
    memcpy(a->photos, tmp, (size_t)n * sizeof(TM_Photo));
    free(tmp);
    a->count = n;
    a->default_flow_valid = 0;
    for (int i = 0; i < n; i++) {
        tm_relocate_source(a->photos[i].path, TM_PATH, path);
        if (!a->photos[i].state.excluded && a->photos[i].state.flow_valid) {
            a->default_flow_valid = 1;
            memcpy(a->default_flow, a->photos[i].state.flow, sizeof(a->default_flow));
        }
    }
    snprintf(a->project_path, TM_PATH, "%s", path);
    if (n)
        switch_photo(a, 0);
    else {
        rebuild(a, 1);
        a->index = -1;
        status(a, T("Пустой проект.", "Empty project."));
    }
}
static void save_outputs(App *a, const char *xlsx) {
    char error[512], base[TM_PATH], path[TM_PATH];
    int saved = 0;
    if (!tm_export_photo_base(xlsx, base, sizeof(base))) {
        status(a, T("Не удалось создать saves/photo.", "Cannot create saves/photo."));
        return;
    }
    if (!tm_export_xlsx(xlsx, a->photos, a->count, error, sizeof(error))) {
        status(a, error);
        return;
    }
    int ok = 1;
    for (int i = 0; i < a->count && ok; i++)
        if (a->photos[i].state.count && !a->photos[i].state.excluded) {
            TM_Photo *p = a->photos + i;
            if (!p->image) {
                int w, h;
                p->image = cvb_load(p->path, &w, &h);
                if (!p->image) {
                    ok = 0;
                    break;
                }
                make_strip(p);
            }
            for (int view = 0; view < 2 && ok; view++) {
                int w, h;
                void *out = annotate(p, view, 1, &w, &h);
                char stem[TM_PATH];
                if (!tm_export_stem(p, i, stem, sizeof(stem)) ||
                    snprintf(path, sizeof(path), "%s_%s_%s.png", base, stem,
                             view ? "channel" : "photo") >= (int)sizeof(path))
                    ok = 0;
                else
                    ok = out && cvb_save(out, path);
                cvb_free(out);
            }
            saved++;
        }
    if (strlen(base) + 5 > sizeof(path))
        ok = 0;
    else if (ok) {
        strcpy(path, base);
        strcat(path, ".tmc");
        ok = tm_save_project(path, a->photos, a->count);
        snprintf(a->project_path, TM_PATH, "%s", path);
    }
    if (ok) {
        snprintf(error, sizeof(error),
                 T("Сохранено в saves: Excel, %d фото, каналы и проект .tmc.",
                   "Saved to saves: Excel, %d photos, channel crops and .tmc project."),
                 saved);
        status(a, error);
    } else
        status(a, T("Excel сохранён; часть фото/проект не сохранены. Проверьте пути к исходникам.",
                    "XLSX saved; some images/project could not be saved. Check source paths."));
}
static void apply_distance(App *a) {
    TM_Photo *p = photo(a);
    if (!p || a->mode != DISTANCE)
        return;
    char text[32], *end = NULL;
    snprintf(text, sizeof(text), "%s", a->input);
    for (char *c = text; *c; c++)
        if (*c == ',')
            *c = '.';
    double mm = strtod(text, &end);
    if (!text[0] || !end || *end || !isfinite(mm) || mm <= 0) {
        status(a, T("Введите положительное расстояние, например 10 или 1,5 мм.",
                    "Enter a positive distance, for example 10 or 1.5 mm."));
        return;
    }
    push(a);
    if (!tm_manual_calibrate(&p->state, a->points[0], a->points[1], mm)) {
        rollback_edit(a);
        status(a, T("Штрихи слишком близко или не совпадают с направлением канала.",
                    "Ticks are too close or do not follow the channel direction."));
        return;
    }
    a->mode = EDIT;
    a->point_count = 0;
    rebuild(a, 0);
    status(a, T("Масштаб установлен. Проверьте длины и отметьте проверку границ.",
                "Scale applied. Inspect lengths and mark boundaries reviewed."));
}
static void dialog_cancelled(App *a) {
    const char *error = tm_dialog_error();
    status(a, error[0] ? error
                       : T("Диалог закрыт. Можно продолжать работу.",
                           "Dialog cancelled. You can continue editing."));
}
static void edit_flow(App *a) {
    TM_Photo *p = photo(a);
    if (!p) return;
    a->mode = FLOW; a->help = 0; a->flow_field = 0;
    a->point_count = a->rubber = a->drag = 0;
    for (int i = 0; i < 2; i++) {
        if (p->state.flow_valid) snprintf(a->flow_input[i], 32, "%.12g", p->state.flow[i]);
        else if (a->default_flow_valid) snprintf(a->flow_input[i], 32, "%.12g", a->default_flow[i]);
        else a->flow_input[i][0] = 0;
    }
    status(a, T("Введите два значения расхода. Они перейдут на новые фото.",
                "Enter two flow values. New photos will inherit them."));
}
static void apply_flow(App *a) {
    TM_Photo *p = photo(a);
    double values[2];
    if (!p || !tm_parse_flow(a->flow_input[0], values) || !tm_parse_flow(a->flow_input[1], values+1)) {
        status(a, T("Введите два числа от 0 до 10^12; допустимы точка и запятая.",
                    "Enter two numbers from 0 to 10^12; a decimal point or comma is accepted."));
        return;
    }
    push(a);
    memcpy(p->state.flow, values, sizeof(values)); p->state.flow_valid = 1;
    memcpy(a->default_flow, values, sizeof(values)); a->default_flow_valid = 1;
    a->mode = EDIT;
    commit_edit(a);
    status(a, T("Расход сохранён для этого и новых фото. Предыдущие фото не изменены.",
                "Flow saved for this photo and new photos. Earlier photos keep their values."));
}
static void action(App *a, int id) {
    if (id == UNDO_EDIT && a->mode == ADD && a->point_count) {
        a->point_count = 0;
        status(a, T("Первый торец сброшен. Добавляйте следующую пару; Esc — выход.",
                    "First cap cleared. Add the next pair; Esc exits."));
        return;
    }
    if ((id == UNDO_EDIT || id == CANCEL) && (a->drag || a->rubber)) {
        rollback_edit(a);
        a->mode = EDIT;
        a->point_count = 0;
        make_strip(photo(a));
        rebuild(a, 0);
        status(a, T("Незавершённая правка отменена.", "Unfinished edit cancelled."));
        return;
    }
    if (a->drag)
        a->drag = 0;
    commit_edit(a);
    char path[TM_PATH];
    TM_Photo *p = photo(a);
    if (!button_enabled(a, id)) {
        unavailable(a, id);
        return;
    }
    if (id == OPEN) {
        if (tm_choose_file(path, sizeof(path), 0, "image")) {
            working(a, T("Открываю фотографию…", "Opening photograph..."));
            open_photo(a, path);
            a->help = 0;
            finished(a);
        } else {
#ifdef _WIN32
            dialog_cancelled(a);
#else
            status(a, "Linux: start TaylorMeter photo1.jpg photo2.jpg or session.tmc.");
#endif
        }
        return;
    }
    if (id == OPEN_PROJECT) {
        if (tm_choose_file(path, sizeof(path), 0, "project")) {
            working(a, T("Открываю проект…", "Opening project..."));
            load_project(a, path);
            a->help = 0;
            finished(a);
        } else
            dialog_cancelled(a);
        return;
    }
    if (id == CANCEL || id == DISTANCE_CANCEL || id == FLOW_CANCEL) {
        a->mode = EDIT;
        a->point_count = 0;
        a->drag = a->panning = a->help = 0;
        status(a, T("Выбор отменён. Готовая разметка сохранена.",
                    "Selection cancelled. Existing measurements are kept."));
        return;
    }
    if (id == HELP) {
        a->help = !a->help;
        a->dirty = 1;
        return;
    }
    if (id == DISTANCE_OK) {
        apply_distance(a);
        return;
    }
    if (id == SET_FLOW) { edit_flow(a); return; }
    if (id == FLOW_OK) { apply_flow(a); return; }
    if (!p && id != UNDO_EDIT && id != REDO_EDIT && id != SAVE_PROJECT && id != EXPORT) return;
    switch (id) {
    case CLOSE_PHOTO:
        push(a);
        p->state.excluded = 1;
        commit_edit(a);
        cvb_free(p->image); cvb_free(p->strip); p->image = p->strip = NULL;
        switch_photo(a, a->index);
        status(a, T("Фото закрыто и исключено из расчёта. Ctrl+Z вернёт его.",
                    "Photo closed and excluded from calculations. Ctrl+Z restores it."));
        break;
    case PREV:
        switch_photo(a, next_open(a, a->index, -1));
        break;
    case NEXT:
        switch_photo(a, next_open(a, a->index, 1));
        break;
    case PHOTO_VIEW:
        a->mode = EDIT;
        a->point_count = 0;
        a->view = 0;
        rebuild(a, 1);
        status(a, T("Показано исходное фото. Колесо увеличивает, перетаскивание перемещает.",
                    "Full photograph. Wheel zooms; drag empty space to pan."));
        break;
    case CHANNEL_VIEW:
        if (p->state.channel.valid) {
            a->view = 1;
            a->mode = EDIT;
            a->point_count = 0;
            rebuild(a, 1);
            status(a, T("Показан канал. Перетаскивайте красные торцы; таблица выбирает пузырёк.",
                        "Channel view. Drag red caps; select a bubble in the table."));
        }
        break;
    case AUTO_CHANNEL:
        choose_automatic_channel(a);
        break;
    case CLEAR_CHANNEL:
        push(a);
        memset(&p->state.channel, 0, sizeof(p->state.channel));
        memset(&p->state.region, 0, sizeof(p->state.region));
        p->state.count = p->state.reviewed = p->state.partial_count = 0;
        a->selected = -1;
        a->mode = CHANNEL;
        a->point_count = a->rubber = 0;
        a->view = 0;
        make_strip(p);
        rebuild(a, 1);
        status(a, T("Область снята. Выделите прямоугольник; «Отменить» вернёт прежнюю область.",
                    "Region cleared. Draw a rectangle; Undo restores the previous region."));
        break;
    case SELECT_CHANNEL:
        set_mode(a, CHANNEL);
        break;
    case AUTO_RULER:
        set_mode(a, RULER);
        break;
    case MANUAL_RULER:
        set_mode(a, CALIBRATE);
        break;
    case DETECT:
        a->mode = EDIT;
        a->point_count = 0;
        working(a, T("Распознаю пузырьки…", "Detecting bubbles..."));
        detect(a);
        finished(a);
        break;
    case TRAIN_DETECTOR:
        train_detector(a);
        break;
    case ADD_BUBBLE:
        if (a->mode == ADD)
            action(a, CANCEL);
        else
            set_mode(a, ADD);
        break;
    case DELETE_BUBBLE:
        if (a->selected >= 0) {
            push(a);
            tm_delete_bubble(&p->state, a->selected);
            a->selected = -1;
            rebuild(a, 0);
            status(a, T("Пузырёк удалён. Слаги пересчитаны; отмена возвращает разметку.",
                        "Bubble deleted. Slugs recalculated; Undo restores it."));
        }
        break;
    case REVIEW: {
        char e[256];
        if (!tm_validate(&p->state, e, sizeof(e))) {
            status(a, e);
            break;
        }
        push(a);
        p->state.reviewed = !p->state.reviewed;
        status(a, p->state.reviewed
                      ? T("Фото отмечено как проверенное. Теперь можно сохранить Excel.",
                          "Photo marked reviewed. You can now export Excel.")
                      : T("Отметка проверки снята.", "Review mark cleared."));
        break;
    }
    case SAVE_PROJECT:
        if (tm_choose_file(path, sizeof(path), 1, "project")) {
            if (tm_save_project(path, a->photos, a->count)) {
                snprintf(a->project_path, TM_PATH, "%s", path);
                status(a, T("Проект сохранён.", "Project saved."));
            } else
                status(a, T("Не удалось сохранить проект. Выберите другую папку.",
                            "Cannot save project. Choose another folder."));
        }
#ifdef _WIN32
        else
            dialog_cancelled(a);
#else
        else {
            if (tm_save_project("TaylorMeter_session.tmc", a->photos, a->count))
                status(a, "Saved TaylorMeter_session.tmc");
        }
#endif
        break;
    case EXPORT:
        if (tm_create_export_path(path, sizeof(path))) {
            working(a, T("Сохраняю результаты в saves…", "Saving results to saves..."));
            save_outputs(a, path);
            finished(a);
        } else status(a, T("Не удалось создать saves. Перенесите программу в папку с правом записи.",
                           "Cannot create saves. Move the app to a writable folder."));
        break;
    case UNDO_EDIT:
    case REDO_EDIT: {
        int index, old_index = a->index, old_view = a->view, old_w = a->display_w,
                   old_h = a->display_h, adding = a->mode == ADD;
        TM_Rect old_region = p ? p->state.region : (TM_Rect){0};
        int entry = id == UNDO_EDIT ? a->history.cursor-1 : a->history.cursor;
        int target = a->history.entries[entry].photo_index;
        TM_State *target_state = &a->photos[target].state;
        double prior_flow[2]; int prior_valid = target_state->flow_valid;
        memcpy(prior_flow, target_state->flow, sizeof(prior_flow));
        int changed = id == UNDO_EDIT ? tm_history_undo(&a->history, a->photos, a->count, &index)
                                      : tm_history_redo(&a->history, a->photos, a->count, &index);
        if (!changed)
            break;
        if (index != old_index || !photo(a)) switch_photo(a, index);
        p = photo(a);
        if (!p) { rebuild(a, 0); status(a, T("Закрытие фото возвращено.", "Photo closure restored.")); break; }
        target_state = &a->photos[target].state;
        if (target_state->flow_valid != prior_valid || memcmp(prior_flow, target_state->flow, sizeof(prior_flow))) {
            a->default_flow_valid = target_state->flow_valid;
            memcpy(a->default_flow, target_state->flow, sizeof(a->default_flow));
        }
        a->selected = -1;
        a->mode = p->state.channel.valid ? (adding && index == old_index ? ADD : EDIT) : CHANNEL;
        a->point_count = a->rubber = 0;
        make_strip(p);
        if (memcmp(&old_region, &p->state.region, sizeof(old_region))) {
            a->view = 0;
            a->mode = p->state.channel.valid ? EDIT : CHANNEL;
        }
        rebuild(a, 0);
        if (old_index != index || old_view != a->view || old_w != a->display_w ||
            old_h != a->display_h)
            fit(a);
        snprintf(path, sizeof(path),
                 id == UNDO_EDIT ? T("Изменение отменено: фото %d. Можно повторить Ctrl+Y.",
                                     "Edit undone: photo %d. Ctrl+Y redoes it.")
                                 : T("Изменение возвращено: фото %d.", "Edit redone: photo %d."),
                 index + 1);
        status(a, path);
        break;
    }
    case FIT_VIEW:
        fit(a);
        status(a, T("Изображение показано целиком.", "Entire image fitted to view."));
        break;
    case ZOOM_IN:
    case ZOOM_OUT: {
        double x = a->panx + VW / (2 * a->zoom), y = a->pany + VH / (2 * a->zoom);
        a->zoom = fmax(.02, fmin(40, a->zoom * (id == ZOOM_IN ? 1.25 : .8)));
        a->panx = x - VW / (2 * a->zoom);
        a->pany = y - VH / (2 * a->zoom);
        a->dirty = 1;
        break;
    }
    case LABELS:
        a->labels = !a->labels;
        rebuild(a, 0);
        break;
    case SENS_DOWN:
    case SENS_UP:
        push(a);
        p->state.sensitivity = fmax(0, fmin(100, p->state.sensitivity + (id == SENS_UP ? 5 : -5)));
        status(a, T("Чувствительность изменена. Нажмите «Распознать пузырьки» для применения.",
                    "Sensitivity changed. Click Detect bubbles to apply."));
        break;
    case TABLE_UP:
    case TABLE_DOWN:
        a->table_offset += id == TABLE_UP ? -TABLE_ROWS : TABLE_ROWS;
        if (a->table_offset < 0)
            a->table_offset = 0;
        if (a->table_offset >= p->state.count)
            a->table_offset = p->state.count > 0 ? p->state.count - 1 : 0;
        a->dirty = 1;
        break;
    }
}
static void click_point(App *a, TM_Point q) {
    TM_Photo *p = photo(a);
    if (!p)
        return;
    if (a->mode == CALIBRATE) {
        a->points[a->point_count++] = q;
        if (a->point_count == 2) {
            a->mode = DISTANCE;
            a->input[0] = 0;
            status(a, T("Введите расстояние в мм, Enter. Малое деление: 1 мм, сантиметр: 10 мм.",
                        "Enter distance in mm, then Enter. Small tick: 1 mm; centimetre: 10 mm."));
        }
    } else if (a->mode == ADD) {
        int sw, sh, st;
        cvb_gray(p->strip, &sw, &sh, &st);
        double pos = q.x * tm_channel_length(&p->state.channel) / (sw - 1);
        if (pos < 0 || pos > tm_channel_length(&p->state.channel) || q.y < 80 || q.y > 220) {
            status(a, T("Выберите торец внутри полосы канала. Esc — завершить добавление.",
                        "Click a cap inside the channel strip. Esc finishes adding."));
            return;
        }
        a->points[a->point_count++] = (TM_Point){pos, 0};
        if (a->point_count == 2) {
            double l = fmin(a->points[0].x, pos), r = fmax(a->points[0].x, pos);
            push(a);
            int index = tm_add_bubble(&p->state, l, r, TM_MANUAL, 1);
            a->point_count = 0;
            if (index < 0)
                status(a, T("Пара пересекает другую или слишком короткая. Укажите два торца заново; "
                            "Esc — выход.",
                            "Pair overlaps another or is too short. Try two caps again; Esc exits."));
            else {
                a->selected = index;
                a->table_offset = (index / TABLE_ROWS) * TABLE_ROWS;
                rebuild(a, 0);
                status(a, T("Пузырёк добавлен. Сразу выбирайте следующую пару; Esc или «Завершить» — выход.",
                            "Bubble added. Click the next pair; Esc or Finish exits."));
            }
        }
    }
    a->dirty = 1;
}
static void mouse(int event, int x, int y, int flags, void *ctx) {
    App *a = (App *)ctx;
    TM_Photo *p = photo(a);
    a->mousex = x;
    a->mousey = y;
    if (a->busy) return;
    if (a->mode == FLOW) {
        if (event == 1) {
            if (y >= 310 && y < 344) {
                if (x >= 240 && x < 420) a->flow_field = 0;
                if (x >= 465 && x < 645) a->flow_field = 1;
            }
            if (y >= 370 && y < 404) {
                if (x >= 355 && x < 465) action(a, FLOW_OK);
                if (x >= 480 && x < 590) action(a, FLOW_CANCEL);
            }
            a->dirty = 1;
        }
        return;
    }
    if (event == 0 || event == 14)
        update_measure_hover(a);
    if (event == 14)
        return;
    if (event == 13) {
        if (a->rubber || a->drag) {
            rollback_edit(a);
            if (p)
                make_strip(p);
            rebuild(a, 0);
            status(a, T("Незавершённое перетаскивание отменено.", "Unfinished drag cancelled."));
        }
        return;
    }
    if (a->rubber && p) {
        if (event == 0 || event == 4) {
            TM_Point next = image_point(a, p, x, y);
            if (next.x != a->rectangle_end.x || next.y != a->rectangle_end.y) {
                a->rectangle_end = next;
                a->dirty = 1;
            }
            if (event == 4)
                finish_rectangle(a);
        }
        return;
    }
#ifndef _WIN32
    if (event == 0) {
        int hover = -1;
        for (size_t i = 0; i < sizeof(buttons) / sizeof(buttons[0]); i++) {
            const Button *b = buttons + i;
            if (button_visible(a, b->id) && x >= b->x && x < b->x + b->w && y >= b->y &&
                y < b->y + b->h)
                hover = b->id;
        }
        if (hover != a->hover) {
            a->hover = hover;
            a->dirty = 1;
        }
    }
#endif
    if (event == 4 || event == 5) {
        a->drag = 0;
        a->panning = 0;
    }
    if (event == 10) {
        int delta = (int)(short)((flags >> 16) & 0xffff);
        if (x >= VX && x < VX + VW && y >= TABLE_Y && y < TABLE_Y + TABLE_ROWS * ROW_H) {
            a->table_offset += delta > 0 ? -3 : 3;
            if (a->table_offset < 0)
                a->table_offset = 0;
            if (p && a->table_offset > p->state.count - TABLE_ROWS)
                a->table_offset = p->state.count > TABLE_ROWS ? p->state.count - TABLE_ROWS : 0;
            a->dirty = 1;
            return;
        }
        if (x < VX || x >= VX + VW || y < VY || y >= VY + VH)
            return;
        double qx = (x - VX) / a->zoom + a->panx, qy = (y - VY) / a->zoom + a->pany,
               z = a->zoom * (delta > 0 ? 1.25 : 0.8);
        if (z < 0.02)
            z = 0.02;
        if (z > 40)
            z = 40;
        a->zoom = z;
        a->panx = qx - (x - VX) / z;
        a->pany = qy - (y - VY) / z;
        a->dirty = 1;
        return;
    }
    if (event == 1) {
        for (size_t i = 0; i < sizeof(buttons) / sizeof(buttons[0]); i++) {
            const Button *b = buttons + i;
            if (button_visible(a, b->id) && x >= b->x && x < b->x + b->w && y >= b->y &&
                y < b->y + b->h) {
                action(a, b->id);
                return;
            }
        }
        if (x >= VX && x < VX + VW && y >= TABLE_Y && y < TABLE_Y + TABLE_ROWS * ROW_H && p &&
            p->image && p->strip && a->mode == EDIT) {
            int i = a->table_offset + (y - TABLE_Y) / ROW_H;
            if (i < p->state.count) {
                a->selected = i;
                if (!a->view && p->state.channel.valid) {
                    a->view = 1;
                    rebuild(a, 1);
                }
                if (a->view) {
                    int w, h, st;
                    cvb_gray(p->strip, &w, &h, &st);
                    double center = (p->state.bubbles[i].left + p->state.bubbles[i].right) * .5 *
                                    (w - 1) / tm_channel_length(&p->state.channel);
                    a->panx = center - VW / (2 * a->zoom);
                }
                a->dirty = 1;
                status(a, T("Пузырёк выбран. Можно перетащить торец или удалить выбранную пару.",
                            "Bubble selected. Drag a cap or delete the selected pair."));
            }
            return;
        }
    }
    if (a->help)
        return;
    if (!p || !p->image || !a->display || x < VX || x >= VX + VW || y < VY || y >= VY + VH)
        return;
    TM_Point q = {(x - VX) / a->zoom + a->panx, (y - VY) / a->zoom + a->pany};
    if (event == 1 && (a->mode == CHANNEL || a->mode == RULER)) {
        /* A fitted image edge can lie between two screen pixels. Accept the
           nearest pixel; image_point clamps it to the exact image boundary. */
        double edge_epsilon = .5 / a->zoom + 1e-9;
        if (q.x < -edge_epsilon || q.y < -edge_epsilon || q.x >= p->width + edge_epsilon ||
            q.y >= p->height + edge_epsilon) {
            status(a, T("Начните выделение внутри фотографии.",
                        "Start the rectangle inside the photograph."));
            return;
        }
        a->rectangle_start = a->rectangle_end = image_point(a, p, x, y);
        a->rubber = 1;
        a->panning = a->drag = 0;
        a->dirty = 1;
        return;
    }
    if (event == 1 && a->mode != EDIT) {
        if (a->mode != DISTANCE)
            click_point(a, q);
        return;
    }
    if (event == 1 && a->mode == EDIT && p->state.channel.valid) {
        double best = 10;
        int bi = -1, side = 0;
        for (int i = 0; i < p->state.count; i++)
            for (int k = 0; k < 2; k++) {
                double s = k ? p->state.bubbles[i].right : p->state.bubbles[i].left, dist;
                if (a->view) {
                    int sw, sh, st;
                    cvb_gray(p->strip, &sw, &sh, &st);
                    dist =
                        fabs(q.x - s * (sw - 1) / tm_channel_length(&p->state.channel)) * a->zoom;
                } else {
                    double len = tm_channel_length(&p->state.channel),
                           ux = (p->state.channel.b.x - p->state.channel.a.x) / len,
                           uy = (p->state.channel.b.y - p->state.channel.a.y) / len;
                    double along = (q.x - p->state.channel.a.x) * ux +
                                   (q.y - p->state.channel.a.y) * uy,
                           across = -(q.x - p->state.channel.a.x) * uy +
                                    (q.y - p->state.channel.a.y) * ux;
                    dist = fabs(across) <= p->state.channel.half_width + 8 / a->zoom
                               ? fabs(along - s) * a->zoom
                               : 1000;
                }
                if (dist < best) {
                    best = dist;
                    bi = i;
                    side = k;
                }
            }
        if (bi >= 0) {
            a->selected = bi;
            a->side = side;
            a->drag = 1;
            push(a);
            if (bi < a->table_offset || bi >= a->table_offset + TABLE_ROWS)
                a->table_offset = (bi / TABLE_ROWS) * TABLE_ROWS;
            a->dirty = 1;
            return;
        }
    }
    if (event == 1 || event == 2) {
        a->panning = 1;
        a->start_mx = x;
        a->start_my = y;
        a->start_panx = a->panx;
        a->start_pany = a->pany;
    }
    if (event == 0 && a->drag) {
        double pos;
        if (a->view) {
            int sw, sh, st;
            cvb_gray(p->strip, &sw, &sh, &st);
            pos = q.x * tm_channel_length(&p->state.channel) / (sw - 1);
        } else {
            double len = tm_channel_length(&p->state.channel);
            pos = ((q.x - p->state.channel.a.x) * (p->state.channel.b.x - p->state.channel.a.x) +
                   (q.y - p->state.channel.a.y) * (p->state.channel.b.y - p->state.channel.a.y)) /
                  len;
        }
        tm_move_boundary(&p->state, a->selected, a->side, pos);
        rebuild(a, 0);
    } else if (event == 0 && a->panning) {
        a->panx = a->start_panx - (x - a->start_mx) / a->zoom;
        a->pany = a->start_pany - (y - a->start_my) / a->zoom;
        a->dirty = 1;
    }
    if (event == 4 || event == 5) {
        a->drag = 0;
        a->panning = 0;
    }
}
static const char *next_step(App *a) {
    TM_Photo *p = photo(a);
    if (a->mode == CHANNEL)
        return a->rubber ? T("Отпустите мышь для выбора области",
                             "Release the mouse to select the region")
                         : T("Протяните прямоугольник вокруг канала",
                             "Drag a rectangle around the channel");
    if (a->mode == RULER)
        return a->rubber ? T("Отпустите мышь: область линейки", "Release the mouse: ruler region")
                         : T("Протяните область линейки", "Drag a rectangle around the ruler");
    if (a->mode == CALIBRATE)
        return a->point_count ? T("Точка 2/2: второй штрих линейки", "Point 2/2: second ruler tick")
                              : T("Точка 1/2: первый штрих линейки", "Point 1/2: first ruler tick");
    if (a->mode == DISTANCE)
        return T("Введите расстояние между штрихами", "Enter the distance between ticks");
    if (a->mode == ADD)
        return a->point_count ? T("Второй торец; Esc — завершить", "Second cap; Esc to finish")
                              : T("Следующая капля: первый торец; Esc — выход",
                                  "Next bubble: first cap; Esc to finish");
    if (!p)
        return T("Откройте фото или готовый проект", "Open a photo or an existing project");
    if (!p->state.channel.valid)
        return T("Выделите прямоугольник или нажмите «Авто»", "Draw a rectangle or click Auto");
    if (!p->state.calibration.valid)
        return T("Задайте масштаб по линейке", "Set the scale using the ruler");
    if (!p->state.count)
        return T("Распознайте или добавьте пузырьки", "Detect or add bubbles");
    if (!p->state.reviewed)
        return T("Проверьте торцы и отметьте проверку", "Inspect caps and mark them reviewed");
    char reason[256];
    if (!export_ready(a, reason, sizeof(reason)))
        return T("Проверьте остальные фото проекта", "Review the other photos in the project");
    return T("Сохраните Excel и размеченные фото", "Save Excel and annotated photographs");
}
/* Wrap at UTF-8 character boundaries; never split a Cyrillic byte sequence. */
static void wrapped(void *canvas, int x, int y, const char *s, int chars, int height, int color,
                    int max_lines) {
    for (int line = 0; *s && line < max_lines; line++) {
        const char *p = s, *space = NULL;
        int n = 0;
        while (*p && n < chars) {
            if (*p == ' ')
                space = p;
            p++;
            while ((*p & 0xc0) == 0x80)
                p++;
            n++;
        }
        if (*p && space && space > s)
            p = space;
        char text[512];
        size_t bytes = (size_t)(p - s);
        if (bytes >= sizeof(text))
            bytes = sizeof(text) - 1;
        memcpy(text, s, bytes);
        text[bytes] = 0;
        cvb_text(canvas, x, y + line * (height + 5), text, height, color);
        s = p;
        while (*s == ' ')
            s++;
    }
}
static void step_title(void *canvas, int y, const char *label, int done, int active) {
    cvb_circle(canvas, PX + 10, y - 6, 5, done ? GREEN : active ? BLUE : 0x596a80);
    cvb_text(canvas, PX + 26, y, label, 17, done ? GREEN : FG);
}
static void rectangle_overlay(void *canvas, App *a, TM_Point start, TM_Point end, int preview) {
    double left = VX + (fmin(start.x, end.x) - a->panx) * a->zoom;
    double right = VX + (fmax(start.x, end.x) - a->panx) * a->zoom;
    double top = VY + (fmin(start.y, end.y) - a->pany) * a->zoom;
    double bottom = VY + (fmax(start.y, end.y) - a->pany) * a->zoom;
    if (right < VX || left > VX + VW || bottom < VY || top > VY + VH)
        return;
    int x0 = (int)fmax(VX, left), x1 = (int)fmin(VX + VW - 1, right);
    int y0 = (int)fmax(VY, top), y1 = (int)fmin(VY + VH - 1, bottom);
    int color = preview ? GREEN : BLUE;
    cvb_rect(canvas, x0, y0, x1 - x0 + 1, y1 - y0 + 1, 0x101010, 3);
    for (int x = x0; x < x1; x += 12) {
        cvb_line(canvas, x, y0, fmin(x + 6, x1), y0, color, 1);
        cvb_line(canvas, x, y1, fmin(x + 6, x1), y1, color, 1);
    }
    for (int y = y0; y < y1; y += 12) {
        cvb_line(canvas, x0, y, x0, fmin(y + 6, y1), color, 1);
        cvb_line(canvas, x1, y, x1, fmin(y + 6, y1), color, 1);
    }
    if (preview) {
        char size[64];
        snprintf(size, sizeof(size), "%.0f x %.0f px", fabs(end.x - start.x) + 1,
                 fabs(end.y - start.y) + 1);
        cvb_text(canvas, x0 + 8, (int)fmax(VY + 20, y0 - 8), size, 16, GREEN);
    }
}
static void screen_layout(App *a, TM_Overlay *layout) {
    tm_overlay_init(layout, &photo(a)->state.channel, a->view ? a->display_w : 0);
    layout->zoom = a->zoom;
    layout->panx = a->panx;
    layout->pany = a->pany;
}
static void update_measure_hover(App *a) {
    TM_Hover next = {TM_HOVER_NONE, -1};
    TM_Photo *p = photo(a);
    int x = (int)a->mousex, y = (int)a->mousey;
    if (p && a->display && !a->busy && !a->help && !a->drag && !a->panning && !a->rubber &&
        (a->mode == EDIT || (a->mode == ADD && !a->point_count))) {
        if (x >= VX && x < VX + VW && y >= VY && y < VY + VH) {
            TM_Overlay layout;
            screen_layout(a, &layout);
            next = tm_overlay_hit(&p->state, &layout, x - VX, y - VY, 6);
        } else if (y >= TABLE_Y && y < TABLE_Y + TABLE_ROWS * ROW_H) {
            int i = a->table_offset + (y - TABLE_Y) / ROW_H;
            if (i < p->state.count && x >= VX + 64 && x < VX + 240)
                next = (TM_Hover){TM_HOVER_BUBBLE, i};
            else if (i + 1 < p->state.count && x >= VX + 240 && x < VX + 412)
                next = (TM_Hover){TM_HOVER_SLUG, i};
        }
    }
    /* A stable target uses a fixed tooltip anchor: moving inside it does not
       rebuild the large source image or request another identical frame. */
    if (next.kind != a->measure_hover.kind || next.index != a->measure_hover.index) {
        a->measure_hover = next;
        a->dirty = 1;
    }
}
static void draw_measure_hover(void *viewport, App *a) {
    if (!a->measure_hover.kind)
        return;
    TM_State *s = &photo(a)->state;
    TM_Hover hit = a->measure_hover;
    TM_Overlay layout;
    screen_layout(a, &layout);
    tm_overlay_highlight(viewport, s, &layout, hit);
    int slug = hit.kind == TM_HOVER_SLUG, color = slug ? TM_SLUG_COLOR : TM_DROP_COLOR;
    int small = slug && s->bubbles[hit.index + 1].left - s->bubbles[hit.index].right <= 1;
    int uncertain = !slug && (s->bubbles[hit.index].flags & TM_UNCERTAIN);
    int x = VW - 342, y = 8, height = small || uncertain ? 82 : 62;
    cvb_rect(viewport, x, y, 330, height, 0x172638, -1);
    cvb_rect(viewport, x, y, 330, height, color, 1);
    char text[160], value[80];
    snprintf(text, sizeof(text), slug ? T("Слаг №%d", "Slug #%d") : T("Капля №%d", "Bubble #%d"),
             hit.index + 1);
    cvb_text(viewport, x + 12, y + 22, text, 17, color);
    tm_overlay_value(s, hit, value, sizeof(value));
    snprintf(text, sizeof(text), T("Длина: %s", "Length: %s"), value);
    cvb_text(viewport, x + 12, y + 47, text, 18, FG);
    if (small)
        cvb_text(viewport, x + 12, y + 70,
                 T("~ Не больше 1 px; проверьте торцы", "~ At most 1 px; inspect the caps"), 13, color);
    else if (uncertain)
        cvb_text(viewport, x + 12, y + 70,
                 T("Проверьте найденные торцы", "Inspect the detected caps"), 13, color);
}
static void draw(App *a) {
    void *canvas = cvb_create(CW, CH, BG);
    if (!canvas)
        return;
    TM_Photo *p = photo(a);
    TM_State *s = p ? &p->state : NULL;
    update_measure_hover(a);
    char text[512];
    cvb_text(canvas, VX, 29, "TaylorMeter", 24, FG);
    if (p) {
        int ordinal = 0, total = 0;
        for (int i = 0; i < a->count; i++) if (!a->photos[i].state.excluded) {
            total++; if (i <= a->index) ordinal++;
        }
        snprintf(text, sizeof(text), T("Фото %d / %d", "Photo %d / %d"), ordinal, total);
        cvb_text(canvas, PX + 69, 73, text, 18, FG);
    }
    cvb_rect(canvas, PX - 4, 94, PW + 8, 646, 0x1c293b, -1);
    if (a->display) {
        void *viewport = cvb_create(VW, VH, BG);
        if (viewport) {
            cvb_blit(viewport, a->display, a->zoom, a->panx, a->pany, 0, 0, VW, VH);
            draw_measure_hover(viewport, a);
            cvb_blit(canvas, viewport, 1, 0, 0, VX, VY, VW, VH);
            cvb_free(viewport);
        }
    } else {
        cvb_text(canvas, 66, 264, T("Начните с фотографии", "Start with a photograph"), 28, FG);
        cvb_text(
            canvas, 66, 303,
            T("1. Откройте фото.  2. Выберите канал.", "1. Open a photo.  2. Select the channel."),
            20, BLUE);
        cvb_text(canvas, 66, 336,
                 T("3. Задайте масштаб.  4. Проверьте торцы.",
                   "3. Set the scale.  4. Inspect the caps."),
                 20, BLUE);
        cvb_text(canvas, 66, 378,
                 T("Готовую работу можно открыть кнопкой «Открыть проект».",
                   "Use Open project to continue saved measurements."),
                 17, FG);
    }
    if (s && s->region.valid && !a->view && a->mode != DISTANCE) {
        TM_Rect r = s->region;
        rectangle_overlay(canvas, a, (TM_Point){r.x, r.y}, (TM_Point){r.x + r.w - 1, r.y + r.h - 1},
                          0);
    }
    if (a->rubber)
        rectangle_overlay(canvas, a, a->rectangle_start, a->rectangle_end, 1);
    cvb_rect(canvas, VX, VY, VW, VH, 0x3b5068, 1);
    if (p) {
        snprintf(text, sizeof(text), "%.0f%%", a->zoom * 100);
        cvb_text(canvas, 666, 113, text, 15, BLUE);
    }
    step_title(canvas, 113, T("1. Область канала", "1. Channel region"), s && s->channel.valid,
               a->mode == CHANNEL);
    if (s && s->region.valid)
        cvb_text(canvas, PX + 158, 181,
                 s->region.automatic ? T("Автовыделение", "Automatic region")
                                     : T("Ручная область", "Manual region"),
                 14, BLUE);
    step_title(canvas, 211, T("2. Масштаб по линейке", "2. Ruler calibration"),
               s && s->calibration.valid,
               a->mode == RULER || a->mode == CALIBRATE || a->mode == DISTANCE);
    cvb_text(canvas, PX + 4, 268,
             T("Малое деление: 1 мм. Цифры: 10 мм.", "Small tick: 1 mm. Numbers: 10 mm."), 13,
             BLUE);
    step_title(canvas, 294, T("3. Границы пузырьков", "3. Bubble boundaries"), s && s->count,
               a->mode == ADD);
    if (s) {
        snprintf(text, sizeof(text), T("Чувствительность: %.0f", "Sensitivity: %.0f"),
                 s->sensitivity);
        cvb_text(canvas, PX + 4, 362, text, 15, FG);
    }
    step_title(canvas, 455, T("4. Проверка и сохранение", "4. Review and export"), s && s->reviewed,
               0);
    cvb_text(canvas, PX + 4, 555, T("РЕЗУЛЬТАТ ТЕКУЩЕГО ФОТО", "CURRENT PHOTO RESULTS"), 14, BLUE);
    if (s) {
        snprintf(text, sizeof(text), T("Пузырьков: %d   Слагов: %d", "Bubbles: %d   Slugs: %d"),
                 s->count, s->count > 0 ? s->count - 1 : 0);
        cvb_text(canvas, PX + 4, 578, text, 18, FG);
        if (s->calibration.valid) {
            snprintf(text, sizeof(text), T("Масштаб: %.6f мм/px", "Scale: %.6f mm/px"),
                     s->calibration.mm_per_px);
            cvb_text(canvas, PX + 4, 601, text, 15, BLUE);
            double bubbles = 0, slugs = 0;
            for (int i = 0; i < s->count; i++) {
                bubbles += tm_bubble_mm(s, i);
                if (i + 1 < s->count)
                    slugs += tm_slug_mm(s, i);
            }
            if (s->count) {
                snprintf(text, sizeof(text), T("Средний пузырёк: %.4f мм", "Mean bubble: %.4f mm"),
                         bubbles / s->count);
                cvb_text(canvas, PX + 4, 626, text, 16, RED);
            }
            if (s->count > 1) {
                snprintf(text, sizeof(text), T("Средний слаг: %.4f мм", "Mean slug: %.4f mm"),
                         slugs / (s->count - 1));
                cvb_text(canvas, PX + 4, 650, text, 16, TM_SLUG_COLOR);
            }
        } else
            cvb_text(canvas, PX + 4, 601,
                     T("Задайте масштаб для длины в мм", "Set a scale to measure in mm"), 15, BLUE);
    }
    cvb_rect(canvas, PX + 2, 670, PW - 4, 67, 0x253d57, -1);
    cvb_text(canvas, PX + 12, 689, T("РАСХОД ДЛЯ ЭТОГО ФОТО", "FLOW FOR THIS PHOTO"), 13, BLUE);
    if (p) wrapped(canvas, VX, 576, tm_basename(p->path), 75, 13, BLUE, 1);
    cvb_text(canvas, VX, 593,
             T("Измерения: ~ у слага означает не больше 1 пикселя",
               "Measurements: ~ marks a gap no larger than one pixel"),
             14, FG);
    cvb_rect(canvas, VX, TABLE_Y - 25, VW, TABLE_ROWS * ROW_H + 25, 0x1c293b, -1);
    cvb_text(canvas, VX + 10, TABLE_Y - 8, T("№", "#"), 14, BLUE);
    cvb_text(canvas, VX + 64, TABLE_Y - 8,
             s && s->calibration.valid ? T("Пузырёк, мм", "Bubble, mm")
                                       : T("Пузырёк, px", "Bubble, px"),
             14, RED);
    cvb_text(canvas, VX + 240, TABLE_Y - 8,
             s && s->calibration.valid ? T("Слаг, мм", "Slug, mm") : T("Слаг, px", "Slug, px"), 14,
             TM_SLUG_COLOR);
    cvb_text(canvas, VX + 412, TABLE_Y - 8, T("Левый торец, px", "Left cap, px"), 14, BLUE);
    cvb_text(canvas, VX + 560, TABLE_Y - 8, T("Правый торец, px", "Right cap, px"), 14, BLUE);
    cvb_text(canvas, VX + 724, TABLE_Y - 8, T("Проверка", "Review"), 14, BLUE);
    if (s) {
        for (int k = 0; k < TABLE_ROWS; k++) {
            int i = a->table_offset + k;
            if (i >= s->count)
                break;
            int y = TABLE_Y + k * ROW_H;
            TM_Bubble *b = s->bubbles + i;
            if (i == a->selected)
                cvb_rect(canvas, VX, y, VW, ROW_H, 0x305773, -1);
            else if (k % 2)
                cvb_rect(canvas, VX, y, VW, ROW_H, 0x223146, -1);
            if (i == a->measure_hover.index && a->measure_hover.kind)
                cvb_rect(canvas, VX + (a->measure_hover.kind == TM_HOVER_SLUG ? 232 : 56), y,
                         176, ROW_H,
                         a->measure_hover.kind == TM_HOVER_SLUG ? 0x254a73 : 0x65353d, -1);
            snprintf(text, sizeof(text), "%d", i + 1);
            cvb_text(canvas, VX + 10, y + 16, text, 15, FG);
            snprintf(text, sizeof(text), "%.4f",
                     s->calibration.valid ? tm_bubble_mm(s, i) : b->right - b->left);
            cvb_text(canvas, VX + 64, y + 16, text, 15, RED);
            if (i + 1 < s->count) {
                snprintf(
                    text, sizeof(text), "%s%.6f", s->bubbles[i + 1].left - b->right <= 1 ? "~" : "",
                    s->calibration.valid ? tm_slug_mm(s, i) : s->bubbles[i + 1].left - b->right);
                cvb_text(canvas, VX + 240, y + 16, text, 15, TM_SLUG_COLOR);
            } else
                cvb_text(canvas, VX + 240, y + 16, "-", 15, TM_SLUG_COLOR);
            snprintf(text, sizeof(text), "%.2f", b->left);
            cvb_text(canvas, VX + 412, y + 16, text, 15, FG);
            snprintf(text, sizeof(text), "%.2f", b->right);
            cvb_text(canvas, VX + 560, y + 16, text, 15, FG);
            cvb_text(canvas, VX + 724, y + 16,
                     b->flags & TM_UNCERTAIN ? T("Проверьте", "Inspect")
                     : b->flags & TM_MANUAL  ? T("Вручную", "Manual")
                                             : T("Авто", "Auto"),
                     14, b->flags & TM_UNCERTAIN ? BLUE : FG);
        }
        for (int i = 0; i < a->point_count; i++) {
            double x = a->points[i].x, y = a->points[i].y;
            if (a->mode == ADD) {
                int sw, sh, st;
                cvb_gray(p->strip, &sw, &sh, &st);
                x *= (sw - 1) / tm_channel_length(&s->channel);
                y = 150;
            }
            int xx = (int)(VX + (x - a->panx) * a->zoom), yy = (int)(VY + (y - a->pany) * a->zoom);
            cvb_circle(canvas, xx, yy, 5, GREEN);
            snprintf(text, sizeof(text), "%d", i + 1);
            cvb_text(canvas, xx + 8, yy - 7, text, 17, GREEN);
        }
        if (a->mode != EDIT && a->mode != DISTANCE && a->mode != FLOW && !a->rubber) {
            cvb_rect(canvas, VX + 12, VY + 12, 590, 34, 0x203d56, -1);
            cvb_text(canvas, VX + 22, VY + 36, next_step(a), 18, FG);
        }
    }
    if (a->mode == DISTANCE && !a->help) {
        cvb_rect(canvas, 200, 246, 510, 142, 0x203d56, -1);
        cvb_rect(canvas, 200, 246, 510, 142, BLUE, 1);
        cvb_text(canvas, 222, 278,
                 T("Расстояние между штрихами, мм", "Distance between ruler ticks, mm"), 22, FG);
        cvb_text(canvas, 222, 371,
                 T("Малое деление: 1 мм; сантиметр: 10 мм", "Small tick: 1 mm; centimetre: 10 mm"),
                 16, BLUE);
#ifndef _WIN32
        cvb_rect(canvas, 222, 312, 236, 34, 0x131a25, -1);
        cvb_text(canvas, 230, 336, a->input[0] ? a->input : "_", 22, GREEN);
#endif
    }
    if (a->mode == FLOW && !a->help) {
        cvb_rect(canvas, 210, 245, 490, 182, 0x203d56, -1);
        cvb_rect(canvas, 210, 245, 490, 182, BLUE, 1);
        cvb_text(canvas, 230, 277, T("Расход", "Flow"), 22, FG);
        cvb_text(canvas, 240, 302, T("Значение 1", "Value 1"), 15, FG);
        cvb_text(canvas, 465, 302, T("Значение 2", "Value 2"), 15, FG);
#ifndef _WIN32
        for (int j = 0; j < 2; j++) {
            int x = j ? 465 : 240;
            cvb_rect(canvas, x, 310, 180, 34, 0x131a25, -1);
            cvb_rect(canvas, x, 310, 180, 34, a->flow_field == j ? GREEN : BLUE, 1);
            cvb_text(canvas, x+6, 335, a->flow_input[j][0] ? a->flow_input[j] : "_", 20, FG);
        }
#endif
    }
    if (a->help) {
        cvb_rect(canvas, 30, 134, 860, 417, 0x203349, -1);
        const char *lines[] = {
            T("Канал выделяется автоматически. Проверьте рамку на фотографии.",
              "The channel is selected automatically. Inspect the rectangle."),
            T("Прямоугольник: зажать левую кнопку, протянуть и отпустить.",
              "Rectangle: hold the left button, drag, then release."),
            T("Авто по линейке: прямоугольник минимум с 12 малыми делениями.",
              "Auto ruler: rectangle around at least 12 small divisions."),
            T("Вручную: 2 штриха, расстояние в мм, кнопка «Применить».",
              "Manual scale: two ticks, distance in mm, then Apply."),
            T("Малое деление: 1 мм. Соседние сантиметровые цифры: 10 мм.",
              "Small division: 1 mm. Adjacent centimetre numbers: 10 mm."),
            T("Колесо увеличивает, перетаскивание пустого места перемещает.",
              "Wheel zooms; drag empty space to pan."),
            T("Перетаскивайте красные торцы; таблица выбирает пузырёк.",
              "Drag red caps; click a table row to select a bubble."),
            T("Добавляйте пары подряд. Esc / «Завершить» — выход из добавления.",
              "Add pairs continuously. Esc / Finish ends adding."),
            T("N пузырьков дают все N-1 слагов, включая нулевые и дробные.",
              "N bubbles always give all N-1 slugs, including zero and fractional gaps."),
            T("Проверьте торцы и масштаб каждого фото, отметьте проверку.",
              "Inspect caps and scale for each photo, then mark reviewed."),
            T("Экспорт сохраняет Excel, размеченные фото, канал и проект.",
              "Export saves Excel, annotated photos, channel crops and a project."),
            T("Отмена: Ctrl+Z. Повтор: Ctrl+Y. Сброс незавершённого ввода: Esc.",
              "Undo: Ctrl+Z. Redo: Ctrl+Y. Cancel unfinished input: Esc."),
            T("Капли — красные вверх, слаги — синие вниз. Наведите для длины.",
              "Bubbles: red, above. Slugs: blue, below. Hover to see the length."),
            T("Закройте справку этой же кнопкой или нажмите H / Esc.",
              "Close help with the same button, or press H / Esc.")};
        for (size_t i = 0; i < sizeof(lines) / sizeof(lines[0]); i++)
            cvb_text(canvas, 48, 161 + (int)i * 27, lines[i], 16, FG);
    }
    for (size_t i = 0; i < sizeof(buttons) / sizeof(buttons[0]); i++) {
        const Button *b = buttons + i;
        int visible = button_visible(a, b->id), enabled = button_enabled(a, b->id);
        int active = (b->id == PHOTO_VIEW && p && !a->view) || (b->id == CHANNEL_VIEW && a->view) ||
                     (b->id == REVIEW && s && s->reviewed) || (b->id == LABELS && a->labels) ||
                     (b->id == SELECT_CHANNEL && a->mode == CHANNEL) ||
                     (b->id == AUTO_RULER && a->mode == RULER) ||
                     (b->id == MANUAL_RULER && (a->mode == CALIBRATE || a->mode == DISTANCE)) ||
                     (b->id == ADD_BUBBLE && a->mode == ADD);
        const char *label = b->english ? T(b->label, b->english) : b->label;
        char flow_label[96];
        if (b->id == SET_FLOW && s && s->flow_valid) {
            snprintf(flow_label, sizeof(flow_label), T("%.8g - %.8g   Изменить", "%.8g - %.8g   Edit"), s->flow[0], s->flow[1]);
            label = flow_label;
        }
        if (b->id == ADD_BUBBLE && a->mode == ADD)
            label = T("Завершить добавление", "Finish adding");
        if (b->id == HELP && a->help)
            label = T("Закрыть", "Close");
        if (b->id == REVIEW && s && s->reviewed)
            label = T("Проверено: снять отметку", "Reviewed: clear mark");
        tmui_button(b->id, b->x, b->y, b->w, b->h, label, visible, enabled, active);
#ifndef _WIN32
        if (!visible)
            continue;
        int color = !enabled            ? 0x202a38
                    : active            ? 0x225575
                    : a->hover == b->id ? 0x3a5673
                    : b->id == EXPORT   ? 0x216451
                                        : 0x2b3e54;
        cvb_rect(canvas, b->x, b->y, b->w, b->h, color, -1);
        cvb_rect(canvas, b->x, b->y, b->w, b->h, enabled ? 0x557493 : 0x334355, 1);
        cvb_text(canvas, b->x + 8, b->y + b->h / 2 + 6, label, 15, enabled ? FG : 0x8290a0);
#endif
    }
    tmui_textfield(1, a->mode == FLOW && !a->help, 240, 310, 180, 34, a->flow_input[0]);
    tmui_textfield(2, a->mode == FLOW && !a->help, 465, 310, 180, 34, a->flow_input[1]);
    tmui_input(a->mode == DISTANCE && !a->help, 222, 312, 236, 34, a->input);
    cvb_rect(canvas, 0, 756, CW, 44, a->busy ? 0x24465e : 0x213047, -1);
    wrapped(canvas, VX, 774, a->status, 142, 14, FG, 2);
    tmui_show(canvas);
    cvb_free(canvas);
    a->dirty = 0;
}
int tm_run_gui(int argc, char **argv) {
    fprintf(stderr, "Allocating application state\n");
    App *a = (App *)calloc(1, sizeof(App));
    if (!a)
        return 1;
    a->photos = (TM_Photo *)calloc(TM_MAX_PHOTOS, sizeof(TM_Photo));
    a->pending = (TM_State *)calloc(1, sizeof(TM_State));
    if (!a->photos || !a->pending || !tm_history_init(&a->history, HISTORY_LIMIT)) {
        free(a->photos);
        free(a->pending);
        tm_history_free(&a->history);
        free(a);
        return 1;
    }
    a->labels = 1;
    a->selected = -1;
    a->hover = -1;
    a->measure_hover = (TM_Hover){TM_HOVER_NONE, -1};
    a->dirty = 1;
    a->zoom = 1;
    status(a, T("Нажмите «Открыть фото» или «Открыть проект». Подсказки находятся справа.",
                "Click Open photo or Open project. Follow the steps on the right."));
    fprintf(stderr, "Creating application window\n");
    if (!tmui_open(TITLE, CW, CH)) {
        fprintf(stderr, "%s\n", cvb_error());
        release_photos(a);
        free(a->photos);
        free(a->pending);
        tm_history_free(&a->history);
        free(a);
        return 1;
    }
    fprintf(stderr, "Window ready; startup animation\n");
    if (!tmui_splash() || tmui_choose_language() < 0) {
        tmui_close(); free(a->photos); free(a->pending); tm_history_free(&a->history); free(a);
        return 0;
    }
    status(a, T("Откройте фото или проект. Расход задаётся после открытия фото.",
                "Open a photo or project. Set flow after opening a photo."));
    draw(a);
    for (int i = 1; i < argc; i++) {
        const char *ext = strrchr(argv[i], '.');
        if (ext && !strcmp(ext, ".tmc"))
            load_project(a, argv[i]);
        else
            open_photo(a, argv[i]);
    }
    int run = 1;
    while (run) {
        commit_edit(a);
        if (a->dirty)
            draw(a);
        TMUI_Event event;
        int received = tmui_poll(&event, 30);
        if (!tmui_alive())
            break;
        if (!received)
            continue;
        if (event.type == TMUI_MOUSE) {
            mouse(event.code, event.x, event.y, event.flags, a);
            continue;
        }
        if (event.type == TMUI_COMMAND) {
            action(a, event.code);
            continue;
        }
        if (event.type == TMUI_INPUT) {
            if (a->mode == FLOW && event.code >= 1 && event.code <= 2) {
                snprintf(a->flow_input[event.code-1], 32, "%s", event.text);
                a->flow_field = event.code-1;
                a->dirty = 1;
            } else if (a->mode == DISTANCE) {
                snprintf(a->input, sizeof(a->input), "%s", event.text);
                a->dirty = 1;
            }
            continue;
        }
        int key = event.code;
        if (key > 255 && key != 65535 && key != 3014656)
            continue;
        int k = key & 255;
        if (a->mode == FLOW) {
            char *field = a->flow_input[a->flow_field];
            size_t n = strlen(field);
            if (k == 13 || k == 10) action(a, FLOW_OK);
            else if (k == 27) action(a, FLOW_CANCEL);
            else if (k == 9) { a->flow_field = 1-a->flow_field; a->dirty = 1; }
            else if (k == 8 && n) { field[n-1] = 0; a->dirty = 1; }
            else if (((k >= '0' && k <= '9') || k == '.' || k == ',') && n < 30) {
                field[n] = (char)k; field[n+1] = 0; a->dirty = 1;
            }
            continue;
        }
        if (a->mode == DISTANCE) {
            size_t n = strlen(a->input);
            if (k == 13 || k == 10) {
                action(a, DISTANCE_OK);
            } else if (k == 27) {
                action(a, CANCEL);
            } else if (k == 8 && n) {
                a->input[n - 1] = 0;
                a->dirty = 1;
            } else if (((k >= '0' && k <= '9') || k == '.' || k == ',') &&
                       n < sizeof(a->input) - 1) {
                a->input[n] = (char)(k == ',' ? '.' : k);
                a->input[n + 1] = 0;
                a->dirty = 1;
            }
            continue;
        }
        if (k >= 'A' && k <= 'Z')
            k += 32;
        if (key == 3014656 || key == 65535) {
            action(a, DELETE_BUBBLE);
            continue;
        }
        switch (k) {
        case 'q':
            run = 0;
            break;
        case 27:
            if (a->mode != EDIT || a->help)
                action(a, CANCEL);
            break;
        case 'o':
            action(a, OPEN);
            break;
        case 'c':
            action(a, SELECT_CHANNEL);
            break;
        case 'r':
            action(a, AUTO_RULER);
            break;
        case 'm':
            action(a, MANUAL_RULER);
            break;
        case 'd':
            action(a, DETECT);
            break;
        case 'a':
            action(a, ADD_BUBBLE);
            break;
        case 'v':
            action(a, CHANNEL_VIEW);
            break;
        case 'f':
            action(a, PHOTO_VIEW);
            break;
        case 'e':
            action(a, EXPORT);
            break;
        case 's':
            action(a, SAVE_PROJECT);
            break;
        case 'p':
            action(a, OPEN_PROJECT);
            break;
        case '0':
            action(a, FIT_VIEW);
            break;
        case 'l':
            action(a, LABELS);
            break;
        case 'h':
            action(a, HELP);
            break;
        case '[':
            action(a, SENS_DOWN);
            break;
        case ']':
            action(a, SENS_UP);
            break;
        case 'z':
        case 26:
            action(a, UNDO_EDIT);
            break;
        case 'y':
        case 25:
            action(a, REDO_EDIT);
            break;
        case 127:
        case 255:
            if (key == 65535 || key == 3014656 || k == 127)
                action(a, DELETE_BUBBLE);
            break;
        case ',':
            action(a, PREV);
            break;
        case '.':
            action(a, NEXT);
            break;
        }
    }
    a->drag = a->rubber = 0;
    commit_edit(a);
    /* Reversible recovery checkpoint, including unreviewed edits. */
    if (a->count) {
        char directory[TM_PATH], recovery[TM_PATH];
        if (a->project_path[0]) tm_save_project(a->project_path, a->photos, a->count);
        else if (tm_photo_directory(directory, sizeof(directory)) &&
                 snprintf(recovery, sizeof(recovery), "%s/TaylorMeter_recovery.tmc", directory) < (int)sizeof(recovery))
            tm_save_project(recovery, a->photos, a->count);
    }
    tmui_close();
    cvb_free(a->display);
    release_photos(a);
    free(a->photos);
    free(a->pending);
    tm_history_free(&a->history);
    free(a);
    return 0;
}
