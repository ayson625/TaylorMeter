#ifndef TM_UI_H
#define TM_UI_H
#include "cv_bridge.h"

enum { TMUI_MOUSE = 1, TMUI_KEY, TMUI_COMMAND, TMUI_INPUT };
typedef struct {
    int type, code, x, y, flags;
    char text[32];
} TMUI_Event;

/* Window callbacks only enqueue events. Application commands run after polling. */
int tmui_open(const char *title, int width, int height);
void tmui_button(int id, int x, int y, int w, int h, const char *label, int visible, int enabled,
                 int active);
void tmui_textfield(int slot, int visible, int x, int y, int w, int h, const char *text);
int tmui_choose_language(void);
int tmui_splash(void);
void tmui_input(int visible, int x, int y, int w, int h, const char *text);
void tmui_show(void *image);
int tmui_poll(TMUI_Event *event, int timeout_ms);
int tmui_alive(void);
void tmui_busy(int busy);
void tmui_close(void);
#endif
