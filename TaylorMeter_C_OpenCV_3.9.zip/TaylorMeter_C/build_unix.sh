#!/bin/sh
set -eu
cd "$(dirname "$0")"
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DTM_BUILD_TESTS=ON
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
printf '%s\n' 'Run ./build/TaylorMeter photo.jpg or ./build/TaylorMeter session.tmc'
