/* The only C++ translation unit. The application and inference are C11. */
#include "cv_bridge.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstring>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <string>
#include <vector>
#ifdef TM_HAVE_LIBRAW
#include <libraw/libraw.h>
#endif
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

struct Image {
    cv::Mat color, gray;
};
static std::string last_error;
static cv::Scalar rgb(int c) { return cv::Scalar(c & 255, (c >> 8) & 255, (c >> 16) & 255); }
static Image *im(void *p) { return static_cast<Image *>(p); }
static void caught(const std::exception &e) { last_error = e.what(); }

extern "C" {
const char *cvb_error(void) { return last_error.c_str(); }
void *cvb_load(const char *path, int *w, int *h) {
    try {
        FILE *f = tm_fopen(path, "rb");
        if (!f) {
            last_error = "Cannot open file.";
            return nullptr;
        }
        fseek(f, 0, SEEK_END);
        long size = ftell(f);
        rewind(f);
        if (size <= 0 || size > 700 * 1024 * 1024) {
            fclose(f);
            last_error = "Unsupported file size.";
            return nullptr;
        }
        std::vector<unsigned char> data(static_cast<size_t>(size));
        size_t got = fread(data.data(), 1, data.size(), f);
        fclose(f);
        if (got != data.size()) {
            last_error = "Cannot read complete file.";
            return nullptr;
        }
        std::string name(path);
        std::transform(name.begin(), name.end(), name.begin(),
                       [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        std::string ext = name.substr(
            name.find_last_of('.') == std::string::npos ? name.size() : name.find_last_of('.'));
        bool rawfile = ext == ".cr2" || ext == ".cr3" || ext == ".nef" || ext == ".arw" ||
                       ext == ".dng" || ext == ".raw";
        cv::Mat a;
        if (!rawfile)
            a = cv::imdecode(data, cv::IMREAD_COLOR);
#ifdef TM_HAVE_LIBRAW
        if (a.empty()) {
            LibRaw raw;
            int rc = raw.open_buffer(data.data(), data.size());
            raw.imgdata.params.output_bps = 8;
            raw.imgdata.params.use_camera_wb = 1;
            raw.imgdata.params.user_flip = 0;
            if (!rc)
                rc = raw.unpack();
            if (!rc)
                rc = raw.dcraw_process();
            if (!rc) {
                libraw_processed_image_t *p = raw.dcraw_make_mem_image(&rc);
                if (p && p->type == LIBRAW_IMAGE_BITMAP && p->bits == 8 && p->colors == 3) {
                    cv::Mat r(p->height, p->width, CV_8UC3, p->data);
                    cv::cvtColor(r, a, cv::COLOR_RGB2BGR);
                }
                if (p)
                    LibRaw::dcraw_clear_mem(p);
            }
        }
#endif
        if (a.empty()) {
            last_error = "Image decode failed. Convert RAW to TIFF/JPG or enable LibRaw.";
            return nullptr;
        }
        Image *p = new Image;
        p->color = a;
        *w = a.cols;
        *h = a.rows;
        return p;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void *cvb_create(int w, int h, int color) {
    try {
        Image *p = new Image;
        p->color = cv::Mat(h, w, CV_8UC3, rgb(color));
        return p;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void *cvb_decode_rgba(const unsigned char *data, size_t size) {
    try {
        if (!data || !size || size > 16*1024*1024) return nullptr;
        cv::Mat bytes(1, static_cast<int>(size), CV_8UC1, const_cast<unsigned char *>(data));
        cv::Mat decoded = cv::imdecode(bytes, cv::IMREAD_UNCHANGED);
        if (decoded.empty() || decoded.depth() != CV_8U ||
            (decoded.channels() != 3 && decoded.channels() != 4)) return nullptr;
        Image *p = new Image;
        p->color = decoded;
        return p;
    } catch (const std::exception &e) { caught(e); return nullptr; }
}
void cvb_composite(void *dst, void *src, int x, int y, int w, int h, double opacity) {
    try {
        if (!dst || !src || w <= 0 || h <= 0 || !std::isfinite(opacity) || opacity <= 0) return;
        opacity = std::min(1.0, opacity);
        cv::Mat &target = im(dst)->color, scaled;
        const cv::Mat &source = im(src)->color;
        if (target.channels() != 3) return;
        if (source.cols == w && source.rows == h) scaled = source;
        else cv::resize(source, scaled, cv::Size(w,h), 0, 0,
                        w < source.cols ? cv::INTER_AREA : cv::INTER_LINEAR);
        cv::Rect visible = cv::Rect(x,y,w,h) & cv::Rect(0,0,target.cols,target.rows);
        if (visible.empty()) return;
        cv::Mat dest = target(visible);
        cv::Mat region = scaled(cv::Rect(visible.x-x,visible.y-y,visible.width,visible.height));
        if (region.channels() == 3) {
            cv::addWeighted(region, opacity, dest, 1-opacity, 0, dest);
        } else if (region.channels() == 4) {
            for (int row = 0; row < region.rows; row++) {
                const cv::Vec4b *s = region.ptr<cv::Vec4b>(row);
                cv::Vec3b *d = dest.ptr<cv::Vec3b>(row);
                for (int col = 0; col < region.cols; col++) {
                    double a = opacity * s[col][3]/255.0;
                    for (int k = 0; k < 3; k++)
                        d[col][k] = cv::saturate_cast<unsigned char>(d[col][k]*(1-a)+s[col][k]*a);
                }
            }
        }
    } catch (const std::exception &e) { caught(e); }
}
void cvb_radial_glow(void *dst, int cx, int cy, double radius, int color, double opacity) {
    try {
        if (!dst || radius <= 0) return;
        cv::Mat &target = im(dst)->color;
        if (target.channels() != 3) return;
        cv::Vec3b tint(color & 255, (color >> 8) & 255, (color >> 16) & 255);
        for (int y = 0; y < target.rows; y++) {
            cv::Vec3b *p = target.ptr<cv::Vec3b>(y);
            for (int x = 0; x < target.cols; x++) {
                double dx = (x-cx)/radius, dy = (y-cy)/radius;
                double a = opacity * std::exp(-(dx*dx+dy*dy)*1.8);
                for (int k = 0; k < 3; k++)
                    p[x][k] = cv::saturate_cast<unsigned char>(p[x][k]*(1-a)+tint[k]*a);
            }
        }
    } catch (const std::exception &e) { caught(e); }
}
int cvb_text_width(const char *text, int height) {
    try {
#ifdef _WIN32
        int n = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
        if (!n) return 0;
        std::vector<wchar_t> ws(n);
        MultiByteToWideChar(CP_UTF8, 0, text, -1, ws.data(), n);
        HDC dc = CreateCompatibleDC(nullptr);
        HFONT font = CreateFontW(-height, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                                 OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                 DEFAULT_PITCH, L"Segoe UI");
        if (!dc || !font) { if(font) DeleteObject(font); if(dc) DeleteDC(dc); return 0; }
        HGDIOBJ previous = SelectObject(dc, font);
        SIZE size = {};
        GetTextExtentPoint32W(dc, ws.data(), n-1, &size);
        SelectObject(dc, previous); DeleteObject(font); DeleteDC(dc);
        return size.cx;
#else
        int baseline = 0;
        return cv::getTextSize(text, cv::FONT_HERSHEY_SIMPLEX, height/28.0, 1, &baseline).width;
#endif
    } catch (const std::exception &e) { caught(e); return 0; }
}
void *cvb_clone(void *p) {
    try {
        Image *a = new Image;
        a->color = im(p)->color.clone();
        return a;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void *cvb_resize(void *p, int w, int h) {
    try {
        Image *a = new Image;
        cv::resize(im(p)->color, a->color, cv::Size(w, h), 0, 0, cv::INTER_LINEAR);
        return a;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void cvb_free(void *p) { delete im(p); }
int cvb_line_segments(void *p, const TM_Rect *region, TM_Segment *out, int capacity) {
    try {
        if (!p || capacity < 1)
            return 0;
        cv::Rect roi(0, 0, im(p)->color.cols, im(p)->color.rows);
        if (region)
            roi &= cv::Rect(region->x, region->y, region->w, region->h);
        if (roi.width < 20 || roi.height < 5)
            return 0;
        cv::Mat gray, small, edges;
        cv::cvtColor(im(p)->color(roi), gray, cv::COLOR_BGR2GRAY);
        double scale = std::min(1.0, 1000.0 / std::max(roi.width, roi.height));
        cv::resize(gray, small, cv::Size(), scale, scale, cv::INTER_AREA);
        cv::GaussianBlur(small, small, cv::Size(3, 3), .8);
        cv::Canny(small, edges, 35, 100);
        std::vector<cv::Vec4i> lines;
        double extent = std::max(small.cols, small.rows);
        cv::HoughLinesP(edges, lines, 1, CV_PI / 720, std::max(25, static_cast<int>(extent * .1)),
                        extent * .18, extent * .045);
        std::sort(lines.begin(), lines.end(), [](const cv::Vec4i &a, const cv::Vec4i &b) {
            double ax = a[2] - a[0], ay = a[3] - a[1], bx = b[2] - b[0], by = b[3] - b[1];
            return ax * ax + ay * ay > bx * bx + by * by;
        });
        int n = std::min(capacity, static_cast<int>(lines.size()));
        for (int i = 0; i < n; i++) {
            out[i].a = {roi.x + lines[i][0] / scale, roi.y + lines[i][1] / scale};
            out[i].b = {roi.x + lines[i][2] / scale, roi.y + lines[i][3] / scale};
        }
        return n;
    } catch (const std::exception &e) {
        caught(e);
        return 0;
    }
}
void *cvb_strip(void *p, const TM_Channel *c, int *w, int *h) {
    try {
        double len = tm_channel_length(c);
        *w = static_cast<int>(std::ceil(len)) + 1;
        *h = static_cast<int>(std::ceil(2 * c->half_width)) + 1;
        if (*w < 2 || *h < 3 || *w > 30000 || *h > 10000) {
            last_error = "Channel size is out of range.";
            return nullptr;
        }
        cv::Mat mx(*h, *w, CV_32F), my(*h, *w, CV_32F);
        for (int y = 0; y < *h; y++)
            for (int x = 0; x < *w; x++) {
                TM_Point a = tm_channel_point(c, x * len / (*w - 1),
                                              (y - (*h - 1) * 0.5) * 2 * c->half_width / (*h - 1));
                mx.at<float>(y, x) = static_cast<float>(a.x);
                my.at<float>(y, x) = static_cast<float>(a.y);
            }
        Image *a = new Image;
        cv::remap(im(p)->color, a->color, mx, my, cv::INTER_LINEAR, cv::BORDER_REPLICATE);
        return a;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void *cvb_ruler_roi(void *p, const TM_Channel *c, int x, int y, int w, int h, double *origin) {
    try {
        cv::Rect rc(x, y, w, h);
        rc &= cv::Rect(0, 0, im(p)->color.cols, im(p)->color.rows);
        if (rc.width < 60 || rc.height < 8)
            return nullptr;
        double len = tm_channel_length(c), ux = (c->b.x - c->a.x) / len,
               uy = (c->b.y - c->a.y) / len;
        if (ux < 0) {
            ux = -ux;
            uy = -uy;
        }
        *origin = (rc.x + rc.width * 0.5) * ux + (rc.y + rc.height * 0.5) * uy - rc.width * 0.5;
        cv::Mat t = cv::getRotationMatrix2D(cv::Point2f(rc.width * 0.5f, rc.height * 0.5f),
                                            std::atan2(uy, ux) * 180 / CV_PI, 1);
        Image *a = new Image;
        cv::warpAffine(im(p)->color(rc), a->color, t, rc.size(), cv::INTER_LINEAR,
                       cv::BORDER_REPLICATE);
        return a;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
const uint8_t *cvb_bgr(void *p, int *w, int *h, int *stride) {
    if (!p || im(p)->color.empty())
        return nullptr;
    *w = im(p)->color.cols;
    *h = im(p)->color.rows;
    *stride = static_cast<int>(im(p)->color.step);
    return im(p)->color.data;
}
const uint8_t *cvb_gray(void *p, int *w, int *h, int *stride) {
    try {
        cv::cvtColor(im(p)->color, im(p)->gray, cv::COLOR_BGR2GRAY);
        *w = im(p)->gray.cols;
        *h = im(p)->gray.rows;
        *stride = static_cast<int>(im(p)->gray.step);
        return im(p)->gray.data;
    } catch (const std::exception &e) {
        caught(e);
        return nullptr;
    }
}
void cvb_line(void *p, double x1, double y1, double x2, double y2, int color, int thickness) {
    try {
        cv::line(im(p)->color,
                 cv::Point(static_cast<int>(std::lround(x1)), static_cast<int>(std::lround(y1))),
                 cv::Point(static_cast<int>(std::lround(x2)), static_cast<int>(std::lround(y2))),
                 rgb(color), thickness, cv::LINE_AA);
    } catch (const std::exception &e) {
        caught(e);
    }
}
void cvb_rect(void *p, int x, int y, int w, int h, int color, int thick) {
    try {
        if (w > 0 && h > 0)
            cv::rectangle(im(p)->color, cv::Rect(x, y, w, h), rgb(color), thick);
    } catch (const std::exception &e) {
        caught(e);
    }
}
void cvb_tint_quad(void *p, const TM_Point corners[4], int color, double alpha) {
    try {
        cv::Mat &dst = im(p)->color;
        cv::Point points[4];
        for (int k = 0; k < 4; k++)
            points[k] = cv::Point(static_cast<int>(std::lround(corners[k].x)),
                                 static_cast<int>(std::lround(corners[k].y)));
        cv::Rect bounds = cv::boundingRect(std::vector<cv::Point>(points, points + 4)) &
                          cv::Rect(0, 0, dst.cols, dst.rows);
        if (bounds.empty())
            return;
        for (int k = 0; k < 4; k++)
            points[k] -= bounds.tl();
        cv::Mat mask(bounds.size(), CV_8UC1, cv::Scalar(0));
        cv::fillConvexPoly(mask, points, 4, cv::Scalar(255), cv::LINE_AA);
        cv::Vec3b tint(color & 255, (color >> 8) & 255, (color >> 16) & 255);
        alpha = std::max(0.0, std::min(1.0, alpha));
        for (int y = 0; y < bounds.height; y++) {
            cv::Vec3b *row = dst.ptr<cv::Vec3b>(bounds.y + y) + bounds.x;
            const unsigned char *coverage = mask.ptr<unsigned char>(y);
            for (int x = 0; x < bounds.width; x++) {
                double a = alpha * coverage[x] / 255.0;
                for (int k = 0; k < 3; k++)
                    row[x][k] = cv::saturate_cast<unsigned char>(row[x][k] * (1 - a) + tint[k] * a);
            }
        }
    } catch (const std::exception &e) {
        caught(e);
    }
}
void cvb_circle(void *p, int x, int y, int r, int color) {
    try {
        cv::circle(im(p)->color, cv::Point(x, y), r, rgb(color), -1, cv::LINE_AA);
    } catch (const std::exception &e) {
        caught(e);
    }
}
void cvb_text(void *p, int x, int y, const char *text, int height, int color) {
    try {
#ifdef _WIN32
        /* Native Unicode glyphs for the Russian Windows interface. */
        int n = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
        if (!n)
            return;
        std::vector<wchar_t> ws(n);
        MultiByteToWideChar(CP_UTF8, 0, text, -1, ws.data(), n);
        HDC dc = CreateCompatibleDC(nullptr);
        HFONT font = CreateFontW(-height, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                                 OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,
                                 DEFAULT_PITCH, L"Segoe UI");
        HGDIOBJ oldfont = SelectObject(dc, font);
        SIZE sz = {};
        GetTextExtentPoint32W(dc, ws.data(), n - 1, &sz);
        int tw = sz.cx + 4, th = height + 6;
        if (tw < 4) {
            SelectObject(dc, oldfont);
            DeleteObject(font);
            DeleteDC(dc);
            return;
        }
        BITMAPINFO bi = {};
        bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bi.bmiHeader.biWidth = tw;
        bi.bmiHeader.biHeight = -th;
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        void *bits = nullptr;
        HBITMAP bm = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
        HGDIOBJ oldbm = SelectObject(dc, bm);
        std::memset(bits, 0, static_cast<size_t>(tw) * th * 4);
        SetBkColor(dc, RGB(0, 0, 0));
        SetTextColor(dc, RGB(255, 255, 255));
        TextOutW(dc, 0, 0, ws.data(), n - 1);
        const unsigned char *mask = static_cast<const unsigned char *>(bits);
        cv::Vec3b col(color & 255, (color >> 8) & 255, (color >> 16) & 255);
        for (int yy = 0; yy < th; yy++)
            for (int xx = 0; xx < tw; xx++)
                if (x + xx >= 0 && x + xx < im(p)->color.cols && y + yy - height >= 0 &&
                    y + yy - height < im(p)->color.rows) {
                    double alpha = mask[(yy * tw + xx) * 4] / 255.0;
                    cv::Vec3b &px = im(p)->color.at<cv::Vec3b>(y + yy - height, x + xx);
                    for (int k = 0; k < 3; k++)
                        px[k] =
                            cv::saturate_cast<unsigned char>(px[k] * (1 - alpha) + col[k] * alpha);
                }
        SelectObject(dc, oldbm);
        SelectObject(dc, oldfont);
        DeleteObject(bm);
        DeleteObject(font);
        DeleteDC(dc);
#else
        cv::putText(im(p)->color, text, cv::Point(x, y), cv::FONT_HERSHEY_SIMPLEX, height / 28.0,
                    rgb(color), 1, cv::LINE_AA);
#endif
    } catch (const std::exception &e) {
        caught(e);
    }
}
void cvb_blit(void *dst, void *src, double zoom, double panx, double pany, int x, int y, int w,
              int h) {
    try {
        cv::Mat matrix = (cv::Mat_<double>(2, 3) << zoom, 0, -panx * zoom, 0, zoom, -pany * zoom),
                a;
        cv::warpAffine(im(src)->color, a, matrix, cv::Size(w, h), cv::INTER_LINEAR,
                       cv::BORDER_CONSTANT, rgb(0x131a25));
        a.copyTo(im(dst)->color(cv::Rect(x, y, w, h)));
    } catch (const std::exception &e) {
        caught(e);
    }
}
int cvb_save(void *p, const char *path) {
    try {
        std::vector<unsigned char> data;
        std::string name(path);
        std::string ext = ".png";
        if (name.size() > 4 &&
            (name.substr(name.size() - 4) == ".jpg" || name.substr(name.size() - 4) == ".JPG"))
            ext = ".jpg";
        if (!cv::imencode(ext, im(p)->color, data))
            return 0;
        FILE *f = tm_fopen(path, "wb");
        if (!f)
            return 0;
        bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
        if (fclose(f))
            ok = false;
        return ok ? 1 : 0;
    } catch (const std::exception &e) {
        caught(e);
        return 0;
    }
}
int cvb_open_window(const char *title, CVB_Mouse cb, void *ctx) {
    try {
        cv::namedWindow(title, cv::WINDOW_AUTOSIZE | cv::WINDOW_GUI_NORMAL);
        cv::moveWindow(title, 0, 0);
        cv::setMouseCallback(title, cb, ctx);
        return 1;
    } catch (const std::exception &e) {
        caught(e);
        return 0;
    }
}
void cvb_show(const char *title, void *p) {
    try {
        cv::imshow(title, im(p)->color);
    } catch (const std::exception &e) {
        caught(e);
    }
}
int cvb_key(int ms) {
    try {
        return cv::waitKeyEx(ms);
    } catch (const std::exception &e) {
        caught(e);
        return -1;
    }
}
int cvb_window_alive(const char *title) {
    try {
        return cv::getWindowProperty(title, cv::WND_PROP_VISIBLE) > 0;
    } catch (const std::exception &) {
        return 0;
    }
}
void cvb_close(void) {
    try {
        cv::destroyAllWindows();
    } catch (const std::exception &e) {
        caught(e);
    }
}
}
