#include "tm.h"
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <sys/stat.h>
#include <unistd.h>
#endif

static int english;
void tm_set_language(int value) { english = value != 0; }
int tm_is_english(void) { return english; }
const char *tm_text(const char *ru, const char *en) { return english ? en : ru; }
int tm_flow_equal(const TM_State *a, const TM_State *b) {
    return a->flow_valid == b->flow_valid &&
           (!a->flow_valid || (a->flow[0] == b->flow[0] && a->flow[1] == b->flow[1]));
}
int tm_parse_flow(const char *text, double *value) {
    char buf[32], *end;
    if (!text || strlen(text) >= sizeof(buf)) return 0;
    strcpy(buf, text);
    for (char *p = buf; *p; p++) if (*p == ',') *p = '.';
    errno = 0;
    double v = strtod(buf, &end);
    if (end == buf || errno || !isfinite(v) || v < 0 || v > 1e12) return 0;
    while (isspace((unsigned char)*end)) end++;
    if (*end) return 0;
    *value = v;
    return 1;
}
int tm_export_stem(const TM_Photo *p, int index, char *out, size_t cap) {
    char stem[TM_PATH];
    snprintf(stem, sizeof(stem), "%s", tm_basename(p->path));
    char *dot = strrchr(stem, '.');
    if (dot && dot != stem) *dot = 0;
    for (char *q = stem; *q; q++)
        if ((unsigned char)*q < 32 || strchr("<>:\"/\\|?*", *q)) *q = '_';
    size_t n = strlen(stem);
    while (n && (stem[n-1] == '.' || stem[n-1] == ' ')) stem[--n] = 0;
    if (!n) strcpy(stem, "photo");
    return snprintf(out, cap, "%03d_%s", index + 1, stem) < (int)cap;
}
static int make_directory(const char *path) {
#ifdef _WIN32
    wchar_t wide[TM_PATH];
    if (!MultiByteToWideChar(CP_UTF8, 0, path, -1, wide, TM_PATH)) return 0;
    return CreateDirectoryW(wide, NULL) != 0;
#else
    return mkdir(path, 0777) == 0;
#endif
}
static int is_directory(const char *path) {
#ifdef _WIN32
    wchar_t wide[TM_PATH];
    if (!MultiByteToWideChar(CP_UTF8, 0, path, -1, wide, TM_PATH)) return 0;
    DWORD attrs = GetFileAttributesW(wide);
    return attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY);
#else
    struct stat st;
    return !stat(path, &st) && S_ISDIR(st.st_mode);
#endif
}
int tm_saves_directory(char *out, size_t cap) {
    char executable[TM_PATH];
#ifdef _WIN32
    wchar_t wide[TM_PATH];
    DWORD n = GetModuleFileNameW(NULL, wide, TM_PATH);
    if (!n || n >= TM_PATH || !WideCharToMultiByte(CP_UTF8, 0, wide, -1, executable,
                                                sizeof(executable), NULL, NULL)) return 0;
#else
    ssize_t n = readlink("/proc/self/exe", executable, sizeof(executable) - 1);
    if (n <= 0 || n >= (ssize_t)sizeof(executable) - 1) return 0;
    executable[n] = 0;
#endif
    char *base = (char *)tm_basename(executable);
    *base = 0;
    if (snprintf(out, cap, "%ssaves", executable) >= (int)cap) return 0;
    return is_directory(out) || make_directory(out);
}
static int saves_subdirectory(const char *name, char *out, size_t cap) {
    char saves[TM_PATH];
    if (!tm_saves_directory(saves, sizeof(saves)) ||
        snprintf(out, cap, "%s/%s", saves, name) >= (int)cap) return 0;
    return is_directory(out) || make_directory(out);
}
int tm_photo_directory(char *out, size_t cap) {
    return saves_subdirectory("photo", out, cap);
}
int tm_export_photo_base(const char *xlsx, char *out, size_t cap) {
    char photo[TM_PATH], stem[TM_PATH], folder[TM_PATH];
    if (!tm_photo_directory(photo, sizeof(photo))) return 0;
    snprintf(stem, sizeof(stem), "%s", tm_basename(xlsx));
    char *dot = strrchr(stem, '.');
    if (dot) *dot = 0;
    if (!stem[0] || snprintf(folder, sizeof(folder), "%s/%s", photo, stem) >= (int)sizeof(folder)) return 0;
    if (!is_directory(folder) && !make_directory(folder)) return 0;
    return snprintf(out, cap, "%s/TaylorMeter", folder) < (int)cap;
}
int tm_create_export_path(char *out, size_t cap) {
    char excel[TM_PATH], photo[TM_PATH], stamp[64], folder[TM_PATH], candidate[TM_PATH];
    if (!saves_subdirectory("excel", excel, sizeof(excel)) ||
        !tm_photo_directory(photo, sizeof(photo))) return 0;
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    if (!local || !strftime(stamp, sizeof(stamp), "%Y-%m-%d_%H-%M-%S", local)) return 0;
    for (int i = 0; i < 1000; i++) {
        if (snprintf(folder, sizeof(folder), "%s/TaylorMeter_%s_%03d", photo, stamp, i + 1) >= (int)sizeof(folder) ||
            snprintf(candidate, sizeof(candidate), "%s/TaylorMeter_%s_%03d.xlsx", excel, stamp, i + 1) >= (int)sizeof(candidate) ||
            strlen(candidate) >= cap)
            return 0;
        FILE *existing = tm_fopen(candidate, "rb");
        if (existing) { fclose(existing); continue; }
        /* Reserving a new photo folder also reserves the matching Excel name. */
        if (make_directory(folder)) { strcpy(out, candidate); return 1; }
        if (!is_directory(folder)) return 0;
    }
    return 0;
}
/* A moved project can find its originals beside it or in a sibling originals folder.
   Never guess a different file recursively when several basenames could collide. */
int tm_relocate_source(char *source, size_t cap, const char *project) {
    FILE *f = tm_fopen(source, "rb");
    if (f) { fclose(f); return 1; }
    char directory[TM_PATH], candidate[TM_PATH];
    snprintf(directory, sizeof(directory), "%s", project);
    char *base = (char *)tm_basename(directory);
    if (base == directory) strcpy(directory, "./"); else *base = 0;
    const char *sub[] = {"", "originals/", "исходники/"};
    for (int i = 0; i < 3; i++) {
        if (snprintf(candidate, sizeof(candidate), "%s%s%s", directory, sub[i], tm_basename(source)) >=
            (int)sizeof(candidate)) continue;
        f = tm_fopen(candidate, "rb");
        if (f) {
            fclose(f);
            if (strlen(candidate) >= cap) return 0;
            strcpy(source, candidate);
            return 1;
        }
    }
    return 0;
}
