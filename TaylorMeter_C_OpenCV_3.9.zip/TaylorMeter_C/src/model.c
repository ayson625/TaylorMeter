#include "tm.h"
#include <math.h>
#include <string.h>

double tm_channel_length(const TM_Channel *c) { return hypot(c->b.x - c->a.x, c->b.y - c->a.y); }
TM_Point tm_channel_point(const TM_Channel *c, double s, double t) {
    double len = tm_channel_length(c), ux = (c->b.x - c->a.x) / len, uy = (c->b.y - c->a.y) / len;
    TM_Point p = {c->a.x + ux * s - uy * t, c->a.y + uy * s + ux * t};
    return p;
}
int tm_set_channel(TM_State *s, TM_Point a, TM_Point b, TM_Point wall) {
    double len = hypot(b.x - a.x, b.y - a.y), hw;
    if (!isfinite(len) || len < 10)
        return 0;
    hw = fabs((wall.x - a.x) * (b.y - a.y) - (wall.y - a.y) * (b.x - a.x)) / len;
    if (!isfinite(hw) || hw < 2 || hw > len / 2)
        return 0;
    s->channel = (TM_Channel){a, b, hw, 1};
    memset(&s->region, 0, sizeof(s->region));
    s->count = 0;
    s->reviewed = 0;
    s->partial_count = 0;
    return 1;
}
int tm_set_channel_rect(TM_State *s, TM_Rect r, int image_w, int image_h) {
    if (r.w < 1 || r.h < 1 || image_w < 2 || image_h < 2)
        return 0;
    int x0 = r.x < 0 ? 0 : r.x, y0 = r.y < 0 ? 0 : r.y;
    long long xend = (long long)r.x + r.w, yend = (long long)r.y + r.h;
    int x1 = xend > image_w ? image_w : (int)xend;
    int y1 = yend > image_h ? image_h : (int)yend;
    if (x1 - x0 < 4 || y1 - y0 < 4)
        return 0;
    TM_Point a, b, wall;
    if (x1 - x0 >= y1 - y0) {
        a = (TM_Point){x0, (y0 + y1 - 1) * .5};
        b = (TM_Point){x1 - 1, a.y};
        wall = (TM_Point){x0, y0};
    } else {
        a = (TM_Point){(x0 + x1 - 1) * .5, y0};
        b = (TM_Point){a.x, y1 - 1};
        wall = (TM_Point){x0, y0};
    }
    if (!tm_set_channel(s, a, b, wall))
        return 0;
    s->region = (TM_Rect){x0, y0, x1 - x0, y1 - y0, 1, r.automatic};
    return 1;
}
int tm_add_bubble(TM_State *s, double l, double r, unsigned flags, double conf) {
    int at = 0;
    double len = tm_channel_length(&s->channel);
    if (!s->channel.valid || !isfinite(l) || !isfinite(r) || l < 0 || r > len || l >= r ||
        s->count >= TM_MAX_BUBBLES)
        return -1;
    while (at < s->count && s->bubbles[at].left < l)
        at++;
    /* Adjacent boundaries may coincide: a zero or subpixel slug is retained. */
    if ((at > 0 && s->bubbles[at - 1].right > l) || (at < s->count && r > s->bubbles[at].left))
        return -1;
    memmove(s->bubbles + at + 1, s->bubbles + at, (size_t)(s->count - at) * sizeof(TM_Bubble));
    s->bubbles[at] = (TM_Bubble){l, r, conf, flags};
    s->count++;
    s->reviewed = 0;
    return at;
}
int tm_move_boundary(TM_State *s, int i, int side, double pos) {
    double lo, hi;
    if (i < 0 || i >= s->count || !isfinite(pos))
        return 0;
    if (side == 0) {
        lo = i ? s->bubbles[i - 1].right : 0;
        hi = s->bubbles[i].right - 0.01;
    } else {
        lo = s->bubbles[i].left + 0.01;
        hi = i + 1 < s->count ? s->bubbles[i + 1].left : tm_channel_length(&s->channel);
    }
    if (hi < lo)
        return 0;
    if (pos < lo)
        pos = lo;
    if (pos > hi)
        pos = hi;
    if (side == 0)
        s->bubbles[i].left = pos;
    else
        s->bubbles[i].right = pos;
    s->bubbles[i].flags = TM_MANUAL;
    s->bubbles[i].confidence = 1;
    s->reviewed = 0;
    return 1;
}
void tm_delete_bubble(TM_State *s, int i) {
    if (i < 0 || i >= s->count)
        return;
    memmove(s->bubbles + i, s->bubbles + i + 1, (size_t)(s->count - i - 1) * sizeof(TM_Bubble));
    s->count--;
    s->reviewed = 0;
}
static int fail(char *e, size_t n, const char *msg) {
    if (e && n)
        snprintf(e, n, "%s", msg);
    return 0;
}
int tm_validate(const TM_State *s, char *e, size_t n) {
    double len = tm_channel_length(&s->channel), prev = 0;
    if (!s->channel.valid || !isfinite(len) || len < 10 || !isfinite(s->channel.half_width) ||
        s->channel.half_width < 2)
        return fail(e, n, "Choose the channel manually (3 points).");
    if (s->count < 1 || s->count > TM_MAX_BUBBLES)
        return fail(e, n, "No bubbles. Detect or add boundaries manually.");
    for (int i = 0; i < s->count; i++) {
        const TM_Bubble *b = s->bubbles + i;
        if (!isfinite(b->left) || !isfinite(b->right) || b->left < prev ||
            b->right > b->left + len || b->right > len || b->left < 0 || b->left >= b->right)
            return fail(e, n, "Invalid or overlapping bubble boundaries.");
        prev = b->right;
    }
    if (!s->calibration.valid || !isfinite(s->calibration.mm_per_px) ||
        s->calibration.mm_per_px <= 0)
        return fail(e, n, "Calibrate the ruler first.");
    if (s->calibration.count < 0 || s->calibration.count > TM_MAX_TICKS)
        return fail(e, n, "Invalid ruler tick count.");
    for (int i = 0; i < s->calibration.count; i++) {
        if (!isfinite(s->calibration.ticks[i].x) || !isfinite(s->calibration.ticks[i].mm) ||
            (i && (s->calibration.ticks[i].x <= s->calibration.ticks[i - 1].x ||
                   s->calibration.ticks[i].mm <= s->calibration.ticks[i - 1].mm)))
            return fail(e, n, "Invalid ruler ticks.");
    }
    if (!isfinite(s->calibration.axis_x) || !isfinite(s->calibration.axis_y) ||
        fabs(hypot(s->calibration.axis_x, s->calibration.axis_y) - 1) > 0.001)
        return fail(e, n, "Invalid ruler direction.");
    {
        double ux = (s->channel.b.x - s->channel.a.x) / len,
               uy = (s->channel.b.y - s->channel.a.y) / len;
        if (fabs(ux * s->calibration.axis_x + uy * s->calibration.axis_y) < 0.98)
            return fail(e, n, "Ruler and channel directions differ by more than 11 degrees.");
    }
    return 1;
}
static double ruler_mm(const TM_Calibration *c, double x) {
    int a = 0, b = c->count - 1;
    /* At least two observed ticks; otherwise use the manual uniform scale. */
    if (c->count < 2)
        return x * c->mm_per_px;
    if (x <= c->ticks[0].x) {
        a = 0;
        b = 1;
    } else if (x >= c->ticks[b].x) {
        a = b - 1;
    } else {
        while (b - a > 1) {
            int m = (a + b) / 2;
            if (c->ticks[m].x < x)
                a = m;
            else
                b = m;
        }
    }
    return c->ticks[a].mm + (x - c->ticks[a].x) * (c->ticks[b].mm - c->ticks[a].mm) /
                                (c->ticks[b].x - c->ticks[a].x);
}
double tm_distance_mm(const TM_State *s, double l, double r) {
    if (!s->calibration.valid)
        return NAN;
    TM_Point a = tm_channel_point(&s->channel, l, 0), b = tm_channel_point(&s->channel, r, 0);
    const TM_Calibration *c = &s->calibration;
    return fabs(ruler_mm(c, b.x * c->axis_x + b.y * c->axis_y) -
                ruler_mm(c, a.x * c->axis_x + a.y * c->axis_y));
}
double tm_bubble_mm(const TM_State *s, int i) {
    return i >= 0 && i < s->count ? tm_distance_mm(s, s->bubbles[i].left, s->bubbles[i].right)
                                  : NAN;
}
double tm_slug_mm(const TM_State *s, int i) {
    return i >= 0 && i + 1 < s->count
               ? tm_distance_mm(s, s->bubbles[i].right, s->bubbles[i + 1].left)
               : NAN;
}
int tm_manual_calibrate(TM_State *s, TM_Point a, TM_Point b, double mm) {
    double d = hypot(b.x - a.x, b.y - a.y);
    if (!isfinite(mm) || mm <= 0 || !isfinite(d) || d < 1)
        return 0;
    memset(&s->calibration, 0, sizeof(s->calibration));
    s->calibration.mm_per_px = mm / d;
    s->calibration.axis_x = (b.x - a.x) / d;
    s->calibration.axis_y = (b.y - a.y) / d;
    s->calibration.valid = 1;
    s->calibration.manual = 1;
    s->reviewed = 0;
    return 1;
}
