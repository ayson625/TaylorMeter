#include "ui.h"
#include "tm.h"
#include "splash.h"
#include <stdlib.h>
#include <string.h>
#ifndef _WIN32
#include <time.h>
#endif

#define EVENT_CAP 256
static TMUI_Event queue[EVENT_CAP];
static int queue_head, queue_count;
static char window_title[128];

static void enqueue(TMUI_Event e) {
    if (queue_count && e.type == TMUI_MOUSE && e.code == 0) {
        int last = (queue_head + queue_count - 1) % EVENT_CAP;
        if (queue[last].type == TMUI_MOUSE && queue[last].code == 0) {
            queue[last] = e;
            return;
        }
    }
    if (queue_count == EVENT_CAP) {
        queue_head = (queue_head + 1) % EVENT_CAP;
        queue_count--;
    }
    queue[(queue_head + queue_count++) % EVENT_CAP] = e;
}
static int dequeue(TMUI_Event *e) {
    if (!queue_count)
        return 0;
    *e = queue[queue_head];
    queue_head = (queue_head + 1) % EVENT_CAP;
    queue_count--;
    return 1;
}

#ifdef _WIN32
#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
// clang-format off
#include <windows.h>
#include <windowsx.h>
#include <wchar.h>
// clang-format on
#define MAX_CONTROLS 64
#define INPUT_ID 9000
typedef struct {
    HWND hwnd;
    int id, x, y, w, h, visible, enabled, active;
    char label[192];
} Control;
static HWND window, inputs[3];
static HFONT font;
static Control controls[MAX_CONTROLS], edits[3];
static int control_count, logical_w, logical_h, client_w, client_h, alive, busy, setting_text;
static int canvas_w, canvas_h, offset_x, offset_y;
static unsigned char *pixels;
static size_t pixel_capacity;
static BITMAPINFO bitmap;
static int pixels_valid, frame_dirty = 1, frame_w, frame_h;
static HDC frame_dc;
static HBITMAP frame_bitmap;
static HGDIOBJ frame_previous;

static int text_input(HWND h) {
    for (int i = 0; i < 3; i++) if (h && h == inputs[i]) return 1;
    return 0;
}
static HWND visible_input(void) {
    HWND focused = GetFocus();
    if (text_input(focused) && IsWindowVisible(focused)) return focused;
    for (int i = 0; i < 3; i++) if (edits[i].visible) return inputs[i];
    return NULL;
}
static void release_frame(void) {
    if (frame_dc && frame_previous)
        SelectObject(frame_dc, frame_previous);
    if (frame_bitmap)
        DeleteObject(frame_bitmap);
    if (frame_dc)
        DeleteDC(frame_dc);
    frame_dc = NULL;
    frame_bitmap = NULL;
    frame_previous = NULL;
    frame_w = frame_h = 0;
    frame_dirty = 1;
}
/* Compose the complete resized canvas off screen. WM_PAINT then transfers one
   finished image, never an intermediate background-only frame. */
static int prepare_frame(HDC dc) {
    if (client_w <= 0 || client_h <= 0)
        return 0;
    if (!frame_dc || frame_w != client_w || frame_h != client_h) {
        HDC next_dc = CreateCompatibleDC(dc);
        HBITMAP next_bitmap = CreateCompatibleBitmap(dc, client_w, client_h);
        HGDIOBJ next_previous = NULL;
        if (next_dc && next_bitmap)
            next_previous = SelectObject(next_dc, next_bitmap);
        if (!next_dc || !next_bitmap || !next_previous || next_previous == HGDI_ERROR) {
            if (next_bitmap)
                DeleteObject(next_bitmap);
            if (next_dc)
                DeleteDC(next_dc);
            return 0;
        }
        release_frame();
        frame_dc = next_dc;
        frame_bitmap = next_bitmap;
        frame_previous = next_previous;
        frame_w = client_w;
        frame_h = client_h;
    }
    if (frame_dirty) {
        RECT full = {0, 0, client_w, client_h};
        SetDCBrushColor(frame_dc, RGB(19, 26, 37));
        FillRect(frame_dc, &full, (HBRUSH)GetStockObject(DC_BRUSH));
        if (pixels_valid) {
            SetStretchBltMode(frame_dc, HALFTONE);
            SetBrushOrgEx(frame_dc, 0, 0, NULL);
            int copied =
                StretchDIBits(frame_dc, offset_x, offset_y, canvas_w, canvas_h, 0, 0, logical_w,
                              logical_h, pixels, &bitmap, DIB_RGB_COLORS, SRCCOPY);
            if (copied == 0 || copied == (int)GDI_ERROR)
                return 0;
        }
        frame_dirty = 0;
    }
    return 1;
}
/* Allocation failure still leaves a usable window. Only letterbox margins are
   cleared on the visible DC; the image area is replaced without erasing it. */
static void paint_direct(HDC dc, const RECT *paint) {
    SetDCBrushColor(dc, RGB(19, 26, 37));
    if (!pixels_valid) {
        FillRect(dc, paint, (HBRUSH)GetStockObject(DC_BRUSH));
        return;
    }
    RECT margins[4] = {{0, 0, client_w, offset_y},
                       {0, offset_y + canvas_h, client_w, client_h},
                       {0, offset_y, offset_x, offset_y + canvas_h},
                       {offset_x + canvas_w, offset_y, client_w, offset_y + canvas_h}};
    for (int i = 0; i < 4; i++)
        if (margins[i].right > margins[i].left && margins[i].bottom > margins[i].top)
            FillRect(dc, margins + i, (HBRUSH)GetStockObject(DC_BRUSH));
    SetStretchBltMode(dc, HALFTONE);
    SetBrushOrgEx(dc, 0, 0, NULL);
    StretchDIBits(dc, offset_x, offset_y, canvas_w, canvas_h, 0, 0, logical_w, logical_h, pixels,
                  &bitmap, DIB_RGB_COLORS, SRCCOPY);
}

static void utf16(const char *s, wchar_t *out, int cap) {
    if (!MultiByteToWideChar(CP_UTF8, 0, s, -1, out, cap))
        out[0] = 0;
}
static int scaled(int value, int client, int logical) {
    return MulDiv(value, client > 0 ? client : logical, logical);
}
static void place(Control *c) {
    if (!c->hwnd)
        return;
    MoveWindow(c->hwnd, offset_x + scaled(c->x, canvas_w, logical_w),
               offset_y + scaled(c->y, canvas_h, logical_h), scaled(c->w, canvas_w, logical_w),
               scaled(c->h, canvas_h, logical_h), TRUE);
    SendMessageW(c->hwnd, WM_SETFONT, (WPARAM)font, TRUE);
}
static void layout(void) {
    RECT r;
    GetClientRect(window, &r);
    client_w = r.right;
    client_h = r.bottom;
    if ((long long)client_w * logical_h <= (long long)client_h * logical_w) {
        canvas_w = client_w > 0 ? client_w : 1;
        canvas_h = MulDiv(canvas_w, logical_h, logical_w);
    } else {
        canvas_h = client_h > 0 ? client_h : 1;
        canvas_w = MulDiv(canvas_h, logical_w, logical_h);
    }
    offset_x = (client_w - canvas_w) / 2;
    offset_y = (client_h - canvas_h) / 2;
    double sx = (double)canvas_w / logical_w, sy = (double)canvas_h / logical_h;
    int height = (int)(16 * (sx < sy ? sx : sy));
    if (height < 11)
        height = 11;
    HFONT next = CreateFontW(-height, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
                             OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                             DEFAULT_PITCH, L"Segoe UI");
    HFONT old = font;
    if (next)
        font = next;
    for (int i = 0; i < control_count; i++)
        place(controls + i);
    for (int i = 0; i < 3; i++) place(edits+i);
    if (old && old != font)
        DeleteObject(old);
    frame_dirty = 1;
    InvalidateRect(window, NULL, FALSE);
}
static LRESULT CALLBACK procedure(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    TMUI_Event e = {0};
    switch (msg) {
    case WM_SIZE:
        if (window)
            layout();
        return 0;
    case WM_GETMINMAXINFO: {
        MINMAXINFO *m = (MINMAXINFO *)lp;
        m->ptMinTrackSize.x = 880;
        m->ptMinTrackSize.y = 560;
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(wp) >= INPUT_ID && LOWORD(wp) < INPUT_ID + 3 && HIWORD(wp) == EN_CHANGE && !setting_text) {
            wchar_t text[32] = {0};
            GetWindowTextW((HWND)lp, text, 32);
            e.type = TMUI_INPUT;
            e.code = LOWORD(wp) - INPUT_ID;
            WideCharToMultiByte(CP_UTF8, 0, text, -1, e.text, sizeof(e.text), NULL, NULL);
            enqueue(e);
        } else if (HIWORD(wp) == BN_CLICKED) {
            e.type = TMUI_COMMAND;
            e.code = LOWORD(wp);
            enqueue(e);
            HWND field = visible_input();
            SetFocus(field ? field : hwnd);
        }
        return 0;
    case WM_CANCELMODE:
        e.type = TMUI_MOUSE;
        e.code = 13;
        enqueue(e);
        if (GetCapture() == hwnd)
            ReleaseCapture();
        return 0;
    case WM_ACTIVATE:
        if (LOWORD(wp) == WA_INACTIVE) {
            e.type = TMUI_MOUSE;
            e.code = 13;
            enqueue(e);
        }
        break;
    case WM_MOUSELEAVE:
        e.type = TMUI_MOUSE;
        e.code = 14;
        e.x = e.y = -1;
        enqueue(e);
        return 0;
    case WM_LBUTTONDOWN:
    case WM_RBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONUP:
    case WM_MOUSEMOVE:
    case WM_MOUSEWHEEL: {
        if (msg == WM_MOUSEMOVE) {
            TRACKMOUSEEVENT tracking = {sizeof(TRACKMOUSEEVENT), TME_LEAVE, hwnd, 0};
            TrackMouseEvent(&tracking);
        }
        POINT pt = {GET_X_LPARAM(lp), GET_Y_LPARAM(lp)};
        if (msg == WM_MOUSEWHEEL)
            ScreenToClient(hwnd, &pt);
        e.type = TMUI_MOUSE;
        e.code = msg == WM_LBUTTONDOWN   ? 1
                 : msg == WM_RBUTTONDOWN ? 2
                 : msg == WM_LBUTTONUP   ? 4
                 : msg == WM_RBUTTONUP   ? 5
                 : msg == WM_MOUSEWHEEL  ? 10
                                         : 0;
        e.x = scaled(pt.x - offset_x, logical_w, canvas_w);
        e.y = scaled(pt.y - offset_y, logical_h, canvas_h);
        e.flags = (wp & MK_LBUTTON ? 1 : 0) | (wp & MK_RBUTTON ? 2 : 0) |
                  (wp & MK_CONTROL ? 8 : 0) | (wp & MK_SHIFT ? 16 : 0);
        if (msg == WM_MOUSEWHEEL)
            e.flags |= ((unsigned)(unsigned short)GET_WHEEL_DELTA_WPARAM(wp)) << 16;
        if (msg == WM_LBUTTONDOWN || msg == WM_RBUTTONDOWN) {
            SetFocus(visible_input() ? visible_input() : hwnd);
            SetCapture(hwnd);
        } else if (msg == WM_LBUTTONUP || msg == WM_RBUTTONUP)
            ReleaseCapture();
        enqueue(e);
        return 0;
    }
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT) {
            SetCursor(LoadCursorW(NULL, busy ? IDC_WAIT : IDC_ARROW));
            return TRUE;
        }
        break;
    case WM_ERASEBKGND:
        return 1;
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        if (prepare_frame(dc))
            BitBlt(dc, ps.rcPaint.left, ps.rcPaint.top, ps.rcPaint.right - ps.rcPaint.left,
                   ps.rcPaint.bottom - ps.rcPaint.top, frame_dc, ps.rcPaint.left, ps.rcPaint.top,
                   SRCCOPY);
        else
            paint_direct(dc, &ps.rcPaint);
        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        alive = 0;
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}
int tmui_open(const char *title, int w, int h) {
    const wchar_t *name = L"TaylorMeterNativeC";
    WNDCLASSW wc = {0};
    wchar_t caption[128];
    wc.lpfnWndProc = procedure;
    wc.hInstance = GetModuleHandleW(NULL);
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hIcon = LoadIconW(GetModuleHandleW(NULL), MAKEINTRESOURCEW(1));
    if (!wc.hIcon) wc.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    wc.lpszClassName = name;
    if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) {
        fprintf(stderr, "RegisterClassW failed: %lu\n", (unsigned long)GetLastError());
        return 0;
    }
    logical_w = w;
    logical_h = h;
    queue_head = queue_count = control_count = 0;
    snprintf(window_title, sizeof(window_title), "%s", title);
    utf16(title, caption, 128);
    RECT work = {0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)};
    RECT frame = {0, 0, w, h};
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    DWORD style = WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN;
    AdjustWindowRect(&frame, style, FALSE);
    int fw = frame.right - frame.left, fh = frame.bottom - frame.top;
    if (fw > work.right - work.left - 24)
        fw = work.right - work.left - 24;
    if (fh > work.bottom - work.top - 24)
        fh = work.bottom - work.top - 24;
    window = CreateWindowExW(0, name, caption, style, work.left + 12, work.top + 12, fw, fh, NULL,
                             NULL, wc.hInstance, NULL);
    if (!window) {
        fprintf(stderr, "CreateWindowExW failed: %lu\n", (unsigned long)GetLastError());
        return 0;
    }
    SendMessageW(window, WM_SETICON, ICON_BIG, (LPARAM)wc.hIcon);
    SendMessageW(window, WM_SETICON, ICON_SMALL,
                 (LPARAM)LoadImageW(wc.hInstance, MAKEINTRESOURCEW(1), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR));
    alive = 1;
    layout();
    tm_set_dialog_owner(window);
    ShowWindow(window, SW_SHOW);
    UpdateWindow(window);
    return 1;
}
void tmui_button(int id, int x, int y, int w, int h, const char *label, int visible, int enabled,
                 int active) {
    Control *c = NULL;
    for (int i = 0; i < control_count; i++)
        if (controls[i].id == id)
            c = controls + i;
    if (!c) {
        if (control_count == MAX_CONTROLS)
            return;
        c = controls + control_count++;
        c->id = id;
        c->enabled = -1;
        c->active = -1;
        c->hwnd =
            CreateWindowExW(0, L"BUTTON", L"", WS_CHILD | WS_TABSTOP | BS_PUSHLIKE | BS_CHECKBOX, 0,
                            0, 1, 1, window, (HMENU)(INT_PTR)id, GetModuleHandleW(NULL), NULL);
        if (!c->hwnd)
            return;
        c->x = x;
        c->y = y;
        c->w = w;
        c->h = h;
        place(c);
    }
    if (strcmp(c->label, label)) {
        wchar_t text[192];
        utf16(label, text, 192);
        SetWindowTextW(c->hwnd, text);
        snprintf(c->label, sizeof(c->label), "%s", label);
    }
    if (c->visible != visible) {
        ShowWindow(c->hwnd, visible ? SW_SHOW : SW_HIDE);
        c->visible = visible;
    }
    if (c->enabled != enabled) {
        EnableWindow(c->hwnd, enabled);
        c->enabled = enabled;
    }
    if (c->active != active) {
        SendMessageW(c->hwnd, BM_SETCHECK, active ? BST_CHECKED : BST_UNCHECKED, 0);
        c->active = active;
    }
}
void tmui_textfield(int slot, int visible, int x, int y, int w, int h, const char *text) {
    if (slot < 0 || slot >= 3) return;
    Control *edit = edits + slot;
    HWND input = inputs[slot];
    if (!input && !visible) return;
    if (!input) {
        input = inputs[slot] = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
            WS_CHILD | WS_TABSTOP | ES_AUTOHSCROLL, 0, 0, 1, 1, window,
            (HMENU)(INT_PTR)(INPUT_ID+slot), GetModuleHandleW(NULL), NULL);
        if (!input) return;
        SendMessageW(input, EM_SETLIMITTEXT, 30, 0);
        edit->hwnd = input;
    }
    if (edit->x != x || edit->y != y || edit->w != w || edit->h != h) {
        edit->x = x; edit->y = y; edit->w = w; edit->h = h;
        place(edit);
    }
    if (visible && !edit->visible) {
        wchar_t next[32]; utf16(text, next, 32);
        setting_text = 1; SetWindowTextW(input, next); setting_text = 0;
        SendMessageW(input, EM_SETSEL, 0, (LPARAM)-1);
    }
    if (edit->visible != visible) {
        HWND previous = visible_input();
        ShowWindow(input, visible ? SW_SHOW : SW_HIDE);
        edit->visible = visible;
        if (visible && !previous) SetFocus(input);
        else if (!visible && GetFocus() == input) SetFocus(window);
    }
}
void tmui_input(int visible, int x, int y, int w, int h, const char *text) {
    tmui_textfield(0, visible, x, y, w, h, text);
}
void tmui_show(void *image) {
    int w, h, stride;
    const unsigned char *data = cvb_bgr(image, &w, &h, &stride);
    if (!data || w != logical_w || h != logical_h)
        return;
    int pitch = (w * 3 + 3) & ~3;
    size_t size = (size_t)pitch * h;
    if (pixel_capacity < size) {
        unsigned char *next = (unsigned char *)realloc(pixels, size);
        if (!next)
            return;
        pixels = next;
        pixel_capacity = size;
        pixels_valid = 0;
    }
    if (pixels_valid) {
        int changed = 0;
        for (int y = 0; y < h && !changed; y++)
            changed =
                memcmp(pixels + (size_t)y * pitch, data + (size_t)y * stride, (size_t)w * 3) != 0;
        if (!changed)
            return;
    }
    for (int y = 0; y < h; y++)
        memcpy(pixels + (size_t)y * pitch, data + (size_t)y * stride, (size_t)w * 3);
    memset(&bitmap, 0, sizeof(bitmap));
    bitmap.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bitmap.bmiHeader.biWidth = w;
    bitmap.bmiHeader.biHeight = -h;
    bitmap.bmiHeader.biPlanes = 1;
    bitmap.bmiHeader.biBitCount = 24;
    bitmap.bmiHeader.biCompression = BI_RGB;
    pixels_valid = 1;
    frame_dirty = 1;
    InvalidateRect(window, NULL, FALSE);
    UpdateWindow(window);
}
int tmui_poll(TMUI_Event *e, int timeout_ms) {
    if (dequeue(e))
        return 1;
    DWORD start = GetTickCount();
    MSG msg;
    while (alive) {
        while (PeekMessageW(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                alive = 0;
                break;
            }
            if (msg.message == WM_KEYDOWN && !text_input(msg.hwnd) && GetKeyState(VK_CONTROL) < 0 &&
                (msg.wParam == 'Z' || msg.wParam == 'Y')) {
                TMUI_Event key = {0};
                key.type = TMUI_KEY;
                key.code = msg.wParam == 'Y' || GetKeyState(VK_SHIFT) < 0 ? 25 : 26;
                enqueue(key);
                continue;
            }
            if (msg.message == WM_KEYDOWN && (msg.wParam == VK_RETURN || msg.wParam == VK_SPACE) &&
                msg.hwnd != window && !text_input(msg.hwnd) && IsWindowEnabled(msg.hwnd)) {
                TMUI_Event command = {0};
                command.type = TMUI_COMMAND;
                command.code = GetDlgCtrlID(msg.hwnd);
                enqueue(command);
                if (visible_input()) SetFocus(visible_input());
                continue;
            }
            /* Keep shortcuts working after a mouse click focuses a child control. */
            if (msg.message == WM_KEYDOWN && msg.wParam == VK_DELETE && !text_input(msg.hwnd)) {
                TMUI_Event key = {0};
                key.type = TMUI_KEY;
                key.code = 65535;
                enqueue(key);
                continue;
            }
            if (msg.message == WM_CHAR && visible_input() && !text_input(msg.hwnd) && msg.wParam != 13 &&
                msg.wParam != 27) {
                HWND field = visible_input();
                SetFocus(field);
                SendMessageW(field, WM_CHAR, msg.wParam, msg.lParam);
                continue;
            }
            if (msg.message == WM_CHAR &&
                (!text_input(msg.hwnd) || msg.wParam == 13 || msg.wParam == 27)) {
                TMUI_Event key = {0};
                key.type = TMUI_KEY;
                key.code = (int)msg.wParam;
                enqueue(key);
                continue;
            }
            if (msg.message == WM_KEYDOWN && msg.wParam == VK_TAB && IsDialogMessageW(window, &msg))
                continue;
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        if (dequeue(e))
            return 1;
        int remaining = timeout_ms - (int)(GetTickCount() - start);
        if (remaining <= 0)
            break;
        MsgWaitForMultipleObjects(0, NULL, FALSE, (DWORD)remaining, QS_ALLINPUT);
    }
    return 0;
}
int tmui_alive(void) { return alive; }
void tmui_busy(int value) {
    busy = value;
    SetCursor(LoadCursorW(NULL, busy ? IDC_WAIT : IDC_ARROW));
}
void tmui_close(void) {
    tm_set_dialog_owner(NULL);
    if (IsWindow(window))
        DestroyWindow(window);
    if (font)
        DeleteObject(font);
    release_frame();
    free(pixels);
    pixels = NULL;
    pixel_capacity = 0;
    pixels_valid = 0;
    window = NULL;
    memset(inputs, 0, sizeof(inputs));
    font = NULL;
    memset(controls, 0, sizeof(controls));
    memset(edits, 0, sizeof(edits));
}
#else
static void mouse_queue(int code, int x, int y, int flags, void *ctx) {
    (void)ctx;
    TMUI_Event e = {0};
    e.type = TMUI_MOUSE;
    e.code = code;
    e.x = x;
    e.y = y;
    e.flags = flags;
    enqueue(e);
}
int tmui_open(const char *title, int w, int h) {
    (void)w;
    (void)h;
    queue_head = queue_count = 0;
    snprintf(window_title, sizeof(window_title), "%s", title);
    return cvb_open_window(title, mouse_queue, NULL);
}
void tmui_button(int id, int x, int y, int w, int h, const char *label, int visible, int enabled,
                 int active) {
    (void)id;
    (void)x;
    (void)y;
    (void)w;
    (void)h;
    (void)label;
    (void)visible;
    (void)enabled;
    (void)active;
}
void tmui_textfield(int slot, int visible, int x, int y, int w, int h, const char *text) {
    (void)slot; (void)visible; (void)x; (void)y; (void)w; (void)h; (void)text;
}
void tmui_input(int visible, int x, int y, int w, int h, const char *text) {
    (void)visible;
    (void)x;
    (void)y;
    (void)w;
    (void)h;
    (void)text;
}
void tmui_show(void *image) { cvb_show(window_title, image); }
int tmui_poll(TMUI_Event *e, int timeout_ms) {
    if (dequeue(e))
        return 1;
    int key = cvb_key(timeout_ms);
    if (key >= 0) {
        TMUI_Event ke = {0};
        ke.type = TMUI_KEY;
        ke.code = key;
        enqueue(ke);
    }
    return dequeue(e);
}
int tmui_alive(void) { return cvb_window_alive(window_title); }
void tmui_busy(int busy) { (void)busy; }
void tmui_close(void) { cvb_close(); }
#endif

static double splash_clock(void) {
#ifdef _WIN32
    LARGE_INTEGER counter, frequency;
    QueryPerformanceCounter(&counter); QueryPerformanceFrequency(&frequency);
    return 1000.0 * (double)counter.QuadPart / (double)frequency.QuadPart;
#else
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000.0 + t.tv_nsec / 1000000.0;
#endif
}
int tmui_splash(void) {
#ifdef _WIN32
    BOOL animations = TRUE;
    if (SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0, &animations, 0) && !animations)
        return tmui_alive();
#endif
    TM_Splash *s = tm_splash_create();
    if (!s) return tmui_alive(); /* Cosmetic failure must not block the application. */
    double start = splash_clock(), next = start;
    while (tmui_alive()) {
        double now = splash_clock();
        if (now - start >= TM_SPLASH_DURATION_MS) break;
        if (now >= next) {
            void *frame = tm_splash_frame(s, now-start);
            if (!frame) break;
            tmui_show(frame); cvb_free(frame);
            next = now + 16;
        }
        TMUI_Event event;
        int wait = (int)(next-splash_clock());
        if (wait < 1) wait = 1;
        if (wait > 16) wait = 16;
        if (tmui_poll(&event, wait) &&
            (event.type == TMUI_KEY || (event.type == TMUI_MOUSE && event.code == 1))) break;
    }
    tm_splash_free(s);
    return tmui_alive();
}

/* The language choice precedes loading command-line photographs and projects. */
int tmui_choose_language(void) {
    void *canvas = cvb_create(1280, 800, 0x131a25);
    if (!canvas) return -1;
    cvb_text(canvas, 460, 235, "TaylorMeter", 48, 0xe6eef8);
    cvb_text(canvas, 405, 300, "Choose language / Русский или English", 22, 0x62b7fa);
    const char *names[] = {"Русский / Russian", "English"};
    for (int i = 0; i < 2; i++) {
        int x = 360 + 290*i;
        cvb_rect(canvas, x, 345, 260, 56, 0x2b3e54, -1);
        cvb_text(canvas, x+20, 380, names[i], 24, 0xe6eef8);
        tmui_button(100+i, x, 345, 260, 56, names[i], 1, 1, 0);
    }
    tmui_show(canvas); cvb_free(canvas);
    int chosen = -1;
    while (tmui_alive()) {
        TMUI_Event event;
        if (!tmui_poll(&event, 30)) continue;
        if (event.type == TMUI_COMMAND && (event.code == 100 || event.code == 101)) chosen = event.code-100;
        if (event.type == TMUI_MOUSE && event.code == 1 && event.y >= 345 && event.y < 401) {
            if (event.x >= 360 && event.x < 620) chosen = 0;
            if (event.x >= 650 && event.x < 910) chosen = 1;
        }
        if (event.type == TMUI_KEY) {
            if (event.code == 'r' || event.code == 'R' || event.code == '1') chosen = 0;
            if (event.code == 'e' || event.code == 'E' || event.code == '2') chosen = 1;
            if (event.code == 27) break;
        }
        if (chosen >= 0) break;
    }
    for (int i = 0; i < 2; i++) tmui_button(100+i, 360+290*i, 345, 260, 56, names[i], 0, 0, 0);
    if (chosen >= 0) tm_set_language(chosen);
    return chosen;
}
