#include "tm.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #x);                                   \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)
int main(void) {
    TM_Photo *p = (TM_Photo *)calloc(2, sizeof(TM_Photo)),
             *q = (TM_Photo *)calloc(2, sizeof(TM_Photo));
    CHECK(p && q);
    TM_State *s = &p[0].state;
    s->sensitivity = 50;
    s->min_length_px = 3;
    CHECK(tm_set_channel(s, (TM_Point){10, 50}, (TM_Point){1010, 50}, (TM_Point){10, 60}));
    CHECK(tm_manual_calibrate(s, (TM_Point){0, 200}, (TM_Point){100, 200}, 10));
    CHECK(tm_add_bubble(s, 20, 50, TM_MANUAL, 1) == 0);
    CHECK(tm_add_bubble(s, 50.25, 100, TM_MANUAL, 1) == 1);
    CHECK(tm_add_bubble(s, 100, 150, TM_MANUAL, 1) == 2);
    CHECK(tm_add_bubble(s, 300, 350, TM_MANUAL, 1) == 3);
    CHECK(tm_add_bubble(s, 99, 125, 0, 1) == -1);
    CHECK(s->count == 4);
    CHECK(fabs(tm_bubble_mm(s, 0) - 3) < 1e-12);
    CHECK(fabs(tm_slug_mm(s, 0) - 0.025) < 1e-12);
    CHECK(tm_slug_mm(s, 1) == 0);
    CHECK(fabs(tm_slug_mm(s, 2) - 15) < 1e-12);
    CHECK(isnan(tm_slug_mm(s, 3)));
    CHECK(tm_move_boundary(s, 1, 0, 52));
    CHECK(fabs(tm_slug_mm(s, 0) - 0.2) < 1e-12);
    CHECK(tm_move_boundary(s, 1, 0, 40));
    CHECK(s->bubbles[1].left == 50);
    CHECK(tm_move_boundary(s, 1, 0, 50.25));
    char error[512];
    CHECK(tm_validate(s, error, sizeof(error)));
    CHECK(!tm_export_xlsx("unreviewed.xlsx", p, 1, error, sizeof(error)));
    s->reviewed = 1;
    snprintf(p[0].path, TM_PATH, "/папка/фото & 1.jpg");
    p[0].width = 1020;
    p[0].height = 400;
    p[1].state = *s;
    p[1].state.count = 1;
    snprintf(p[1].path, TM_PATH, "/другая папка/фото & 1.jpg");
    p[1].width = 1020;
    p[1].height = 400;
    CHECK(tm_export_xlsx("test_measurements.xlsx", p, 2, error, sizeof(error)));
    CHECK(tm_save_project("test_session.tmc", p, 2));
    CHECK(tm_load_project("test_session.tmc", q, 2, error, sizeof(error)) == 2);
    CHECK(!strcmp(q[0].path, p[0].path));
    CHECK(q[0].state.count == 4);
    CHECK(q[0].state.reviewed == 1);
    CHECK(q[0].state.bubbles[1].left == 50.25);
    CHECK(tm_slug_mm(&q[0].state, 1) == 0);
    FILE *f = tm_fopen("bad_session.tmc", "wb");
    CHECK(f);
    fwrite("TMC3", 1, 4, f);
    fclose(f);
    CHECK(tm_load_project("bad_session.tmc", q, 2, error, sizeof(error)) < 0);
    tm_delete_bubble(s, 1);
    CHECK(s->count == 3);
    CHECK(fabs(tm_slug_mm(s, 0) - 5) < 1e-12);
    CHECK(!s->reviewed);
    /* Oblique channel: coordinates are arc length on its axis, not raw x. */
    CHECK(tm_set_channel(s, (TM_Point){0, 0}, (TM_Point){600, 800}, (TM_Point){8, -6}));
    CHECK(tm_manual_calibrate(s, (TM_Point){0, 0}, (TM_Point){60, 80}, 10));
    CHECK(tm_add_bubble(s, 20, 120, TM_MANUAL, 1) == 0);
    CHECK(fabs(tm_bubble_mm(s, 0) - 10) < 1e-12);
    s->calibration.axis_x = 0;
    s->calibration.axis_y = 1;
    CHECK(!tm_validate(s, error, sizeof(error)));
    /* Physical thousandths and smaller positive gaps survive editing,
       serialization and numeric Excel export; no minimum slug is imposed. */
    memset(p, 0, sizeof(*p));
    s = &p[0].state;
    s->sensitivity = 50;
    s->min_length_px = 3;
    snprintf(p[0].path, TM_PATH, "small_gaps.png");
    p[0].width = 200;
    p[0].height = 80;
    CHECK(tm_set_channel(s, (TM_Point){0, 40}, (TM_Point){199, 40}, (TM_Point){0, 50}));
    CHECK(tm_manual_calibrate(s, (TM_Point){0, 60}, (TM_Point){100, 60}, 10));
    CHECK(tm_add_bubble(s, 10, 20, TM_MANUAL, 1) == 0);
    CHECK(tm_add_bubble(s, 20.1, 30, TM_MANUAL, 1) == 1);
    CHECK(tm_add_bubble(s, 30.01, 40, TM_MANUAL, 1) == 2);
    CHECK(tm_add_bubble(s, 40.001, 50, TM_MANUAL, 1) == 3);
    const double small[] = {.01, .001, .0001};
    for (int i = 0; i < 3; i++)
        CHECK(fabs(tm_slug_mm(s, i) - small[i]) < 1e-12);
    s->reviewed = 1;
    CHECK(tm_save_project("small_gaps.tmc", p, 1));
    CHECK(tm_load_project("small_gaps.tmc", q, 2, error, sizeof(error)) == 1);
    for (int i = 0; i < 3; i++)
        CHECK(fabs(tm_slug_mm(&q[0].state, i) - small[i]) < 1e-12);
    CHECK(tm_export_xlsx("small_gaps.xlsx", p, 1, error, sizeof(error)));
    free(p);
    free(q);
    puts("model, N-1 slugs, subpixel/zero gaps, calibration, XLSX and sessions: PASS");
    return 0;
}
