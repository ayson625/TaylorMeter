#ifndef TM_RECOGNITION_H
#define TM_RECOGNITION_H

#include "tm.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int runs, min_count, max_count, unstable, recovered;
    /* Mean pairwise one-to-one repeatability, NOT measurement accuracy.
       Every match requires BOTH endpoints to lie within the tolerance. */
    double agreement;
} TM_RecognitionReport;

/* Detect at the current sensitivity and at distinct, clamped +/-10 values.
   Preserve the base result, marking bubbles which do not repeat as uncertain.
   A zero base result can be replaced by one complete neighbouring result only
   when BOTH neighbours exist and match each other at least 80 percent.
   The tolerance is max(1.5, 10% of strip height), converted to source pixels
   and capped at 6 source pixels. No unions, inferred intervals, or averaged
   endpoints are produced.
   Returns the bubble count, or -1 on error with *state completely unchanged. */
int tm_detect_checked(const uint8_t *gray, int width, int height, int stride, TM_State *state,
                      TM_RecognitionReport *report);

typedef struct {
    int trials, matched, missed, extra, accepted;
    double sensitivity, mean_error_px, tolerance_px;
} TM_TrainingReport;

/* Fit sensitivity on this same, user-reviewed photograph, using at least
   three valid labelled bubbles. This is parameter fitting, NOT a neural
   network and NOT an independent accuracy estimate. Endpoint distances are
   in original image pixels. Tolerance is max(2, 10% of strip height), converted
   to source pixels and capped at 6; a wide ROI cannot excuse large endpoint
   errors. mean_error_px is INFINITY when nothing matches.
   accepted means both precision and recall are at least 90 percent against
   the supplied labels. The labels and all of *truth are always unchanged.
   Return 1 after completed trials (including rejected fits), 0 for invalid or
   unreviewed labels, or -1 for an image/allocation/detector error. */
int tm_tune_recognition(const uint8_t *gray, int width, int height, int stride,
                        const TM_State *truth, TM_TrainingReport *report);

#ifdef __cplusplus
}
#endif
#endif
