"""Verify exported grouping, readable text styles and numeric means without Excel."""
import math
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(Path('workflow_groups.xlsx')) as archive:
    styles = ET.fromstring(archive.read('xl/styles.xml'))
    fills = styles.find('s:fills', ns)
    formats = styles.find('s:cellXfs', ns)
    sheet = ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
    cells = {c.attrib['r']: c for c in sheet.findall('.//s:c', ns)}
    def color(c):
        fill = fills[int(formats[int(c.attrib.get('s', 0))].attrib['fillId'])]
        return fill.find('s:patternFill/s:fgColor', ns).attrib['rgb']
    merges = {m.attrib['ref'] for m in sheet.findall('s:mergeCells/s:mergeCell', ns)}
    assert {'A1:D1', 'E1:H1', 'I1:J1'} <= merges
    assert color(cells['A1']) == 'FF304C60'
    assert color(cells['A3']) == 'FFF5E2E0' and color(cells['B3']) == 'FFDDECF8'
    for name in ('xl/worksheets/sheet1.xml', 'xl/worksheets/sheet2.xml'):
        for c in ET.fromstring(archive.read(name)).findall('.//s:c', ns):
            text = ''.join(c.itertext())
            if c.attrib.get('t') == 'inlineStr' and text.strip():
                assert color(c) != 'FFFFFFFF', c.attrib['r']
            elif c.find('s:f', ns) is not None:
                assert color(c) == 'FFC6EFCE'
            elif c.find('s:v', ns) is not None:
                assert color(c) == 'FFFFFFFF'
    for col in 'ABCDEFGHIJ':
        c = cells[col+'7']
        last = 5 if col in 'ACEGI' else 4
        assert c.find('s:f', ns).text == f'AVERAGE({col}4:{col}{last})'
        expected = sum(float(cells[col+str(row)].find('s:v', ns).text) for row in range(4,last+1))/(last-3)
        assert math.isclose(float(c.find('s:v', ns).text), expected, rel_tol=1e-12)
print('XLSX grouping, text colors, white numbers and green formula means: PASS')
