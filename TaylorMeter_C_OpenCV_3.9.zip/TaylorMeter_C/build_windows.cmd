@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo Install CMake and open a Developer Command Prompt for Visual Studio.
  exit /b 1
)
if "%OpenCV_DIR%"=="" (
  echo Set OpenCV_DIR to the folder containing OpenCVConfig.cmake.
  echo Example: set OpenCV_DIR=C:\opencv\build
  exit /b 1
)
cmake -S . -B build -DOpenCV_DIR="%OpenCV_DIR%" -DTM_LIBRAW_SOURCE_DIR="%CD%\vendor\LibRaw" -DTM_BUILD_TESTS=ON
if errorlevel 1 exit /b 1
cmake --build build --config Release
if errorlevel 1 exit /b 1
ctest --test-dir build -C Release --output-on-failure
if errorlevel 1 exit /b 1
cmake --install build --config Release --prefix "%CD%"
if errorlevel 1 exit /b 1
echo Build complete. If your OpenCV uses DLLs, place them beside TaylorMeter.exe.
