# TaylorMeter

A two-second startup animation introduces the app icon and TaylorMeter name.
Press a key or click to skip directly to language selection. Windows animation
preferences are respected; headless processing has no splash screen.
The logo is embedded in the executable, so shortcuts need no external assets.

Desktop measurement of capsule-shaped drops and the liquid gaps between them in
microchannel photographs. Version 3.9, C11 with an OpenCV C++ bridge and LibRaw.
The Windows UI uses native Win32 controls. Russian and English are available at startup.

![Application icon](resources/TaylorMeter.png)

## Run on Windows

Use the separate Windows release archive, extract it completely, then open
`TaylorMeter.exe`. No terminal or Python installation is required.
`create_shortcut.cmd` creates a TaylorMeter desktop shortcut.
The source archive intended for GitHub does not contain a compiled executable.

If the application fails to start, run `diagnose_windows.cmd`. It records the
launch result in `saves/photo/TaylorMeter_launch.txt`. Application diagnostics go to
`saves/photo/TaylorMeter_startup.log` (or `%TEMP%` if the folder is read-only).
The supplied binary targets Windows 10/11 x64 and links the image libraries statically.

## Workflow

Open photos or a `.tmc` project, set the flow pair, verify the channel, scale and
drop endpoints, then mark the measurements reviewed and export. Close photo
excludes it from results; Undo restores it. New photos inherit the last flow pair.
Keep the original photographs: project files store paths and annotations, not image pixels.

- `saves/excel/TaylorMeter_<timestamp>_<sequence>.xlsx`: measurements.
- `saves/photo/TaylorMeter_<timestamp>_<sequence>/`: annotated photographs,
  channel crops and the corresponding `.tmc` project.
- `saves/photo/TaylorMeter_recovery.tmc`: recovery of an unsaved project on normal exit.

The workbook groups adjacent photographs by flow. Headers use muted colors;
measurements stay white and arithmetic mean formulas green. Shot numbers are
preserved in filenames. Older result folders are left intact.

## Build and test

Required: CMake 3.16+, C11/C++11 compiler, OpenCV 4 (`core`, `imgproc`, `imgcodecs`,
`highgui`). LibRaw is optional; the bundled source enables RAW decoding.

Ubuntu/Debian:

```sh
sudo apt-get install build-essential cmake libopencv-dev libraw-dev python3
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
./build/TaylorMeter examples/demo.png
```

Windows: open an x64 Developer Command Prompt for Visual Studio, set `OpenCV_DIR`
to the directory containing `OpenCVConfig.cmake`, then run `build_windows.cmd`.
For a dynamic OpenCV build, install its matching runtime DLLs beside the executable
or add the OpenCV runtime directory to PATH before building and testing.
The script builds the bundled LibRaw sources and runs the tests.

Linux GUI file selection uses command-line arguments. Its OpenCV text renderer has
limited Cyrillic support; use English. The Windows interface supports both languages.

## Upload to GitHub

Extract the source archive and upload the **contents** of its TaylorMeter folder
to the root of an empty repository, including `.gitignore` and `.github`.
Alternatively, from that folder:

```sh
git init
git add .
git commit -m "TaylorMeter 3.9"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/TaylorMeter.git
git push -u origin main
```

The included GitHub Actions workflow builds and tests on Linux. It does not publish
a release. Put the separate Windows ZIP in a GitHub Release if you want to distribute
the executable. Local measurements and save folders are excluded by `.gitignore`.

## Source layout

`src/` contains C application logic, native XLSX/TMC writers, Win32 UI and the
OpenCV bridge. `include/` contains public headers. `tests/` contains synthetic
and small cropped-image regression fixtures. `examples/demo.png` is the synthetic demo.
`resources/` contains the icon; `vendor/LibRaw` and `licenses/` contain dependency sources
and notices. See [THIRD_PARTY.md](THIRD_PARTY.md).

Detection results need review. Saving a project does not train a neural network;
the existing calibration feature tunes detection sensitivity against reviewed boundaries.

Project source licensing is not specified. Third-party component licenses remain
in force as documented in their notices.

[Русское руководство](README_RU.md) · [English usage](README_EN.md)
