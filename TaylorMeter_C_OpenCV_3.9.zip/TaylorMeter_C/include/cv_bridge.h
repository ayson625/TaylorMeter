#ifndef CV_BRIDGE_H
#define CV_BRIDGE_H
#include "tm.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef void (*CVB_Mouse)(int event, int x, int y, int flags, void *context);
void *cvb_load(const char *path, int *width, int *height);
void *cvb_create(int width, int height, int color);
void *cvb_decode_rgba(const unsigned char *data, size_t size);
void cvb_composite(void *dst, void *src, int x, int y, int width, int height, double opacity);
void cvb_radial_glow(void *dst, int x, int y, double radius, int color, double opacity);
int cvb_text_width(const char *text, int height);
void *cvb_clone(void *image);
void *cvb_resize(void *image, int width, int height);
void cvb_free(void *image);
void *cvb_strip(void *image, const TM_Channel *channel, int *width, int *height);
void *cvb_ruler_roi(void *image, const TM_Channel *channel, int x, int y, int w, int h,
                    double *origin);
const uint8_t *cvb_gray(void *image, int *w, int *h, int *stride);
const uint8_t *cvb_bgr(void *image, int *w, int *h, int *stride);
int cvb_line_segments(void *image, const TM_Rect *region, TM_Segment *out, int capacity);
int tm_image_channel(void *image, const TM_Rect *constraint, TM_Channel *out, TM_Rect *region);
void cvb_line(void *image, double x1, double y1, double x2, double y2, int color, int thickness);
void cvb_rect(void *image, int x, int y, int w, int h, int color, int thickness);
void cvb_circle(void *image, int x, int y, int radius, int color);
void cvb_tint_quad(void *image, const TM_Point corners[4], int color, double alpha);
void cvb_text(void *image, int x, int y, const char *text, int height, int color);
void cvb_blit(void *dst, void *src, double zoom, double pan_x, double pan_y, int x, int y, int w,
              int h);
int cvb_save(void *image, const char *path);
int cvb_open_window(const char *title, CVB_Mouse callback, void *context);
void cvb_show(const char *title, void *image);
int cvb_key(int delay_ms);
int cvb_window_alive(const char *title);
void cvb_close(void);
const char *cvb_error(void);
#ifdef __cplusplus
}
#endif
#endif
