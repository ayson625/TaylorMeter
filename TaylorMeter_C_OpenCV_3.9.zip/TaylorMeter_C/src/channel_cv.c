#include "cv_bridge.h"

int tm_image_channel(void *image, const TM_Rect *constraint, TM_Channel *out, TM_Rect *region) {
    TM_Segment lines[96];
    int n = cvb_line_segments(image, constraint, lines, 96), w, h, stride;
    const uint8_t *g = cvb_gray(image, &w, &h, &stride);
    return n >= 2 && g && tm_find_channel(g, w, h, stride, lines, n, constraint, out, region);
}
