#ifndef TM_H
#define TM_H
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define TM_VERSION "3.9.0"
#define TM_MAX_BUBBLES 2048
#define TM_MAX_TICKS 4096
#define TM_MAX_PHOTOS 128
#define TM_PATH 4096
#define TM_UNCERTAIN 1u
#define TM_MANUAL 2u
#define TM_PARTIAL 4u

typedef struct {
    double x, y;
} TM_Point;
typedef struct {
    TM_Point a, b;
    double half_width;
    int valid;
} TM_Channel;
typedef struct {
    int x, y, w, h, valid, automatic;
} TM_Rect;
typedef struct {
    TM_Point a, b;
} TM_Segment;
typedef struct {
    double left, right, confidence;
    unsigned flags;
} TM_Bubble;
typedef struct {
    double x, mm;
} TM_Tick;
typedef struct {
    double mm_per_px, residual_px, drift_percent;
    double axis_x, axis_y; /* ruler direction in source coordinates */
    int valid, manual, count;
    TM_Tick ticks[TM_MAX_TICKS]; /* source projection -> physical mm */
} TM_Calibration;
typedef struct {
    TM_Channel channel;
    TM_Rect region;
    TM_Calibration calibration;
    int count, reviewed, partial_count;
    double sensitivity, min_length_px;
    double flow[2];
    int flow_valid, excluded;
    TM_Bubble bubbles[TM_MAX_BUBBLES];
} TM_State;
typedef struct {
    char path[TM_PATH];
    int width, height;
    void *image, *strip;
    TM_State state;
} TM_Photo;

#ifdef __cplusplus
extern "C" {
#endif
double tm_channel_length(const TM_Channel *c);
TM_Point tm_channel_point(const TM_Channel *c, double s, double t);
int tm_set_channel(TM_State *s, TM_Point a, TM_Point b, TM_Point wall);
int tm_set_channel_rect(TM_State *s, TM_Rect rectangle, int image_w, int image_h);
TM_Rect tm_channel_bounds(const TM_Channel *channel, int image_w, int image_h);
int tm_find_channel(const uint8_t *gray, int w, int h, int stride, const TM_Segment *segments,
                    int count, const TM_Rect *constraint, TM_Channel *channel, TM_Rect *region);
int tm_add_bubble(TM_State *s, double left, double right, unsigned flags, double confidence);
int tm_move_boundary(TM_State *s, int index, int side, double position);
void tm_delete_bubble(TM_State *s, int index);
int tm_validate(const TM_State *s, char *error, size_t cap);
double tm_distance_mm(const TM_State *s, double left, double right);
double tm_bubble_mm(const TM_State *s, int index);
double tm_slug_mm(const TM_State *s, int index);
int tm_manual_calibrate(TM_State *s, TM_Point a, TM_Point b, double mm);
int tm_detect(const uint8_t *gray, int width, int height, int stride, TM_State *state);
int tm_find_ruler(const uint8_t *gray, int width, int height, int stride, double origin_projection,
                  TM_Calibration *out);

int tm_export_xlsx(const char *path, const TM_Photo *photos, int count, char *error, size_t cap);
int tm_save_project(const char *path, const TM_Photo *photos, int count);
int tm_load_project(const char *path, TM_Photo *photos, int capacity, char *error, size_t cap);
FILE *tm_fopen(const char *path, const char *mode);
int tm_replace_file(const char *source, const char *dest);
void tm_remove_file(const char *path);
const char *tm_basename(const char *path);
int tm_choose_file(char *path, size_t capacity, int save, const char *kind);
void tm_set_dialog_owner(void *window);
const char *tm_dialog_error(void);
void tm_platform_init(void);
void tm_set_language(int english);
int tm_is_english(void);
const char *tm_text(const char *ru, const char *en);
int tm_flow_equal(const TM_State *a, const TM_State *b);
int tm_parse_flow(const char *text, double *value);
int tm_export_stem(const TM_Photo *p, int index, char *out, size_t cap);
int tm_create_export_path(char *out, size_t cap);
int tm_saves_directory(char *out, size_t cap);
int tm_photo_directory(char *out, size_t cap);
int tm_export_photo_base(const char *xlsx, char *out, size_t cap);
int tm_relocate_source(char *source, size_t cap, const char *project);
int tm_run_gui(int argc, char **argv);
#ifdef __cplusplus
}
#endif
#endif
