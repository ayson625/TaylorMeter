/* Independent repeated runs check sensitivity to a parameter change; they
   cannot prove that the observed objects are physically the right bubbles. */
#include "recognition.h"
#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int count;
    double error;
} Match;

static double clamp_sensitivity(double v) { return fmax(0, fmin(100, v)); }

static int valid_pixels(const uint8_t *gray, int w, int h, int stride) {
    /* The detector indexes rows with int arithmetic. Reject overflow before
       passing it an image; callers still own the actual pixel allocation. */
    return gray && w >= 12 && h >= 5 && stride >= w && stride <= INT_MAX / h;
}

static int valid_settings(const TM_State *s) {
    if (!s || !s->channel.valid || !isfinite(s->channel.a.x) || !isfinite(s->channel.a.y) ||
        !isfinite(s->channel.b.x) || !isfinite(s->channel.b.y) ||
        !isfinite(s->channel.half_width) || s->channel.half_width < 2 ||
        !isfinite(s->sensitivity) || !isfinite(s->min_length_px) || s->min_length_px < 0)
        return 0;
    double length = tm_channel_length(&s->channel);
    return isfinite(length) && length >= 10;
}

static int valid_intervals(const TM_State *s) {
    if (s->count < 0 || s->count > TM_MAX_BUBBLES)
        return 0;
    double previous = 0, length = tm_channel_length(&s->channel);
    for (int i = 0; i < s->count; i++) {
        const TM_Bubble *b = &s->bubbles[i];
        if (!isfinite(b->left) || !isfinite(b->right) || b->left < previous ||
            b->right <= b->left || b->right > length)
            return 0;
        previous = b->right;
    }
    return 1;
}

static int better(Match a, Match b) {
    return a.count > b.count || (a.count == b.count && a.error < b.error);
}

/* Ordered dynamic programming gives a maximum-cardinality one-to-one
   assignment, with minimum total endpoint error among equally sized matches.
   A missed bubble cannot be reused to match two neighbouring predictions.
   Only two score rows are needed; traceback is allocated only for flags. */
static int match_pairs(const TM_State *a, const TM_State *b, double tolerance,
                       unsigned char *matched_a, Match *result) {
    int n = a->count, m = b->count;
    *result = (Match){0, 0};
    if (matched_a)
        memset(matched_a, 0, (size_t)n);
    if (!n || !m)
        return 1;
    size_t columns = (size_t)m + 1;
    Match *rows = (Match *)calloc(columns * 2, sizeof(Match));
    unsigned char *path = matched_a ? (unsigned char *)malloc((size_t)n * m) : NULL;
    if (!rows || (matched_a && !path)) {
        free(rows);
        free(path);
        return 0;
    }
    Match *old = rows, *current = rows + columns;
    for (int i = 1; i <= n; i++) {
        current[0] = (Match){0, 0};
        for (int j = 1; j <= m; j++) {
            Match best = old[j];
            unsigned char direction = 1; /* skip a */
            if (better(current[j - 1], best)) {
                best = current[j - 1];
                direction = 2; /* skip b */
            }
            double dl = fabs(a->bubbles[i - 1].left - b->bubbles[j - 1].left);
            double dr = fabs(a->bubbles[i - 1].right - b->bubbles[j - 1].right);
            if (dl <= tolerance && dr <= tolerance) {
                Match diagonal = {old[j - 1].count + 1, old[j - 1].error + dl + dr};
                if (better(diagonal, best)) {
                    best = diagonal;
                    direction = 3;
                }
            }
            current[j] = best;
            if (path)
                path[(size_t)(i - 1) * m + (j - 1)] = direction;
        }
        Match *swap = old;
        old = current;
        current = swap;
    }
    *result = old[m];
    if (path) {
        int i = n, j = m;
        while (i && j) {
            unsigned char direction = path[(size_t)(i - 1) * m + (j - 1)];
            if (direction == 3) {
                matched_a[--i] = 1;
                j--;
            } else if (direction == 1)
                i--;
            else
                j--;
        }
    }
    free(path);
    free(rows);
    return 1;
}

static double pair_agreement(const TM_State *a, const TM_State *b, Match match) {
    int maximum = a->count > b->count ? a->count : b->count;
    return maximum ? (double)match.count / maximum : 1;
}

int tm_detect_checked(const uint8_t *gray, int w, int h, int stride, TM_State *state,
                      TM_RecognitionReport *report) {
    TM_RecognitionReport out = {0};
    if (report)
        *report = out;
    if (!valid_pixels(gray, w, h, stride) || !valid_settings(state))
        return -1;
    TM_State *runs = (TM_State *)malloc(3 * sizeof(TM_State));
    unsigned char *matched = (unsigned char *)malloc(TM_MAX_BUBBLES);
    unsigned char *stable = (unsigned char *)malloc(TM_MAX_BUBBLES);
    if (!runs || !matched || !stable) {
        free(runs);
        free(matched);
        free(stable);
        return -1;
    }
    double base = clamp_sensitivity(state->sensitivity);
    double candidates[3] = {base, clamp_sensitivity(base - 10), clamp_sensitivity(base + 10)};
    double sensitivities[3];
    int count = 0;
    for (int i = 0; i < 3; i++) {
        int duplicate = 0;
        for (int j = 0; j < count; j++)
            duplicate |= sensitivities[j] == candidates[i];
        if (!duplicate)
            sensitivities[count++] = candidates[i];
    }
    out.min_count = TM_MAX_BUBBLES;
    for (int i = 0; i < count; i++) {
        runs[i] = *state;
        runs[i].sensitivity = sensitivities[i];
        int found = tm_detect(gray, w, h, stride, &runs[i]);
        if (found < 0 || found != runs[i].count || !valid_intervals(&runs[i]))
            goto error;
        out.runs++;
        if (found < out.min_count)
            out.min_count = found;
        if (found > out.max_count)
            out.max_count = found;
    }
    double tolerance = fmin(6, fmax(1.5, h * .1) * tm_channel_length(&state->channel) / (w - 1));
    memset(stable, 1, (size_t)runs[0].count);
    int comparisons = 0;
    double neighbours_agreement = 0;
    for (int i = 0; i < count; i++)
        for (int j = i + 1; j < count; j++) {
            Match match;
            if (!match_pairs(&runs[i], &runs[j], tolerance, i == 0 ? matched : NULL, &match))
                goto error;
            double agreement = pair_agreement(&runs[i], &runs[j], match);
            out.agreement += agreement;
            comparisons++;
            if (i == 0)
                for (int k = 0; k < runs[0].count; k++)
                    stable[k] &= matched[k];
            if (i == 1 && j == 2)
                neighbours_agreement = agreement;
        }
    out.agreement /= comparisons;
    int chosen = 0;
    if (!runs[0].count && count == 3 && runs[1].count && runs[2].count &&
        neighbours_agreement >= .8) {
        /* Prefer the result with fewer unsupported candidates, retaining all
           endpoints of that one run. An empty base is still disagreement. */
        chosen = runs[2].count < runs[1].count ? 2 : 1;
        out.recovered = 1;
    }
    for (int i = 0; i < runs[chosen].count; i++)
        if (out.recovered || !stable[i]) {
            runs[chosen].bubbles[i].flags |= TM_UNCERTAIN;
            out.unstable++;
        }
    *state = runs[chosen];
    if (report)
        *report = out;
    int found = state->count;
    free(stable);
    free(matched);
    free(runs);
    return found;
error:
    free(stable);
    free(matched);
    free(runs);
    return -1;
}

int tm_tune_recognition(const uint8_t *gray, int w, int h, int stride, const TM_State *truth,
                        TM_TrainingReport *report) {
    TM_TrainingReport out = {0};
    out.mean_error_px = INFINITY;
    if (report)
        *report = out;
    if (!valid_settings(truth) || !truth->reviewed || truth->count < 3 || !valid_intervals(truth))
        return 0;
    if (!valid_pixels(gray, w, h, stride))
        return -1;
    TM_State *trial = (TM_State *)malloc(sizeof(TM_State));
    if (!trial)
        return -1;
    double current = clamp_sensitivity(truth->sensitivity), parameters[12];
    int count = 0, present = 0;
    for (int v = 0; v <= 100; v += 10) {
        parameters[count++] = v;
        present |= current == v;
    }
    if (!present)
        parameters[count++] = current;
    out.tolerance_px = fmin(6, fmax(2, h * .1) * tm_channel_length(&truth->channel) / (w - 1));
    int best_errors = INT_MAX;
    double best_distance = INFINITY;
    for (int i = 0; i < count; i++) {
        *trial = *truth;
        trial->sensitivity = parameters[i];
        int found = tm_detect(gray, w, h, stride, trial);
        Match match;
        if (found < 0 || found != trial->count || !valid_intervals(trial) ||
            !match_pairs(truth, trial, out.tolerance_px, NULL, &match)) {
            free(trial);
            return -1;
        }
        out.trials++;
        int missed = truth->count - match.count, extra = trial->count - match.count;
        int errors = missed + extra;
        double mean = match.count ? match.error / (2 * match.count) : INFINITY;
        double distance = fabs(parameters[i] - current);
        if (errors < best_errors ||
            (errors == best_errors && (mean < out.mean_error_px ||
                                       (mean == out.mean_error_px && distance < best_distance)))) {
            best_errors = errors;
            best_distance = distance;
            out.sensitivity = parameters[i];
            out.matched = match.count;
            out.missed = missed;
            out.extra = extra;
            out.mean_error_px = mean;
        }
    }
    out.accepted =
        out.matched * 10 >= truth->count * 9 && out.extra * 10 <= out.matched + out.extra;
    free(trial);
    if (report)
        *report = out;
    return 1;
}
