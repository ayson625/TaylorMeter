@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "TM_APP_DIR=%~dp0"
powershell -NoProfile -Command "$dir=$env:TM_APP_DIR; $out=Join-Path $dir 'saves\photo'; try { New-Item -ItemType Directory -Force -Path $out -ErrorAction Stop | Out-Null } catch { $out=$env:TEMP }; $report=Join-Path $out 'TaylorMeter_launch.txt'; $lines=@('TaylorMeter launch diagnostics', ('OS: '+[Environment]::OSVersion), ('64-bit OS: '+[Environment]::Is64BitOperatingSystem)); try { $p=Start-Process -FilePath (Join-Path $dir 'TaylorMeter.exe') -WorkingDirectory $dir -PassThru -Wait -ErrorAction Stop; $lines+=('Exit code: '+$p.ExitCode); $lines+=('Exit hex: '+$p.ExitCode.ToString('X8')) } catch { $lines+=$_.Exception.Message }; $lines | Set-Content -LiteralPath $report -Encoding UTF8; Write-Host ('Report: '+$report); Get-Content -LiteralPath $report"
pause
