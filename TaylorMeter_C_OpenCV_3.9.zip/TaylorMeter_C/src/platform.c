#include "tm.h"
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
// clang-format off
#include <windows.h>
#include <commdlg.h>
#include <wchar.h>
// clang-format on
static HWND dialog_owner;
static char dialog_error[128];
void tm_set_dialog_owner(void *window) { dialog_owner = (HWND)window; }
const char *tm_dialog_error(void) { return dialog_error; }
static wchar_t *wide(const char *s) {
    int n = MultiByteToWideChar(CP_UTF8, 0, s, -1, NULL, 0);
    wchar_t *w = (wchar_t *)malloc((size_t)n * sizeof(wchar_t));
    if (w)
        MultiByteToWideChar(CP_UTF8, 0, s, -1, w, n);
    return w;
}
FILE *tm_fopen(const char *p, const char *m) {
    wchar_t *wp = wide(p), *wm = wide(m);
    FILE *f = wp && wm ? _wfopen(wp, wm) : NULL;
    free(wp);
    free(wm);
    return f;
}
int tm_replace_file(const char *a, const char *b) {
    wchar_t *wa = wide(a), *wb = wide(b);
    int ok = wa && wb && MoveFileExW(wa, wb, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
    free(wa);
    free(wb);
    return ok;
}
void tm_remove_file(const char *p) {
    wchar_t *wp = wide(p);
    if (wp)
        DeleteFileW(wp);
    free(wp);
}
void tm_platform_init(void) {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    SetProcessDPIAware();
}
int tm_choose_file(char *path, size_t cap, int save, const char *kind) {
    wchar_t file[32768] = L"";
    OPENFILENAMEW of = {0};
    dialog_error[0] = 0;
    of.lStructSize = sizeof(of);
    of.hwndOwner = dialog_owner;
    of.lpstrFile = file;
    of.nMaxFile = 32768;
    of.Flags = OFN_EXPLORER | OFN_NOCHANGEDIR | OFN_PATHMUSTEXIST |
               (save ? OFN_OVERWRITEPROMPT : OFN_FILEMUSTEXIST);
    if (!strcmp(kind, "xlsx")) {
        of.lpstrFilter = L"Excel (*.xlsx)\0*.xlsx\0\0";
        of.lpstrDefExt = L"xlsx";
    } else if (!strcmp(kind, "project")) {
        of.lpstrFilter = L"TaylorMeter project (*.tmc)\0*.tmc\0\0";
        of.lpstrDefExt = L"tmc";
    } else {
        of.lpstrFilter = L"Images\0*.jpg;*.jpeg;*.png;*.bmp;*.tif;*.tiff;*.webp;*.cr2;*.nef;*.arw;*"
                         L".dng\0All files\0*.*\0\0";
    }
    BOOL ok = save ? GetSaveFileNameW(&of) : GetOpenFileNameW(&of);
    if (!ok) {
        DWORD code = CommDlgExtendedError();
        if (code)
            snprintf(dialog_error, sizeof(dialog_error), "File dialog error: 0x%08lx",
                     (unsigned long)code);
        return 0;
    }
    int converted = WideCharToMultiByte(CP_UTF8, 0, file, -1, path, (int)cap, NULL, NULL) > 0;
    if (!converted)
        snprintf(dialog_error, sizeof(dialog_error), "File path is too long.");
    return converted;
}
#else
FILE *tm_fopen(const char *p, const char *m) { return fopen(p, m); }
int tm_replace_file(const char *a, const char *b) { return rename(a, b) == 0; }
void tm_remove_file(const char *p) { remove(p); }
void tm_platform_init(void) {}
void tm_set_dialog_owner(void *window) { (void)window; }
const char *tm_dialog_error(void) { return "File dialog unavailable on this platform."; }
int tm_choose_file(char *path, size_t cap, int save, const char *kind) {
    (void)path;
    (void)cap;
    (void)save;
    (void)kind;
    return 0;
}
#endif
const char *tm_basename(const char *p) {
    const char *a = strrchr(p, '/'), *b = strrchr(p, '\\');
    if (b && (!a || b > a))
        a = b;
    return a ? a + 1 : p;
}
