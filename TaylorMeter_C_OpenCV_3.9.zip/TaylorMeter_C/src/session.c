/* Portable little-endian project format. Stores source paths and measurements;
   it never rewrites the input photographs. */
#include "tm.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
static int put32(FILE *f, uint32_t x) {
    unsigned char a[4];
    for (int i = 0; i < 4; i++)
        a[i] = (unsigned char)(x >> (8 * i));
    return fwrite(a, 1, 4, f) == 4;
}
static int get32(FILE *f, uint32_t *x) {
    unsigned char a[4];
    if (fread(a, 1, 4, f) != 4)
        return 0;
    *x = 0;
    for (int i = 0; i < 4; i++)
        *x |= (uint32_t)a[i] << (8 * i);
    return 1;
}
static int putd(FILE *f, double v) {
    uint64_t x;
    memcpy(&x, &v, 8);
    return put32(f, (uint32_t)x) && put32(f, (uint32_t)(x >> 32));
}
static int getd(FILE *f, double *v) {
    uint32_t a, b;
    if (!get32(f, &a) || !get32(f, &b))
        return 0;
    uint64_t x = a | ((uint64_t)b << 32);
    memcpy(v, &x, 8);
    return isfinite(*v);
}
int tm_save_project(const char *path, const TM_Photo *photos, int count) {
    if (sizeof(double) != 8 || count < 0 || count > TM_MAX_PHOTOS)
        return 0;
    char tmp[TM_PATH];
    if (snprintf(tmp, sizeof(tmp), "%s.tmp", path) >= (int)sizeof(tmp))
        return 0;
    FILE *f = tm_fopen(tmp, "wb");
    if (!f)
        return 0;
    int ok = fwrite("TMC5\r\n\032\n", 1, 8, f) == 8 && put32(f, (uint32_t)count);
#define P32(v)                                                                                     \
    do {                                                                                           \
        if (ok)                                                                                    \
            ok = put32(f, (uint32_t)(v));                                                          \
    } while (0)
#define PD(v)                                                                                      \
    do {                                                                                           \
        if (ok)                                                                                    \
            ok = putd(f, (v));                                                                     \
    } while (0)
    for (int i = 0; i < count && ok; i++) {
        const TM_State *s = &photos[i].state;
        size_t n = strlen(photos[i].path);
        P32(n);
        if (ok)
            ok = fwrite(photos[i].path, 1, n, f) == n;
        P32(photos[i].width);
        P32(photos[i].height);
        P32(s->channel.valid);
        PD(s->channel.a.x);
        PD(s->channel.a.y);
        PD(s->channel.b.x);
        PD(s->channel.b.y);
        PD(s->channel.half_width);
        P32(s->region.x);
        P32(s->region.y);
        P32(s->region.w);
        P32(s->region.h);
        P32(s->region.valid);
        P32(s->region.automatic);
        const TM_Calibration *c = &s->calibration;
        P32(c->valid);
        P32(c->manual);
        PD(c->mm_per_px);
        PD(c->axis_x);
        PD(c->axis_y);
        PD(c->residual_px);
        PD(c->drift_percent);
        P32(c->count);
        for (int j = 0; j < c->count; j++) {
            PD(c->ticks[j].x);
            PD(c->ticks[j].mm);
        }
        PD(s->sensitivity);
        PD(s->min_length_px);
        P32(s->reviewed);
        P32(s->partial_count);
        P32(s->count);
        P32(s->flow_valid);
        PD(s->flow[0]);
        PD(s->flow[1]);
        P32(s->excluded);
        for (int j = 0; j < s->count; j++) {
            PD(s->bubbles[j].left);
            PD(s->bubbles[j].right);
            PD(s->bubbles[j].confidence);
            P32(s->bubbles[j].flags);
        }
    }
#undef P32
#undef PD
    if (fclose(f))
        ok = 0;
    if (ok)
        ok = tm_replace_file(tmp, path);
    if (!ok)
        tm_remove_file(tmp);
    return ok;
}
int tm_load_project(const char *path, TM_Photo *photos, int capacity, char *error, size_t cap) {
    FILE *f = tm_fopen(path, "rb");
    if (!f) {
        snprintf(error, cap, "Cannot open project.");
        return -1;
    }
    char magic[8];
    uint32_t n, v;
    int header = fread(magic, 1, 8, f) == 8;
    int format5 = header && !memcmp(magic, "TMC5\r\n\032\n", 8);
    int format4 = format5 || (header && !memcmp(magic, "TMC4\r\n\032\n", 8));
    int ok = header && (format4 || !memcmp(magic, "TMC3\r\n\032\n", 8)) && get32(f, &n) &&
             n <= (uint32_t)capacity && n <= TM_MAX_PHOTOS;
    TM_Photo *temp = ok ? (TM_Photo *)calloc(n ? n : 1, sizeof(TM_Photo)) : NULL;
    if (!temp)
        ok = 0;
#define G32(dst)                                                                                   \
    do {                                                                                           \
        if (ok) {                                                                                  \
            ok = get32(f, &v);                                                                     \
            if (ok)                                                                                \
                (dst) = (int)v;                                                                    \
        }                                                                                          \
    } while (0)
#define GD(dst)                                                                                    \
    do {                                                                                           \
        if (ok)                                                                                    \
            ok = getd(f, &(dst));                                                                  \
    } while (0)
    for (uint32_t i = 0; ok && i < n; i++) {
        uint32_t len;
        if (!get32(f, &len) || len >= TM_PATH) {
            ok = 0;
            break;
        }
        ok = fread(temp[i].path, 1, len, f) == len;
        temp[i].path[len] = 0;
        TM_State *s = &temp[i].state;
        G32(temp[i].width);
        G32(temp[i].height);
        G32(s->channel.valid);
        GD(s->channel.a.x);
        GD(s->channel.a.y);
        GD(s->channel.b.x);
        GD(s->channel.b.y);
        GD(s->channel.half_width);
        if (format4) {
            G32(s->region.x);
            G32(s->region.y);
            G32(s->region.w);
            G32(s->region.h);
            G32(s->region.valid);
            G32(s->region.automatic);
            if (s->region.valid &&
                (s->region.x < 0 || s->region.y < 0 || s->region.w < 4 || s->region.h < 4 ||
                 (long long)s->region.x + s->region.w > temp[i].width ||
                 (long long)s->region.y + s->region.h > temp[i].height)) {
                ok = 0;
                break;
            }
        } else if (s->channel.valid)
            s->region = tm_channel_bounds(&s->channel, temp[i].width, temp[i].height);
        TM_Calibration *c = &s->calibration;
        G32(c->valid);
        G32(c->manual);
        GD(c->mm_per_px);
        GD(c->axis_x);
        GD(c->axis_y);
        GD(c->residual_px);
        GD(c->drift_percent);
        G32(c->count);
        if (c->count < 0 || c->count > TM_MAX_TICKS) {
            ok = 0;
            break;
        }
        for (int j = 0; j < c->count; j++) {
            GD(c->ticks[j].x);
            GD(c->ticks[j].mm);
        }
        GD(s->sensitivity);
        GD(s->min_length_px);
        G32(s->reviewed);
        G32(s->partial_count);
        G32(s->count);
        if (format5) {
            G32(s->flow_valid);
            GD(s->flow[0]);
            GD(s->flow[1]);
            G32(s->excluded);
            if ((s->flow_valid != 0 && s->flow_valid != 1) ||
                (s->excluded != 0 && s->excluded != 1) ||
                s->flow[0] < 0 || s->flow[1] < 0)
                ok = 0;
        }
        if (s->count < 0 || s->count > TM_MAX_BUBBLES || s->sensitivity < 0 ||
            s->sensitivity > 100 || s->min_length_px <= 0) {
            ok = 0;
            break;
        }
        for (int j = 0; j < s->count; j++) {
            GD(s->bubbles[j].left);
            GD(s->bubbles[j].right);
            GD(s->bubbles[j].confidence);
            G32(s->bubbles[j].flags);
        }
        if (s->count && c->valid && !tm_validate(s, error, cap))
            ok = 0;
    }
#undef G32
#undef GD
    if (ok && fgetc(f) != EOF)
        ok = 0;
    fclose(f);
    if (ok) {
        memcpy(photos, temp, (size_t)n * sizeof(TM_Photo));
        free(temp);
        return (int)n;
    }
    free(temp);
    snprintf(error, cap, "Invalid, truncated or incompatible project file.");
    return -1;
}
