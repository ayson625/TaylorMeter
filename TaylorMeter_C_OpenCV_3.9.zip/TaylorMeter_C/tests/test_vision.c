#include "cv_bridge.h"
#include "tm.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #x);                                   \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)
/* These endpoints were annotated independently on the original pixels before
   comparison with this detector. They are approximate visual references, not
   calibrated physical ground truth or a held-out machine learning benchmark. */
typedef struct {
    const char *file;
    int count;
    double end[6][2];
} RealCase;
static const RealCase real_cases[] = {
    {"6492_left.png", 5, {{26, 84}, {109, 168}, {189, 244}, {286, 348}, {370, 432}}},
    {"6492_right.png", 6, {{34, 90}, {113, 166}, {204, 264}, {284, 336}, {368, 422}, {459, 510}}},
    {"6672_short.png", 3, {{24, 63}, {97, 212}, {235, 349}}},
};
static int check_real(const uint8_t *gray, int w, int h, int stride, double source_length,
                      const RealCase *c, const char *variant, double tolerance) {
    TM_State *state = (TM_State *)calloc(1, sizeof(*state));
    CHECK(state);
    state->channel = (TM_Channel){{0, 0}, {source_length, 0}, (h - 1) * .5, 1};
    state->sensitivity = 50;
    state->min_length_px = 3;
    int count = tm_detect(gray, w, h, stride, state);
    printf("Real %-16s %-12s %d/%d", c->file, variant, count, c->count);
    if (count != c->count) {
        fprintf(stderr, "\nUnexpected count for %s/%s\n", c->file, variant);
        free(state);
        return 1;
    }
    double largest = 0;
    for (int i = 0; i < count; i++) {
        double error = fmax(fabs(state->bubbles[i].left - c->end[i][0]),
                            fabs(state->bubbles[i].right - c->end[i][1]));
        if (error > largest)
            largest = error;
        if (error > tolerance || (i && state->bubbles[i].left <= state->bubbles[i - 1].right)) {
            fprintf(stderr, "\n%s/%s bubble %d: %.3f..%.3f, reference %.0f..%.0f, tolerance %.1f\n",
                    c->file, variant, i + 1, state->bubbles[i].left, state->bubbles[i].right,
                    c->end[i][0], c->end[i][1], tolerance);
            free(state);
            return 1;
        }
    }
    printf(", maximum endpoint error %.2f source px\n", largest);
    free(state);
    return 0;
}
static int real_regressions(const char *directory) {
    for (size_t k = 0; k < sizeof(real_cases) / sizeof(real_cases[0]); k++) {
        const RealCase *c = &real_cases[k];
        char path[TM_PATH];
        snprintf(path, sizeof(path), "%s/%s", directory, c->file);
        int w, h, stride;
        void *image = cvb_load(path, &w, &h);
        CHECK(image);
        const uint8_t *gray = cvb_gray(image, &w, &h, &stride);
        CHECK(gray);
        int source_w = w;
        CHECK(!check_real(gray, w, h, stride, w - 1, c, "original", 6));
        uint8_t *copy = (uint8_t *)malloc((size_t)w * (h + 36));
        CHECK(copy);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                copy[y * w + x] = (uint8_t)fmin(255, gray[y * stride + x] * .85 + 7);
        CHECK(!check_real(copy, w, h, w, w - 1, c, "illumination", 8));
        unsigned rng = 33;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                rng = rng * 1664525u + 1013904223u;
                int value = gray[y * stride + x] + (int)((rng >> 16) % 7) - 3;
                copy[y * w + x] = (uint8_t)(value < 0 ? 0 : value > 255 ? 255 : value);
            }
        CHECK(!check_real(copy, w, h, w, w - 1, c, "noise", 8));
        /* Move the same channel away from the rectangle's centre and add
           background; this used to enlarge the assumed capsule diameter. */
        for (int y = 0; y < h + 36; y++) {
            int sy = y - 28;
            if (sy < 0)
                sy = 0;
            if (sy >= h)
                sy = h - 1;
            memcpy(copy + y * w, gray + sy * stride, (size_t)w);
        }
        CHECK(!check_real(copy, w, h + 36, w, w - 1, c, "ROI-offset", 8));
        /* Apply an additional camera tilt with a vertical shear. */
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                double sy = y - .027 * (x - (w - 1) * .5);
                if (sy < 0)
                    sy = 0;
                if (sy > h - 1)
                    sy = h - 1;
                int y0 = (int)sy, y1 = y0 + 1 < h ? y0 + 1 : y0;
                copy[y * w + x] =
                    (uint8_t)lround(gray[y0 * stride + x] +
                                    (sy - y0) * (gray[y1 * stride + x] - gray[y0 * stride + x]));
            }
        CHECK(!check_real(copy, w, h, w, w - 1, c, "camera-tilt", 8));
        free(copy);
        const double scales[] = {.75, 1.5};
        for (size_t i = 0; i < sizeof(scales) / sizeof(scales[0]); i++) {
            int nw = (int)lround(w * scales[i]), nh = (int)lround(h * scales[i]), st;
            void *resized = cvb_resize(image, nw, nh);
            CHECK(resized);
            const uint8_t *pixels = cvb_gray(resized, &nw, &nh, &st);
            CHECK(pixels);
            CHECK(!check_real(pixels, nw, nh, st, source_w - 1, c, i ? "scale-150%" : "scale-75%",
                              8));
            cvb_free(resized);
        }
        cvb_free(image);
    }
    puts("Real photos: 14 manually referenced bubbles; 21 original/perturbed cases: PASS");
    return 0;
}

int main(int argc, char **argv) {
    const int w = 700, h = 33;
    uint8_t *gray = (uint8_t *)malloc((size_t)w * h);
    CHECK(gray);
    memset(gray, 180, (size_t)w * h);
    const double l[] = {30, 94, 160, 270, 370, 475}, r[] = {90, 155, 225, 340, 455, 570};
    /* Known capsule boundaries, liquid gaps 4,5,45,30,20 pixels. */
    for (int i = 0; i < 6; i++)
        for (int y = 4; y < h - 4; y++) {
            double t = (y - (h - 1) * 0.5) / 12;
            if (fabs(t) > 1)
                continue;
            double dx = 12 * (1 - sqrt(1 - t * t));
            for (int x = 0; x < w; x++) {
                double a = l[i] + dx, b = r[i] - dx;
                if (x >= a && x <= b)
                    gray[y * w + x] = 210;
                if (fabs(x - a) < 1 || fabs(x - b) < 1)
                    gray[y * w + x] = 50;
            }
        }
    TM_State *s = (TM_State *)calloc(1, sizeof(TM_State));
    CHECK(s);
    s->channel = (TM_Channel){{0, 16}, {699, 16}, 16, 1};
    s->sensitivity = 50;
    s->min_length_px = 3;
    int n = tm_detect(gray, w, h, w, s);
    printf("Synthetic capsules: %d\n", n);
    for (int i = 0; i < n; i++)
        printf("  %.3f : %.3f\n", s->bubbles[i].left, s->bubbles[i].right);
    CHECK(n == 6);
    for (int i = 0; i < n; i++) {
        CHECK(fabs(s->bubbles[i].left - l[i]) < 3);
        CHECK(fabs(s->bubbles[i].right - r[i]) < 3);
    }
    uint8_t *rg = (uint8_t *)malloc(700 * 60);
    CHECK(rg);
    memset(rg, 220, 700 * 60);
    for (int i = 0; i < 65; i++) {
        int x = 20 + i * 10;
        for (int y = 5; y < 30 + (i % 10 == 0 ? 20 : 0); y++)
            for (int j = -1; j <= 1; j++)
                rg[y * 700 + x + j] = 25;
    }
    TM_Calibration *c = (TM_Calibration *)calloc(1, sizeof(TM_Calibration));
    CHECK(c);
    c->axis_x = 1;
    CHECK(tm_find_ruler(rg, 700, 60, 700, 100, c));
    CHECK(fabs(c->mm_per_px - 0.1) < 0.002);
    CHECK(c->count >= 40);
    memset(rg, 180, 700 * 60);
    CHECK(!tm_find_ruler(rg, 700, 60, 700, 0, c));
    /* Exercise real OpenCV decoding, rectification, PNG I/O and C boundary. */
    void *im = cvb_create(700, 80, 0xddddee);
    CHECK(im);
    for (int i = 0; i < 6; i++) {
        cvb_line(im, l[i], 24, l[i], 55, 0x101010, 1);
        cvb_line(im, r[i], 24, r[i], 55, 0x101010, 1);
    }
    CHECK(cvb_save(im, "test_opencv.png"));
    int iw, ih;
    void *loaded = cvb_load("test_opencv.png", &iw, &ih);
    CHECK(loaded && iw == 700 && ih == 80);
    TM_Channel ch = {{20, 40}, {650, 40}, 16, 1};
    void *strip = cvb_strip(loaded, &ch, &iw, &ih);
    CHECK(strip && iw == 631 && ih == 33);
    int st;
    CHECK(cvb_gray(strip, &iw, &ih, &st));
    cvb_free(strip);
    cvb_free(loaded);
    cvb_free(im);
    free(c);
    free(rg);
    free(gray);
    free(s);
    puts("synthetic capsules, narrow slugs, ruler and OpenCV integration: PASS");
    CHECK(argc == 2);
    CHECK(!real_regressions(argv[1]));
    return 0;
}
