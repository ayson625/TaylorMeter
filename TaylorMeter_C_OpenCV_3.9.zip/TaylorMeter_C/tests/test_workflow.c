/* Application-level regression: actual commands, inheritance, close/undo, export. */
#include "../src/app.c"
#define CHECK(x) do { if (!(x)) { fprintf(stderr,"workflow line %d: %s\n",__LINE__,#x); return 1; } } while(0)
int tmui_open(const char *t,int w,int h) {(void)t;(void)w;(void)h;return 0;}
void tmui_button(int id,int x,int y,int w,int h,const char *t,int v,int e,int a) {(void)id;(void)x;(void)y;(void)w;(void)h;(void)t;(void)v;(void)e;(void)a;}
void tmui_textfield(int id,int v,int x,int y,int w,int h,const char *t) {(void)id;(void)v;(void)x;(void)y;(void)w;(void)h;(void)t;}
void tmui_input(int v,int x,int y,int w,int h,const char *t) {tmui_textfield(0,v,x,y,w,h,t);}
int tmui_choose_language(void) {return 0;}
int tmui_splash(void) {return 1;}
void tmui_show(void *p) {(void)p;}
int tmui_poll(TMUI_Event *e,int t) {(void)e;(void)t;return 0;}
int tmui_alive(void) {return 0;}
void tmui_busy(int b) {(void)b;}
void tmui_close(void) {}
static int copy_file(const char *from,const char *to) {
 FILE *a=tm_fopen(from,"rb"),*b=tm_fopen(to,"wb"); if(!a||!b)return 0;
 char buf[8192];size_t n;while((n=fread(buf,1,sizeof(buf),a)))if(fwrite(buf,1,n,b)!=n)return 0;
 fclose(a);return fclose(b)==0;
}
static void valid_marks(TM_Photo *p) {
 TM_State *s=&p->state;
 tm_set_channel(s,(TM_Point){30,200},(TM_Point){850,200},(TM_Point){30,215});
 tm_manual_calibrate(s,(TM_Point){0,350},(TM_Point){100,350},10);
 tm_add_bubble(s,10,20,TM_MANUAL,1);tm_add_bubble(s,20.01,30,TM_MANUAL,1);
 s->reviewed=1;make_strip(p);
}
int main(int argc,char **argv) {
 CHECK(argc==2);tm_set_language(0);
 App *a=calloc(1,sizeof(App));CHECK(a);
 a->photos=calloc(TM_MAX_PHOTOS,sizeof(TM_Photo));a->pending=calloc(1,sizeof(TM_State));
 CHECK(a->photos&&a->pending&&tm_history_init(&a->history,100));a->labels=1;
 double f;
 CHECK(tm_parse_flow("1,25",&f)&&f==1.25);CHECK(tm_parse_flow("0",&f)&&f==0);
 CHECK(!tm_parse_flow("nan",&f)&&!tm_parse_flow("-1",&f)&&!tm_parse_flow("12 garbage",&f));
 CHECK(copy_file(argv[1],"IMG_7001.png")&&copy_file(argv[1],"IMG_7002.png")&&copy_file(argv[1],"IMG_7003.png"));
 open_photo(a,"IMG_7001.png");CHECK(a->count==1&&a->mode==FLOW);
 strcpy(a->flow_input[0],"10");strcpy(a->flow_input[1],"20");action(a,FLOW_OK);
 CHECK(a->mode==EDIT&&a->default_flow_valid&&photo(a)->state.flow[0]==10);
 valid_marks(photo(a));
 open_photo(a,"IMG_7002.png");CHECK(a->mode==EDIT&&photo(a)->state.flow[1]==20);
 valid_marks(photo(a));
 action(a,SET_FLOW);strcpy(a->flow_input[0],"30");strcpy(a->flow_input[1],"40");action(a,FLOW_OK);
 CHECK(a->photos[0].state.flow[0]==10&&a->photos[1].state.flow[0]==30);
 action(a,UNDO_EDIT);CHECK(photo(a)->state.flow[0]==10&&a->default_flow[0]==10);
 action(a,REDO_EDIT);CHECK(photo(a)->state.flow[0]==30&&a->default_flow[0]==30);
 open_photo(a,"IMG_7003.png");CHECK(photo(a)->state.flow[0]==30);valid_marks(photo(a));
 switch_photo(a,1);action(a,CLOSE_PHOTO);
 CHECK(a->photos[1].state.excluded&&a->index==2&&next_open(a,2,-1)==0);
 char err[256];CHECK(tm_export_xlsx("workflow_closed.xlsx",a->photos,a->count,err,sizeof(err)));
 action(a,UNDO_EDIT);CHECK(a->index==1&&!a->photos[1].state.excluded&&a->photos[1].state.count==2);
 action(a,REDO_EDIT);CHECK(a->photos[1].state.excluded);
 switch_photo(a,0);action(a,CLOSE_PHOTO);CHECK(a->index==2);
 action(a,CLOSE_PHOTO);CHECK(!photo(a)&&button_enabled(a,UNDO_EDIT));
 CHECK(!button_enabled(a,EXPORT));
 action(a,UNDO_EDIT);CHECK(photo(a)&&a->index==2&&photo(a)->state.flow[0]==30);
 /* Same basename reload restores a closed photo without duplicating it. */
 open_photo(a,"IMG_7001.png");CHECK(a->count==3&&a->index==0&&!photo(a)->state.excluded);
 CHECK(a->default_flow[0]==30);
 CHECK(tm_save_project("workflow.tmc",a->photos,a->count));
 TM_Photo *q=calloc(TM_MAX_PHOTOS,sizeof(TM_Photo));CHECK(q);
 CHECK(tm_load_project("workflow.tmc",q,TM_MAX_PHOTOS,err,sizeof(err))==3);
 CHECK(q[1].state.excluded&&q[2].state.flow[1]==40&&q[0].state.flow[0]==10);
 for(int i=0;i<3;i++) {
  CHECK(!memcmp(&q[i].state,&a->photos[i].state,offsetof(TM_State,bubbles)));
  CHECK(!memcmp(q[i].state.bubbles,a->photos[i].state.bubbles,q[i].state.count*sizeof(TM_Bubble)));
 }
 free(q);
 char stem[TM_PATH];CHECK(tm_export_stem(a->photos+2,2,stem,sizeof(stem))&&!strcmp(stem,"003_IMG_7003"));
 char x[TM_PATH],y[TM_PATH];CHECK(tm_create_export_path(x,sizeof(x))&&tm_create_export_path(y,sizeof(y))&&strcmp(x,y));
 CHECK(strstr(x,"/saves/excel/")&&strstr(y,"/saves/excel/"));
 save_outputs(a,x);
 FILE *saved=tm_fopen(x,"rb"); CHECK(saved); fclose(saved);
 CHECK(strstr(a->status,"saves"));
 char photo_base[TM_PATH],output[TM_PATH];CHECK(tm_export_photo_base(x,photo_base,sizeof(photo_base)));
 CHECK(strstr(photo_base,"/saves/photo/"));
 const char *suffixes[]={".tmc","_001_IMG_7001_photo.png","_001_IMG_7001_channel.png","_003_IMG_7003_photo.png","_003_IMG_7003_channel.png"};
 for(int i=0;i<5;i++) {
  CHECK(snprintf(output,sizeof(output),"%s%s",photo_base,suffixes[i])<(int)sizeof(output));
  saved=tm_fopen(output,"rb");CHECK(saved);fclose(saved);
 }
 CHECK(snprintf(output,sizeof(output),"%s_002_IMG_7002_photo.png",photo_base)<(int)sizeof(output));
 CHECK(!tm_fopen(output,"rb"));
 /* Group A,A,B,B,A: equal values merge only when consecutive. */
 TM_Photo *group=calloc(5,sizeof(TM_Photo));CHECK(group);
 for(int i=0;i<5;i++) {group[i].state=a->photos[0].state;snprintf(group[i].path,TM_PATH,"IMG_%04d.CR2",8001+i);}
 group[2].state.flow[0]=group[3].state.flow[0]=30;group[2].state.flow[1]=group[3].state.flow[1]=40;
 CHECK(tm_export_xlsx("workflow_groups.xlsx",group,5,err,sizeof(err)));
 group[1].state.flow_valid=0;CHECK(tm_export_xlsx("workflow_missing_flow.xlsx",group,5,err,sizeof(err)));
 tm_set_language(1);CHECK(!strcmp(tm_text("Да","Yes"),"Yes"));
 CHECK(tm_export_xlsx("workflow_english.xlsx",group,5,err,sizeof(err)));
 free(group);release_photos(a);cvb_free(a->display);tm_history_free(&a->history);free(a->photos);free(a->pending);free(a);
 puts("Flow inheritance, close/undo/redo including last photo, sessions, filenames and exports: PASS");return 0;
}
