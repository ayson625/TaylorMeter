#include "history.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL %d: %s\n", __LINE__, #x);                                        \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)
int main(void) {
    TM_Photo *p = (TM_Photo *)calloc(2, sizeof(TM_Photo));
    TM_State *before = (TM_State *)malloc(sizeof(TM_State));
    TM_History history;
    CHECK(p && before && tm_history_init(&history, 4));
    p[0].state.sensitivity = p[1].state.sensitivity = 50;
    p[0].state.min_length_px = p[1].state.min_length_px = 3;
    *before = p[0].state;
    CHECK(tm_set_channel_rect(&p[0].state, (TM_Rect){20, 40, 700, 31, 1, 1}, 900, 500));
    CHECK(tm_manual_calibrate(&p[0].state, (TM_Point){0, 200}, (TM_Point){100, 200}, 10));
    CHECK(tm_add_bubble(&p[0].state, 10, 40, TM_MANUAL, 1) == 0);
    CHECK(tm_add_bubble(&p[0].state, 40.25, 80, TM_MANUAL, 1) == 1);
    tm_history_record(&history, 0, before, &p[0].state);
    int index = -1;
    CHECK(tm_history_undo(&history, p, 2, &index) && index == 0);
    CHECK(!p[0].state.channel.valid && !p[0].state.calibration.valid && !p[0].state.count);
    CHECK(tm_history_redo(&history, p, 2, &index));
    CHECK(p[0].state.region.automatic && fabs(tm_slug_mm(&p[0].state, 0) - .025) < 1e-12);
    *before = p[1].state;
    p[1].state.sensitivity = 65;
    tm_history_record(&history, 1, before, &p[1].state);
    *before = p[0].state;
    CHECK(tm_move_boundary(&p[0].state, 1, 0, 41));
    CHECK(tm_move_boundary(&p[0].state, 1, 0, 43));
    tm_history_record(&history, 0, before, &p[0].state);
    CHECK(tm_history_undo(&history, p, 2, &index) && index == 0);
    CHECK(fabs(tm_slug_mm(&p[0].state, 0) - .025) < 1e-12);
    CHECK(tm_history_undo(&history, p, 2, &index) && index == 1);
    CHECK(p[1].state.sensitivity == 50);
    tm_history_record(&history, 1, &p[1].state, &p[1].state);
    CHECK(tm_history_redo(&history, p, 2, &index) && index == 1);
    CHECK(p[1].state.sensitivity == 65);
    CHECK(tm_history_redo(&history, p, 2, &index) && index == 0);
    CHECK(p[0].state.bubbles[1].left == 43);
    CHECK(tm_history_undo(&history, p, 2, &index));
    *before = p[0].state;
    tm_delete_bubble(&p[0].state, 1);
    tm_history_record(&history, 0, before, &p[0].state);
    CHECK(!tm_history_redo(&history, p, 2, &index));
    CHECK(tm_history_undo(&history, p, 2, &index) && p[0].state.count == 2);
    CHECK(tm_history_redo(&history, p, 2, &index) && p[0].state.count == 1);
    tm_history_clear(&history);
    CHECK(!tm_history_undo(&history, p, 2, &index));
    for (int i = 0; i < 7; i++) {
        *before = p[1].state;
        p[1].state.sensitivity = 70 + i;
        tm_history_record(&history, 1, before, &p[1].state);
    }
    CHECK(history.count == 4);
    for (int i = 0; i < 4; i++)
        CHECK(tm_history_undo(&history, p, 2, &index));
    CHECK(p[1].state.sensitivity == 72 && !tm_history_undo(&history, p, 2, &index));
    for (int i = 0; i < 4; i++)
        CHECK(tm_history_redo(&history, p, 2, &index));
    CHECK(p[1].state.sensitivity == 76);
    tm_history_free(&history);
    free(before);
    free(p);
    puts("whole edits, exact gaps, redo, cross-photo history, branches and bounded history: PASS");
    return 0;
}
