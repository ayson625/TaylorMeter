#include "overlay.h"
#include "cv_bridge.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "line %d: %s\n", __LINE__, #expr); return 1; } } while (0)
static int picked(TM_State *s, TM_Overlay *o, double x, double y, int kind, int index) {
    TM_Hover h = tm_overlay_hit(s, o, x, y, 6);
    return h.kind == kind && (kind == TM_HOVER_NONE || h.index == index);
}
int main(void) {
    TM_State *s = calloc(1, sizeof(*s)), *before = calloc(1, sizeof(*before));
    CHECK(s && before);
    s->channel = (TM_Channel){{30, 200}, {850, 200}, 15, 1};
    s->calibration.valid = 1;
    s->calibration.manual = 1;
    s->calibration.mm_per_px = .05;
    s->calibration.axis_x = 1;
    CHECK(tm_add_bubble(s, 30, 150, TM_MANUAL, 1) >= 0);
    CHECK(tm_add_bubble(s, 150.02, 270, TM_MANUAL, 1) >= 0);
    CHECK(tm_add_bubble(s, 330, 450, TM_MANUAL, 1) >= 0);
    CHECK(tm_add_bubble(s, 450, 570, TM_MANUAL, 1) >= 0);
    *before = *s;
    TM_Overlay o;
    tm_overlay_init(&o, &s->channel, 821);
    CHECK(picked(s, &o, 90, 150, TM_HOVER_BUBBLE, 0));
    CHECK(picked(s, &o, 150.01, 150, TM_HOVER_SLUG, 0));
    CHECK(picked(s, &o, 300, 150, TM_HOVER_SLUG, 1));
    CHECK(picked(s, &o, 150, 232, TM_HOVER_SLUG, 0));
    CHECK(picked(s, &o, 450, 260, TM_HOVER_SLUG, 2));
    CHECK(picked(s, &o, 150, 68, TM_HOVER_BUBBLE, 0));
    CHECK(picked(s, &o, 800, 150, TM_HOVER_NONE, -1));
    CHECK(picked(s, &o, 600, 280, TM_HOVER_NONE, -1));
    char value[80];
    tm_overlay_value(s, (TM_Hover){TM_HOVER_SLUG, 0}, value, sizeof(value));
    CHECK(!strcmp(value, "~0.001000 mm"));
    tm_overlay_value(s, (TM_Hover){TM_HOVER_SLUG, 2}, value, sizeof(value));
    CHECK(!strcmp(value, "~0.000000 mm"));
    tm_overlay_value(s, (TM_Hover){TM_HOVER_SLUG, 3}, value, sizeof(value));
    CHECK(!value[0]);
    /* Zoom and pan preserve both hit coordinates and the six-pixel line target. */
    o.zoom = 2.5; o.panx = 100; o.pany = 50;
    CHECK(picked(s, &o, (90 - 100) * 2.5, (150 - 50) * 2.5, TM_HOVER_BUBBLE, 0));
    CHECK(picked(s, &o, (450 - 100) * 2.5 + 5, (260 - 50) * 2.5, TM_HOVER_SLUG, 2));
    CHECK(!memcmp(s, before, sizeof(*s)));
    /* Original photograph: rotated axis and nonuniform screen position. */
    s->channel = (TM_Channel){{100, 80}, {756, 572}, 20, 1};
    tm_overlay_init(&o, &s->channel, 0);
    o.zoom = 1.7; o.panx = 20; o.pany = 30;
    CHECK(picked(s, &o, (100 + .8 * 90 - 20) * 1.7,
                 (80 + .6 * 90 - 30) * 1.7, TM_HOVER_BUBBLE, 0));
    CHECK(picked(s, &o, (100 + .8 * 450 - .6 * 72 - 20) * 1.7,
                 (80 + .6 * 450 + .8 * 72 - 30) * 1.7, TM_HOVER_SLUG, 2));
    *s = *before;
    tm_overlay_init(&o, &s->channel, 821);
    void *image = cvb_create(821, 300, 0x808080);
    CHECK(image);
    tm_overlay_draw(image, s, &o, 1);
    int w, h, stride;
    const unsigned char *pixels = cvb_bgr(image, &w, &h, &stride);
    const unsigned char *red = pixels + 68 * stride + 90 * 3;
    const unsigned char *blue = pixels + 252 * stride + 300 * 3;
    CHECK(red[2] > red[0] + 80 && red[2] > red[1] + 80);
    CHECK(blue[0] > blue[2] + 80);
    tm_overlay_highlight(image, s, &o, (TM_Hover){TM_HOVER_BUBBLE, 0});
    pixels = cvb_bgr(image, &w, &h, &stride);
    red = pixels + 180 * stride + 90 * 3;
    CHECK(red[2] > red[0] + 30);
    tm_overlay_highlight(image, s, &o, (TM_Hover){TM_HOVER_SLUG, 1});
    blue = pixels + 180 * stride + 300 * 3;
    CHECK(blue[0] > blue[2] + 30);
    CHECK(!memcmp(s, before, sizeof(*s)));
    cvb_free(image);
    s->calibration.valid = 0;
    tm_overlay_value(s, (TM_Hover){TM_HOVER_SLUG, 0}, value, sizeof(value));
    CHECK(!strcmp(value, "~0.020000 px"));
    free(s); free(before);
    puts("PASS: colored dimensions, hover, narrow/zero slugs, zoom/pan, rotated photo and units");
    return 0;
}
