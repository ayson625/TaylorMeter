@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "TM_APP_DIR=%~dp0"
powershell -NoProfile -Command "$exe=Join-Path $env:TM_APP_DIR 'TaylorMeter.exe'; if (-not (Test-Path -LiteralPath $exe)) {exit 1}; $shell=New-Object -ComObject WScript.Shell; $link=$shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'TaylorMeter.lnk')); $link.TargetPath=$exe; $link.WorkingDirectory=$env:TM_APP_DIR; $link.IconLocation=$exe+',0'; $link.Description='TaylorMeter'; $link.Save()"
if errorlevel 1 goto failed
echo TaylorMeter shortcut created on the desktop.
exit /b 0
:failed
echo Could not create the shortcut. Extract the complete archive first.
pause
exit /b 1
