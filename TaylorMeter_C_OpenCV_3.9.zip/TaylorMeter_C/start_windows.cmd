@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto folder_error
if not exist "%~dp0TaylorMeter.exe" goto missing_exe
"%~dp0TaylorMeter.exe" %*
set "tm_launch_exit=%errorlevel%"
popd
if not "%tm_launch_exit%"=="0" goto launch_error
exit /b 0

:missing_exe
echo ERROR: TaylorMeter.exe was not found beside this script.
echo Extract the entire ZIP archive into a folder, then run start_windows.cmd.
echo You can also run TaylorMeter.exe directly from that folder.
popd
pause
exit /b 1

:folder_error
echo ERROR: Unable to open the program folder.
pause
exit /b 1

:launch_error
echo ERROR: TaylorMeter exited with code %tm_launch_exit%.
echo Run diagnose_windows.cmd and send the report from saves\photo.
pause
exit /b %tm_launch_exit%
