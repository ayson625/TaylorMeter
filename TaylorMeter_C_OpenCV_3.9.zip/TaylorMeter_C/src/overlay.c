#include "overlay.h"
#include "cv_bridge.h"
#include <math.h>
#include <stdio.h>
#include <string.h>

void tm_overlay_init(TM_Overlay *o, const TM_Channel *c, int strip_width) {
    memset(o, 0, sizeof(*o));
    o->zoom = 1;
    double len = tm_channel_length(c);
    if (len <= 0)
        return;
    if (strip_width > 1) {
        o->origin = (TM_Point){0, 150};
        o->axis = (TM_Point){1, 0};
        o->normal = (TM_Point){0, 1};
        o->along_scale = (strip_width - 1) / len;
        o->half_width = 70;
    } else {
        o->origin = c->a;
        o->axis = (TM_Point){(c->b.x - c->a.x) / len, (c->b.y - c->a.y) / len};
        o->normal = (TM_Point){-o->axis.y, o->axis.x};
        /* Keep red dimensions on the upper side even for a reversed axis. */
        if (o->normal.y < 0) {
            o->normal.x = -o->normal.x;
            o->normal.y = -o->normal.y;
        }
        o->along_scale = 1;
        o->half_width = c->half_width;
    }
}
static TM_Point point(const TM_Overlay *o, double along, double across) {
    return (TM_Point){(o->origin.x + o->axis.x * along * o->along_scale +
                      o->normal.x * across - o->panx) * o->zoom,
                      (o->origin.y + o->axis.y * along * o->along_scale +
                       o->normal.y * across - o->pany) * o->zoom};
}
static int interval(const TM_State *s, TM_Hover hit, double *left, double *right) {
    if (hit.index < 0 || hit.index >= s->count)
        return 0;
    if (hit.kind == TM_HOVER_BUBBLE) {
        *left = s->bubbles[hit.index].left;
        *right = s->bubbles[hit.index].right;
    } else if (hit.kind == TM_HOVER_SLUG && hit.index + 1 < s->count) {
        *left = s->bubbles[hit.index].right;
        *right = s->bubbles[hit.index + 1].left;
    } else
        return 0;
    return 1;
}
static double level(const TM_Overlay *o, TM_Hover hit) {
    return (hit.kind == TM_HOVER_BUBBLE ? -1 : 1) *
           (o->half_width + 12 + (hit.index % 3) * 20);
}
void tm_overlay_value(const TM_State *s, TM_Hover hit, char *text, size_t cap) {
    double left, right;
    if (!interval(s, hit, &left, &right)) {
        if (cap)
            text[0] = 0;
        return;
    }
    int slug = hit.kind == TM_HOVER_SLUG;
    double value = s->calibration.valid ? (slug ? tm_slug_mm(s, hit.index)
                                               : tm_bubble_mm(s, hit.index))
                                       : right - left;
    snprintf(text, cap, "%s%.6f %s", slug && right - left <= 1 ? "~" : "", value,
             s->calibration.valid ? "mm" : "px");
}
static void line(void *image, TM_Point a, TM_Point b, int color, int thickness) {
    cvb_line(image, a.x, a.y, b.x, b.y, color, thickness);
}
static void dimension(void *image, const TM_State *s, const TM_Overlay *o, TM_Hover hit,
                      int labels, int thickness) {
    double left, right;
    if (!interval(s, hit, &left, &right))
        return;
    int slug = hit.kind == TM_HOVER_SLUG, color = slug ? TM_SLUG_COLOR : TM_DROP_COLOR;
    double t = level(o, hit);
    TM_Point a = point(o, left, t), b = point(o, right, t);
    line(image, point(o, left, 0), a, color, thickness);
    line(image, point(o, right, 0), b, color, thickness);
    line(image, a, b, color, thickness);
    /* Exact endpoints, including coincident ones. Ticks do not widen the gap. */
    for (int k = 0; k < 2; k++) {
        double x = k ? right : left;
        line(image, point(o, x, t - 3), point(o, x, t + 3), color, thickness);
    }
    if (labels) {
        char value[80], text[112];
        tm_overlay_value(s, hit, value, sizeof(value));
        snprintf(text, sizeof(text), "%c%d %s%s", slug ? 'S' : 'B', hit.index + 1, value,
                 !slug && (s->bubbles[hit.index].flags & TM_UNCERTAIN) ? " ?" : "");
        TM_Point q = point(o, left, t + (slug ? 19 : -7));
        cvb_text(image, (int)q.x, (int)q.y, text, 15, color);
    }
}
void tm_overlay_draw(void *image, const TM_State *s, const TM_Overlay *o, int labels) {
    if (!image || !s->channel.valid)
        return;
    for (int i = 0; i < s->count; i++) {
        dimension(image, s, o, (TM_Hover){TM_HOVER_BUBBLE, i}, labels, 1);
        if (i + 1 < s->count)
            dimension(image, s, o, (TM_Hover){TM_HOVER_SLUG, i}, labels, 1);
    }
}
static double distance(TM_Point q, TM_Point a, TM_Point b) {
    double dx = b.x - a.x, dy = b.y - a.y, squared = dx * dx + dy * dy;
    double t = squared > 0 ? ((q.x - a.x) * dx + (q.y - a.y) * dy) / squared : 0;
    t = fmax(0, fmin(1, t));
    return hypot(q.x - a.x - t * dx, q.y - a.y - t * dy);
}
TM_Hover tm_overlay_hit(const TM_State *s, const TM_Overlay *o, double x, double y,
                        double tolerance) {
    TM_Hover none = {TM_HOVER_NONE, -1};
    if (!s->channel.valid || o->zoom <= 0 || o->along_scale <= 0)
        return none;
    double dx = x / o->zoom + o->panx - o->origin.x,
           dy = y / o->zoom + o->pany - o->origin.y,
           along = (dx * o->axis.x + dy * o->axis.y) / o->along_scale,
           across = dx * o->normal.x + dy * o->normal.y;
    /* Interior picks use exact bounds: a neighbouring bubble must not steal
       a real, narrow slug. Below the strip the blue extension remains usable
       even when its two endpoints coincide or are less than one screen pixel. */
    if (fabs(across) <= o->half_width) {
        for (int i = 0; i < s->count; i++) {
            if (along >= s->bubbles[i].left && along < s->bubbles[i].right)
                return (TM_Hover){TM_HOVER_BUBBLE, i};
            if (i + 1 < s->count && along >= s->bubbles[i].right &&
                along < s->bubbles[i + 1].left)
                return (TM_Hover){TM_HOVER_SLUG, i};
        }
    }
    TM_Hover best = none;
    double nearest = tolerance;
    TM_Point q = {x, y};
    for (int i = 0; i < s->count; i++) {
        for (int kind = TM_HOVER_BUBBLE; kind <= TM_HOVER_SLUG; kind++) {
            TM_Hover hit = {kind, i};
            double left, right;
            if (!interval(s, hit, &left, &right))
                continue;
            double t = level(o, hit);
            TM_Point a = point(o, left, t), b = point(o, right, t);
            double d = fmin(distance(q, a, b),
                            fmin(distance(q, point(o, left, 0), a),
                                 distance(q, point(o, right, 0), b)));
            if (d < nearest) {
                nearest = d;
                best = hit;
            }
        }
    }
    return best;
}
void tm_overlay_highlight(void *image, const TM_State *s, const TM_Overlay *o, TM_Hover hit) {
    double left, right;
    if (!interval(s, hit, &left, &right))
        return;
    int color = hit.kind == TM_HOVER_SLUG ? TM_SLUG_COLOR : TM_DROP_COLOR;
    TM_Point corners[4] = {point(o, left, -o->half_width), point(o, right, -o->half_width),
                           point(o, right, o->half_width), point(o, left, o->half_width)};
    cvb_tint_quad(image, corners, color, .25);
    for (int k = 0; k < 4; k++)
        line(image, corners[k], corners[(k + 1) % 4], color, 2);
    dimension(image, s, o, hit, 0, 2);
}
