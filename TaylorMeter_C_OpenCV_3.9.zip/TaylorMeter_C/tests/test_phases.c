#include "cv_bridge.h"
#include "recognition.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do { if (!(x)) { fprintf(stderr, "FAIL %d: %s\n", __LINE__, #x); return 1; } } while (0)

static const double bounds[2][6][2] = {
    {{43, 111}, {151, 300}, {320, 390}},
    {{150, 265}, {353, 425}, {425, 562}, {608, 676}, {717, 866}, {884, 956}}};
static const double minimum_gap[2][5] = {{25, 8}, {65, 0, 30, 25, 5}};
static int verify(const uint8_t *g, int w, int h, int stride, int original_width, int case_id,
                  const char *variant) {
    TM_State *s = calloc(1, sizeof(*s));
    CHECK(s);
    s->channel = (TM_Channel){{0, 0}, {original_width - 1, 0}, (h - 1) * .5, 1};
    s->sensitivity = 50;
    s->min_length_px = 3;
    TM_RecognitionReport report;
    int n = tm_detect_checked(g, w, h, stride, s, &report), expected = case_id ? 6 : 3;
    printf("Phase %d / %s: %d/%d capsules; repeatability %d..%d\n", case_id + 1, variant,
           n, expected, report.min_count, report.max_count);
    for (int i = 0; i < n; i++)
        printf("  %.3f %.3f gap %.3f\n", s->bubbles[i].left, s->bubbles[i].right,
               i + 1 < n ? s->bubbles[i + 1].left - s->bubbles[i].right : -1);
    CHECK(n == expected);
    for (int i = 0; i < n; i++) {
        CHECK(fabs(s->bubbles[i].left - bounds[case_id][i][0]) <= 6);
        CHECK(fabs(s->bubbles[i].right - bounds[case_id][i][1]) <= 6);
        if (i + 1 < n)
            CHECK(s->bubbles[i + 1].left - s->bubbles[i].right >= minimum_gap[case_id][i]);
    }
    free(s);
    return 0;
}
int main(int argc, char **argv) {
    CHECK(argc == 2);
    const char *names[] = {"liquid_between.png", "phase_swapped.png"};
    for (int c = 0; c < 2; c++) {
        char path[4096];
        snprintf(path, sizeof(path), "%s/%s", argv[1], names[c]);
        int w, h, stride;
        void *image = cvb_load(path, &w, &h);
        CHECK(image);
        const uint8_t *g = cvb_gray(image, &w, &h, &stride);
        CHECK(!verify(g, w, h, stride, w, c, "original"));
        uint8_t *noisy = malloc((size_t)w * h);
        CHECK(noisy);
        unsigned seed = 36;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                seed = 1664525u * seed + 1013904223u;
                noisy[y * w + x] = (uint8_t)fmax(0, fmin(255, g[y * stride + x] * .85 +
                                                       7 + (int)((seed >> 16) % 5) - 2));
            }
        CHECK(!verify(noisy, w, h, w, w, c, "brightness and noise"));
        free(noisy);
        for (int k = 0; k < 2; k++) {
            double scale = k ? 1.5 : .75;
            int nw = (int)lround(w * scale), nh = (int)lround(h * scale), ns;
            void *resized = cvb_resize(image, nw, nh);
            CHECK(resized);
            const uint8_t *data = cvb_gray(resized, &nw, &nh, &ns);
            CHECK(!verify(data, nw, nh, ns, w, c, k ? "150%" : "75%"));
            cvb_free(resized);
        }
        cvb_free(image);
    }
    puts("Capsules are droplets; liquid intervals are slugs: PASS");
    return 0;
}
