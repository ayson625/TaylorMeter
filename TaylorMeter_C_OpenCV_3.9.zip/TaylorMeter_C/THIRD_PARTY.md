# Components in the Windows build

- OpenCV 4.12.0: Apache License 2.0.
- LibRaw 0.21.2 with Ubuntu 0.21.2-2.1ubuntu0.24.04.2 patches: dual LGPL 2.1 / CDDL 1.0.
  Complete corresponding LibRaw source is included in `vendor/LibRaw`.
  A static library is built from it with `TM_LIBRAW_SOURCE_DIR`.
- libjpeg-turbo, libpng and zlib: license notices in `licenses`.
- Compiler runtime: Zig 0.15.1, LLVM libc++/libc++abi and MinGW-w64 runtime.
  Runtime notices are included in `licenses`.

The Windows executable links these image libraries statically.
System Windows libraries are provided by Windows.
