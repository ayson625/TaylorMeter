/* Small standards-compliant OOXML writer, entirely C. ZIP method 0 (stored)
   keeps this application independent of Python, Excel, zlib and libxlsxwriter. */
#include "tm.h"
#define T(ru, en) tm_text(ru, en)
#include <math.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *p;
    size_t n, cap;
    int failed;
} Buffer;
static void reserve(Buffer *b, size_t add) {
    if (b->failed)
        return;
    if (add > SIZE_MAX - b->n - 1) {
        b->failed = 1;
        return;
    }
    size_t need = b->n + add + 1;
    if (need <= b->cap)
        return;
    size_t cap = b->cap ? b->cap : 1024;
    while (cap < need) {
        if (cap > SIZE_MAX / 2) {
            b->failed = 1;
            return;
        }
        cap *= 2;
    }
    char *p = (char *)realloc(b->p, cap);
    if (!p) {
        b->failed = 1;
        return;
    }
    b->p = p;
    b->cap = cap;
}
static void append(Buffer *b, const char *s) {
    size_t n = strlen(s);
    reserve(b, n);
    if (!b->failed) {
        memcpy(b->p + b->n, s, n + 1);
        b->n += n;
    }
}
static void fmt(Buffer *b, const char *f, ...) {
    va_list a, c;
    va_start(a, f);
    va_copy(c, a);
    int n = vsnprintf(NULL, 0, f, c);
    va_end(c);
    if (n < 0)
        b->failed = 1;
    else {
        reserve(b, (size_t)n);
        if (!b->failed) {
            vsnprintf(b->p + b->n, b->cap - b->n, f, a);
            b->n += (size_t)n;
        }
    }
    va_end(a);
}
static void xml(Buffer *b, const char *s) {
    for (; *s; s++) {
        switch (*s) {
        case '&':
            append(b, "&amp;");
            break;
        case '<':
            append(b, "&lt;");
            break;
        case '>':
            append(b, "&gt;");
            break;
        case '"':
            append(b, "&quot;");
            break;
        case '\'':
            append(b, "&apos;");
            break;
        default:
            if ((unsigned char)*s >= 32 || *s == '\n' || *s == '\t') {
                char q[2] = {*s, 0};
                append(b, q);
            }
        }
    }
}
static void colname(int n, char *out) {
    char s[16];
    int k = 0;
    n++;
    while (n) {
        s[k++] = (char)('A' + (n - 1) % 26);
        n = (n - 1) / 26;
    }
    for (int i = 0; i < k; i++)
        out[i] = s[k - i - 1];
    out[k] = 0;
}
static void textcell(Buffer *b, int col, int row, int style, const char *s) {
    char c[16];
    colname(col, c);
    fmt(b, "<c r=\"%s%d\" s=\"%d\" t=\"inlineStr\"><is><t xml:space=\"preserve\">", c, row, style);
    xml(b, s);
    append(b, "</t></is></c>");
}
static void numbercell(Buffer *b, int col, int row, int style, double v) {
    char c[16];
    colname(col, c);
    fmt(b, "<c r=\"%s%d\" s=\"%d\"><v>%.15g</v></c>", c, row, style, v);
}
static void avgcell(Buffer *b, int col, int row, int n, double avg) {
    char c[16];
    colname(col, c);
    fmt(b, "<c r=\"%s%d\" s=\"4\"><f>AVERAGE(%s4:%s%d)</f><v>%.15g</v></c>", c, row, c, c, n + 3,
        avg);
}
static uint32_t crc32bytes(const unsigned char *s, size_t n) {
    uint32_t c = 0xffffffffu;
    for (size_t i = 0; i < n; i++) {
        c ^= s[i];
        for (int j = 0; j < 8; j++)
            c = (c >> 1) ^ (0xedb88320u & ((uint32_t)0 - (c & 1)));
    }
    return ~c;
}
static int u16(FILE *f, uint16_t v) {
    unsigned char a[2] = {(unsigned char)v, (unsigned char)(v >> 8)};
    return fwrite(a, 1, 2, f) == 2;
}
static int u32(FILE *f, uint32_t v) { return u16(f, (uint16_t)v) && u16(f, (uint16_t)(v >> 16)); }
typedef struct {
    const char *name;
    Buffer data;
    uint32_t offset, crc;
} Part;
static int zip(FILE *f, Part *p, int n) {
    for (int i = 0; i < n; i++) {
        size_t len = strlen(p[i].name);
        long off = ftell(f);
        if (off < 0 || p[i].data.failed || p[i].data.n > UINT32_MAX)
            return 0;
        p[i].offset = (uint32_t)off;
        p[i].crc = crc32bytes((const unsigned char *)p[i].data.p, p[i].data.n);
        if (!u32(f, 0x04034b50) || !u16(f, 20) || !u16(f, 0) || !u16(f, 0) || !u16(f, 0) ||
            !u16(f, 0x5821) || !u32(f, p[i].crc) || !u32(f, (uint32_t)p[i].data.n) ||
            !u32(f, (uint32_t)p[i].data.n) || !u16(f, (uint16_t)len) || !u16(f, 0) ||
            fwrite(p[i].name, 1, len, f) != len ||
            fwrite(p[i].data.p, 1, p[i].data.n, f) != p[i].data.n)
            return 0;
    }
    long start = ftell(f);
    if (start < 0)
        return 0;
    for (int i = 0; i < n; i++) {
        size_t len = strlen(p[i].name);
        if (!u32(f, 0x02014b50) || !u16(f, 20) || !u16(f, 20) || !u16(f, 0) || !u16(f, 0) ||
            !u16(f, 0) || !u16(f, 0x5821) || !u32(f, p[i].crc) || !u32(f, (uint32_t)p[i].data.n) ||
            !u32(f, (uint32_t)p[i].data.n) || !u16(f, (uint16_t)len) || !u16(f, 0) || !u16(f, 0) ||
            !u16(f, 0) || !u16(f, 0) || !u32(f, 0) || !u32(f, p[i].offset) ||
            fwrite(p[i].name, 1, len, f) != len)
            return 0;
    }
    long end = ftell(f);
    if (end < 0)
        return 0;
    return u32(f, 0x06054b50) && u16(f, 0) && u16(f, 0) && u16(f, (uint16_t)n) &&
           u16(f, (uint16_t)n) && u32(f, (uint32_t)(end - start)) && u32(f, (uint32_t)start) &&
           u16(f, 0);
}
int tm_export_xlsx(const char *path, const TM_Photo *photos, int count, char *error, size_t cap) {
    int ids[TM_MAX_PHOTOS], n = 0, maxrows = 0;
    char tmp[TM_PATH] = {0}, reason[256];
    if (count < 0 || count > TM_MAX_PHOTOS)
        return 0;
    for (int i = 0; i < count; i++)
        if (photos[i].state.count && !photos[i].state.excluded) {
            if (!tm_validate(&photos[i].state, reason, sizeof(reason)) ||
                !photos[i].state.reviewed) {
                snprintf(error, cap, "Photo %d: %s", i + 1,
                         photos[i].state.reviewed ? reason
                                                  : "Review boundaries and scale before export.");
                return 0;
            }
            ids[n++] = i;
            if (photos[i].state.count > maxrows)
                maxrows = photos[i].state.count;
        }
    if (!n) {
        snprintf(error, cap, "No reviewed measurements to export.");
        return 0;
    }
    Part p[7] = {0};
    p[0].name = "[Content_Types].xml";
    p[1].name = "_rels/.rels";
    p[2].name = "xl/workbook.xml";
    p[3].name = "xl/_rels/workbook.xml.rels";
    p[4].name = "xl/styles.xml";
    p[5].name = "xl/worksheets/sheet1.xml";
    p[6].name = "xl/worksheets/sheet2.xml";
    append(
        &p[0].data,
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types "
        "xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default "
        "Extension=\"rels\" "
        "ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default "
        "Extension=\"xml\" ContentType=\"application/xml\"/><Override "
        "PartName=\"/xl/workbook.xml\" "
        "ContentType=\"application/"
        "vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override "
        "PartName=\"/xl/styles.xml\" "
        "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/"
        "><Override PartName=\"/xl/worksheets/sheet1.xml\" "
        "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/"
        "><Override PartName=\"/xl/worksheets/sheet2.xml\" "
        "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/"
        "></Types>");
    append(&p[1].data, "<?xml version=\"1.0\"?><Relationships "
                       "xmlns=\"http://schemas.openxmlformats.org/package/2006/"
                       "relationships\"><Relationship Id=\"rId1\" "
                       "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
                       "officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
    fmt(&p[2].data,
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook "
        "xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
        "<sheets><sheet name=\"%s\" sheetId=\"1\" r:id=\"rId1\"/>"
        "<sheet name=\"%s\" sheetId=\"2\" r:id=\"rId2\"/></sheets>"
        "<calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>",
        T("Измерения", "Measurements"), T("Проверка", "Review"));
    append(&p[3].data, "<?xml version=\"1.0\"?><Relationships "
                       "xmlns=\"http://schemas.openxmlformats.org/package/2006/"
                       "relationships\"><Relationship Id=\"rId1\" "
                       "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
                       "worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" "
                       "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
                       "worksheet\" Target=\"worksheets/sheet2.xml\"/><Relationship Id=\"rId3\" "
                       "Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
                       "styles\" Target=\"styles.xml\"/></Relationships>");
    append(&p[4].data,
        "<?xml version=\"1.0\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
        "<numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"0.000000\"/></numFmts>"
        "<fonts count=\"3\"><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FF243746\"/></font><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FFFFFFFF\"/><b/></font><font><sz val=\"11\"/><name val=\"Calibri\"/><color rgb=\"FF243746\"/><b/></font></fonts>"
        "<fills count=\"10\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFFFFF\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFC6EFCE\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF304C60\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE4EEF4\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFF5E2E0\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDDECF8\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFEDF2F6\"/><bgColor indexed=\"64\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFE2EBDD\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"
        "<borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"2\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"11\">"
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\"/>"
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"5\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\"/>"
        "<xf numFmtId=\"164\" fontId=\"0\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\"/>"
        "<xf numFmtId=\"164\" fontId=\"2\" fillId=\"3\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\"/>"
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"8\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"4\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"5\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"6\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"7\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"9\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\" applyNumberFormat=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>"
        "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
    Buffer *b = &p[5].data;
    append(b,
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
        "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"3\" topLeftCell=\"A4\" activePane=\"bottomLeft\" state=\"frozen\"/>"
        "</sheetView></sheetViews><cols>");
    fmt(b, "<col min=\"1\" max=\"%d\" width=\"24\" customWidth=\"1\" style=\"0\"/></cols><sheetData>", n * 2);
    int groups = 0;
    for (int k = 0; k < n; k++)
        if (!k || !tm_flow_equal(&photos[ids[k-1]].state, &photos[ids[k]].state)) groups++;
    for (int row = 1; row <= maxrows + 5; row++) {
        fmt(b, "<row r=\"%d\"%s>", row, " ht=\"32\" customHeight=\"1\"");
        for (int k = 0; k < n; k++) {
            const TM_State *s = &photos[ids[k]].state;
            int col = k * 2;
            char title[TM_PATH + 64];
            if (row == 1) {
                int first = !k || !tm_flow_equal(&photos[ids[k-1]].state, s);
                title[0] = 0;
                if (first) {
                    if (s->flow_valid)
                        snprintf(title, sizeof(title), T("Расход %.12g - %.12g", "Flow %.12g - %.12g"), s->flow[0], s->flow[1]);
                    else snprintf(title, sizeof(title), "%s", T("Расход не указан", "Flow not set"));
                }
                textcell(b, col, row, 6, title);
                textcell(b, col+1, row, 6, "");
            } else if (row == 2) {
                snprintf(title, sizeof(title), T("Фото %s", "Photo %s"), tm_basename(photos[ids[k]].path));
                textcell(b, col, row, 7, title);
                textcell(b, col+1, row, 7, "");
            } else if (row == 3) {
                textcell(b, col, row, 8, T("Капля, мм", "Drop, mm"));
                textcell(b, col+1, row, 9, T("Слаг, мм", "Slug, mm"));
            } else if (row <= s->count + 3) {
                int i = row - 4;
                numbercell(b, col, row, 2, tm_bubble_mm(s, i));
                if (i + 1 < s->count) numbercell(b, col+1, row, 2, tm_slug_mm(s, i));
                else textcell(b, col+1, row, 0, "");
            } else if (row == s->count + 4) {
                textcell(b, col, row, 10, T("Среднее арифметическое", "Arithmetic mean"));
                textcell(b, col+1, row, 10, T("Среднее арифметическое", "Arithmetic mean"));
            } else if (row == s->count + 5) {
                double sum = 0;
                for (int i = 0; i < s->count; i++) sum += tm_bubble_mm(s, i);
                avgcell(b, col, row, s->count, sum / s->count);
                if (s->count > 1) {
                    sum = 0;
                    for (int i = 0; i+1 < s->count; i++) sum += tm_slug_mm(s, i);
                    avgcell(b, col+1, row, s->count-1, sum / (s->count-1));
                } else textcell(b, col+1, row, 0, "");
            } else {
                textcell(b, col, row, 0, "");
                textcell(b, col+1, row, 0, "");
            }
        }
        append(b, "</row>");
    }
    fmt(b, "</sheetData><mergeCells count=\"%d\">", n + groups);
    for (int k = 0; k < n; k++) {
        char a[16], c[16];
        colname(k*2, a); colname(k*2+1, c);
        fmt(b, "<mergeCell ref=\"%s2:%s2\"/>", a, c);
        if (!k || !tm_flow_equal(&photos[ids[k-1]].state, &photos[ids[k]].state)) {
            int last = k;
            while (last+1 < n && tm_flow_equal(&photos[ids[k]].state, &photos[ids[last+1]].state)) last++;
            colname(last*2+1, c);
            fmt(b, "<mergeCell ref=\"%s1:%s1\"/>", a, c);
        }
    }
    append(b, "</mergeCells></worksheet>");
    b = &p[6].data;
    append(b, "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet "
              "xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols><col "
              "min=\"1\" max=\"1\" width=\"120\" customWidth=\"1\"/></cols><sheetData>");
    int row = 1;
    fmt(b, "<row r=\"%d\">", row);
    textcell(b, 0, row++, 6, T("TaylorMeter — проверка измерений", "TaylorMeter — measurement review"));
    append(b, "</row>");
    for (int k = 0; k < n; k++) {
        const TM_State *s = &photos[ids[k]].state;
        char info[TM_PATH + 300];
        snprintf(info, sizeof(info),
                 T("Фото %d: %s; капель: %d; слагов: %d; калибровка: %s; масштаб: %.9g мм/пиксель; проверено пользователем.",
                   "Photo %d: %s; drops: %d; slugs: %d; calibration: %s; scale: %.9g mm/pixel; reviewed by user."),
                 ids[k] + 1, photos[ids[k]].path, s->count, s->count - 1,
                 s->calibration.manual ? T("ручная", "manual") : T("автоматическая", "automatic"), s->calibration.mm_per_px);
        fmt(b, "<row r=\"%d\" ht=\"54\" customHeight=\"1\">", row);
        textcell(b, 0, row++, 5, info);
        append(b, "</row>");
        for (int i = 0; i < s->count; i++)
            if ((s->bubbles[i].flags & (TM_UNCERTAIN | TM_PARTIAL)) ||
                (i + 1 < s->count && tm_slug_mm(s, i) <= s->calibration.mm_per_px)) {
                snprintf(
                    info, sizeof(info), T("Фото %d, капля %d: %s%s%s", "Photo %d, drop %d: %s%s%s"), ids[k] + 1, i + 1,
                    (s->bubbles[i].flags & TM_UNCERTAIN) ? T("Автоматические торцы требуют проверки. ", "Automatic boundaries need review. ")
                                                         : "",
                    (s->bubbles[i].flags & TM_PARTIAL) ? T("Неполная капля: длина видимой части. ", "Partial drop: visible length only. ")
                                                       : "",
                    (i + 1 < s->count && tm_slug_mm(s, i) <= s->calibration.mm_per_px)
                        ? T("Слаг не больше одного пикселя; число сохранено, но разрешение снимка ограничивает точность. Нулевая оценка при неразличимых торцах не доказывает отсутствие жидкой прослойки.",
                            "Gap no larger than one pixel; its value is retained, but image resolution limits accuracy. A zero estimate with unresolved caps does not prove absence of liquid.")
                        : "");
                fmt(b, "<row r=\"%d\" ht=\"54\" customHeight=\"1\">", row);
                textcell(b, 0, row++, 5, info);
                append(b, "</row>");
            }
    }
    fmt(b, "<row r=\"%d\" ht=\"72\" customHeight=\"1\">", row);
    textcell(b, 0, row, 5,
             T("Масштаб предполагает, что линейка и канал находятся в одной плоскости. Промежуток с невидимыми пузырьками внутри нельзя считать одним физическим слагом: уточните границы вручную или выберите видимый участок.",
               "Calibration assumes ruler and channel share a plane. A gap containing hidden drops is not one physical slug: correct the boundaries or select a visible section."));
    append(b, "</row></sheetData></worksheet>");
    int ok = 1;
    for (int i = 0; i < 7; i++)
        if (p[i].data.failed)
            ok = 0;
    if (snprintf(tmp, sizeof(tmp), "%s.tmp", path) >= (int)sizeof(tmp))
        ok = 0;
    if (ok) {
        FILE *f = tm_fopen(tmp, "wb");
        if (!f)
            ok = 0;
        else {
            ok = zip(f, p, 7);
            if (fclose(f))
                ok = 0;
        }
    }
    if (ok)
        ok = tm_replace_file(tmp, path);
    if (!ok) {
        if (tmp[0])
            tm_remove_file(tmp);
        snprintf(error, cap, "Cannot save XLSX. Close Excel and check the destination.");
    }
    for (int i = 0; i < 7; i++)
        free(p[i].data.p);
    return ok;
}
