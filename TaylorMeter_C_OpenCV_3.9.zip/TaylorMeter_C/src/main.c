#include "cv_bridge.h"
#include "overlay.h"
#include "recognition.h"
#include "tm.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#endif

static int headless(int argc, char **argv) {
    TM_Photo *p = (TM_Photo *)calloc(1, sizeof(TM_Photo));
    if (!p)
        return 1;
    const char *xlsx = NULL, *png = NULL, *project = NULL, *manual = NULL;
    int ruler[4] = {0}, has_ruler = 0, reviewed = 0, automatic = 0;
    TM_Rect rectangle = {0};
    p->state.sensitivity = 50;
    p->state.min_length_px = 3;
    if (argc < 3) {
        free(p);
        return 2;
    }
    snprintf(p->path, TM_PATH, "%s", argv[2]);
    for (int i = 3; i < argc; i++) {
        if (!strcmp(argv[i], "--channel") && i + 1 < argc) {
            double ax, ay, bx, by, hw;
            if (sscanf(argv[++i], "%lf,%lf,%lf,%lf,%lf", &ax, &ay, &bx, &by, &hw) != 5 || hw < 2) {
                fprintf(stderr, "Invalid --channel\n");
                free(p);
                return 2;
            }
            p->state.channel = (TM_Channel){{ax, ay}, {bx, by}, hw, 1};
        } else if (!strcmp(argv[i], "--auto-channel")) {
            automatic = 1;
        } else if (!strcmp(argv[i], "--rect") && i + 1 < argc) {
            if (sscanf(argv[++i], "%d,%d,%d,%d", &rectangle.x, &rectangle.y, &rectangle.w,
                       &rectangle.h) != 4) {
                free(p);
                return 2;
            }
            rectangle.valid = 1;
        } else if (!strcmp(argv[i], "--px-per-mm") && i + 1 < argc) {
            double k = strtod(argv[++i], NULL);
            if (!isfinite(k) || k <= 0) {
                free(p);
                return 2;
            }
            p->state.calibration.valid = 1;
            p->state.calibration.manual = 1;
            p->state.calibration.mm_per_px = 1 / k;
        } else if (!strcmp(argv[i], "--ruler") && i + 1 < argc) {
            has_ruler =
                sscanf(argv[++i], "%d,%d,%d,%d", ruler, ruler + 1, ruler + 2, ruler + 3) == 4;
        } else if (!strcmp(argv[i], "--bubbles") && i + 1 < argc)
            manual = argv[++i];
        else if (!strcmp(argv[i], "--xlsx") && i + 1 < argc)
            xlsx = argv[++i];
        else if (!strcmp(argv[i], "--png") && i + 1 < argc)
            png = argv[++i];
        else if (!strcmp(argv[i], "--project") && i + 1 < argc)
            project = argv[++i];
        else if (!strcmp(argv[i], "--reviewed"))
            reviewed = 1;
        else if (!strcmp(argv[i], "--sensitivity") && i + 1 < argc)
            p->state.sensitivity = strtod(argv[++i], NULL);
        else {
            fprintf(stderr, "Unknown or incomplete option: %s\n", argv[i]);
            free(p);
            return 2;
        }
    }
    if (p->state.sensitivity < 0 || p->state.sensitivity > 100) {
        free(p);
        return 2;
    }
    p->image = cvb_load(p->path, &p->width, &p->height);
    if (!p->image) {
        fprintf(stderr, "%s\n", cvb_error());
        free(p);
        return 1;
    }
    if (rectangle.valid && !tm_set_channel_rect(&p->state, rectangle, p->width, p->height)) {
        fprintf(stderr, "Invalid --rect.\n");
        cvb_free(p->image);
        free(p);
        return 2;
    }
    if (automatic && !p->state.channel.valid &&
        !tm_image_channel(p->image, NULL, &p->state.channel, &p->state.region)) {
        fprintf(stderr, "No reliable automatic channel. Use --rect or --channel.\n");
        cvb_free(p->image);
        free(p);
        return 1;
    }
    double len = tm_channel_length(&p->state.channel);
    if (!p->state.channel.valid || !isfinite(len) || len < 10) {
        fprintf(stderr, "Use --auto-channel, --rect or --channel.\n");
        cvb_free(p->image);
        free(p);
        return 2;
    }
    p->state.calibration.axis_x = (p->state.channel.b.x - p->state.channel.a.x) / len;
    p->state.calibration.axis_y = (p->state.channel.b.y - p->state.channel.a.y) / len;
    printf("Channel: %.2f,%.2f to %.2f,%.2f; half width %.2f; region %d,%d,%d,%d\n",
           p->state.channel.a.x, p->state.channel.a.y, p->state.channel.b.x, p->state.channel.b.y,
           p->state.channel.half_width, p->state.region.x, p->state.region.y, p->state.region.w,
           p->state.region.h);
    printf("Source: %d x %d pixels\n", p->width, p->height);
    int sw, sh, stride;
    p->strip = cvb_strip(p->image, &p->state.channel, &sw, &sh);
    if (!p->strip) {
        fprintf(stderr, "%s\n", cvb_error());
        cvb_free(p->image);
        free(p);
        return 1;
    }
    if (has_ruler) {
        double origin;
        void *a = cvb_ruler_roi(p->image, &p->state.channel, ruler[0], ruler[1], ruler[2], ruler[3],
                                &origin);
        if (a) {
            int w, h, st;
            const uint8_t *g = cvb_gray(a, &w, &h, &st);
            tm_find_ruler(g, w, h, st, origin, &p->state.calibration);
            cvb_free(a);
        }
    }
    if (manual) {
        const char *q = manual;
        while (*q) {
            double l, r;
            int n = 0;
            if (sscanf(q, "%lf:%lf%n", &l, &r, &n) != 2 || n <= 0 ||
                tm_add_bubble(&p->state, l, r, TM_MANUAL, 1) < 0) {
                fprintf(stderr, "Invalid/overlapping --bubbles\n");
                cvb_free(p->strip);
                cvb_free(p->image);
                free(p);
                return 2;
            }
            q += n;
            if (*q == ';')
                q++;
            else if (*q) {
                fprintf(stderr, "Use left:right;left:right\n");
                cvb_free(p->strip);
                cvb_free(p->image);
                free(p);
                return 2;
            }
        }
    } else {
        const uint8_t *g = cvb_gray(p->strip, &sw, &sh, &stride);
        TM_RecognitionReport report;
        if (tm_detect_checked(g, sw, sh, stride, &p->state, &report) < 0) {
            fprintf(stderr, "Detection failed.\n");
            cvb_free(p->strip);
            cvb_free(p->image);
            free(p);
            return 1;
        }
        printf("Self-check: %d runs; counts %d..%d; unstable %d; agreement %.3f "
               "(repeatability, not accuracy)\n",
               report.runs, report.min_count, report.max_count, report.unstable, report.agreement);
    }
    p->state.reviewed = reviewed;
    printf("Bubbles: %d; slugs: %d; scale: %.9g mm/px; calibration: %s\n", p->state.count,
           p->state.count ? p->state.count - 1 : 0, p->state.calibration.mm_per_px,
           p->state.calibration.valid ? "ok" : "missing");
    printf("index,left_px,right_px,bubble_mm,slug_after_mm,confidence\n");
    for (int i = 0; i < p->state.count; i++) {
        printf("%d,%.4f,%.4f,%.6f,", i + 1, p->state.bubbles[i].left, p->state.bubbles[i].right,
               tm_bubble_mm(&p->state, i));
        if (i + 1 < p->state.count)
            printf("%.6f", tm_slug_mm(&p->state, i));
        printf(",%.3f\n", p->state.bubbles[i].confidence);
    }
    int ok = 1;
    char error[512];
    if (png) {
        void *out = cvb_clone(p->image);
        TM_Overlay layout;
        tm_overlay_init(&layout, &p->state.channel, 0);
        tm_overlay_draw(out, &p->state, &layout, 1);
        ok = cvb_save(out, png);
        cvb_free(out);
    }
    if (project && ok)
        ok = tm_save_project(project, p, 1);
    if (xlsx && ok) {
        ok = tm_export_xlsx(xlsx, p, 1, error, sizeof(error));
        if (!ok)
            fprintf(stderr, "%s\n", error);
    }
    cvb_free(p->strip);
    cvb_free(p->image);
    free(p);
    return ok ? 0 : 1;
}
static int entry(int argc, char **argv) {
    tm_platform_init();
    if (argc > 1 && !strcmp(argv[1], "--help")) {
        puts("TaylorMeter 3.9\nGUI: TaylorMeter [photo.jpg ...] or TaylorMeter "
             "session.tmc\nHeadless: TaylorMeter --headless image --channel "
             "ax,ay,bx,by,half_width (or --auto-channel / --rect x,y,w,h)\n  [--px-per-mm N | "
             "--ruler x,y,w,h] [--bubbles "
             "\"l:r;l:r\"]\n  [--sensitivity 0..100] [--reviewed] [--xlsx result.xlsx]\n  [--png "
             "result.png] [--project result.tmc]\nCoordinates refer to original resolution. Bubble "
             "coordinates run along the selected channel.");
        return 0;
    }
    if (argc > 1 && !strcmp(argv[1], "--headless"))
        return headless(argc, argv);
    return tm_run_gui(argc, argv);
}
#ifdef _WIN32
static wchar_t startup_log[TM_PATH];
static int gui_launch;
static void startup_message(const wchar_t *message) {
    wchar_t text[TM_PATH + 512];
    swprintf(text, TM_PATH + 512,
             L"%ls\n\nLog / Журнал:\n%ls", message,
             startup_log[0] ? startup_log : L"Could not create log / Не удалось создать журнал");
    MessageBoxW(NULL, text, L"TaylorMeter", MB_OK | MB_ICONERROR);
}
static LONG WINAPI startup_exception(EXCEPTION_POINTERS *exception) {
    fprintf(stderr, "Unhandled Windows exception: 0x%08lX at %p\n",
            (unsigned long)exception->ExceptionRecord->ExceptionCode,
            exception->ExceptionRecord->ExceptionAddress);
    fflush(stderr);
    if (gui_launch) startup_message(L"TaylorMeter stopped unexpectedly. / TaylorMeter аварийно завершён.");
    return EXCEPTION_EXECUTE_HANDLER;
}
static void open_startup_log(void) {
    char directory[TM_PATH], path[TM_PATH];
    FILE *log = NULL;
    if (tm_photo_directory(directory, sizeof(directory)) &&
        snprintf(path, sizeof(path), "%s/TaylorMeter_startup.log", directory) < (int)sizeof(path) &&
        MultiByteToWideChar(CP_UTF8, 0, path, -1, startup_log, TM_PATH))
        log = _wfreopen(startup_log, L"w", stderr);
    if (!log) {
        DWORD n = GetTempPathW(TM_PATH, startup_log);
        if (n && n + 28 < TM_PATH) {
            wcscat(startup_log, L"TaylorMeter_startup.log");
            log = _wfreopen(startup_log, L"w", stderr);
        }
    }
    if (!log) startup_log[0] = 0;
    else setvbuf(stderr, NULL, _IONBF, 0);
    fprintf(stderr, "TaylorMeter %s Windows x64: starting GUI\n", TM_VERSION);
}
static int windows_entry(int argc, wchar_t **wargv) {
    gui_launch = !(argc > 1 && (!wcscmp(wargv[1], L"--headless") || !wcscmp(wargv[1], L"--help")));
    if (gui_launch) {
        open_startup_log();
        SetUnhandledExceptionFilter(startup_exception);
    } else if (!GetConsoleWindow() && AttachConsole(ATTACH_PARENT_PROCESS)) {
        /* Keep redirected output handles used by scripts and test runners. */
        HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
        if (output && output != INVALID_HANDLE_VALUE && GetFileType(output) == FILE_TYPE_CHAR)
            freopen("CONOUT$", "w", stdout);
        HANDLE error = GetStdHandle(STD_ERROR_HANDLE);
        if (error && error != INVALID_HANDLE_VALUE && GetFileType(error) == FILE_TYPE_CHAR)
            freopen("CONOUT$", "w", stderr);
    }
    char **argv = (char **)calloc((size_t)argc + 1, sizeof(char *));
    if (!argv)
        return 1;
    int rc = 1;
    for (int i = 0; i < argc; i++) {
        int n = WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1, NULL, 0, NULL, NULL);
        argv[i] = (char *)malloc((size_t)n);
        if (!n || !argv[i] || !WideCharToMultiByte(CP_UTF8, 0, wargv[i], -1, argv[i], n, NULL, NULL))
            goto done;
    }
    rc = entry(argc, argv);
done:
    for (int i = 0; i < argc; i++)
        free(argv[i]);
    free(argv);
    if (gui_launch) {
        fprintf(stderr, "Exit code: %d\n", rc);
        if (rc) startup_message(L"Unable to start TaylorMeter. / Не удалось запустить TaylorMeter.");
    }
    return rc;
}
int WINAPI wWinMain(HINSTANCE instance, HINSTANCE previous, PWSTR command, int show) {
    (void)instance; (void)previous; (void)command; (void)show;
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv) { startup_message(L"Cannot read command line. / Ошибка чтения командной строки."); return 1; }
    int rc = windows_entry(argc, argv);
    LocalFree(argv);
    return rc;
}
#else
int main(int argc, char **argv) { return entry(argc, argv); }
#endif
