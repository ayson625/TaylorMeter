#include "cv_bridge.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL %d: %s\n", __LINE__, #x);                                        \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)
static void capsules(void *image, TM_Channel ch, int count) {
    double length = tm_channel_length(&ch);
    for (int side = -1; side <= 1; side += 2) {
        TM_Point a = tm_channel_point(&ch, 0, side * ch.half_width),
                 b = tm_channel_point(&ch, length, side * ch.half_width);
        cvb_line(image, a.x, a.y, b.x, b.y, 0x252525, 2);
    }
    for (int i = 0; i < count; i++) {
        double left = 30 + i * 120, right = left + 80;
        for (int side = 0; side < 2; side++) {
            TM_Point previous = {0};
            for (int y = -15; y <= 15; y++) {
                double offset = 15 * (1 - sqrt(fmax(0, 1 - y * y / 225.0)));
                TM_Point p = tm_channel_point(&ch, side ? right - offset : left + offset, y);
                if (y > -15)
                    cvb_line(image, previous.x, previous.y, p.x, p.y, 0x252525, 2);
                previous = p;
            }
        }
        for (int side = -1; side <= 1; side += 2) {
            TM_Point a = tm_channel_point(&ch, left + 15, side * 15),
                     b = tm_channel_point(&ch, right - 15, side * 15);
            cvb_line(image, a.x, a.y, b.x, b.y, 0x252525, 2);
        }
    }
}
int main(int argc, char **argv) {
    CHECK(argc >= 3);
    int w, h;
    void *image = cvb_load(argv[1], &w, &h);
    CHECK(image);
    TM_Channel channel = {0};
    TM_Rect region = {0};
    CHECK(tm_image_channel(image, NULL, &channel, &region));
    CHECK(region.automatic && region.y >= 165 && region.y + region.h <= 235);
    CHECK(channel.half_width > 10);
    /* Add a strong dark bar; keep the ruler with its many strokes and numbers. */
    cvb_rect(image, 10, 10, w - 20, 100, 0x151515, -1);
    CHECK(tm_image_channel(image, NULL, &channel, &region));
    CHECK(region.y >= 165 && region.y + region.h <= 235);
    cvb_free(image);
    image = cvb_create(900, 600, 0xd0d0d0);
    CHECK(image);
    cvb_rect(image, 10, 25, 880, 100, 0x151515, -1);
    TM_Channel known = {{40, 240}, {860, 270}, 18, 1};
    capsules(image, known, 6);
    CHECK(tm_image_channel(image, NULL, &channel, &region));
    CHECK(region.y > 200 && region.y + region.h < 315);
    CHECK(fabs((channel.a.y + channel.b.y) * .5 - 255) < 15);
    CHECK(fabs((channel.b.y - channel.a.y) / (channel.b.x - channel.a.x) - 30.0 / 820) < .02);
    cvb_free(image);
    image = cvb_create(900, 600, 0xb0b0b0);
    CHECK(image && !tm_image_channel(image, NULL, &channel, &region));
    cvb_free(image);
    TM_State *s = (TM_State *)calloc(1, sizeof(TM_State));
    CHECK(s);
    CHECK(tm_set_channel_rect(s, (TM_Rect){-10, 10, 300, 30, 1, 0}, 900, 500));
    CHECK(s->region.x == 0 && s->region.w == 290 && s->channel.a.y == 24.5);
    CHECK(!tm_set_channel_rect(s, (TM_Rect){10, 10, 1, 1, 1, 0}, 900, 500));
    CHECK(tm_set_channel_rect(s, (TM_Rect){200, 20, 21, 420, 1, 0}, 900, 500));
    CHECK(s->channel.a.x == s->channel.b.x && s->channel.a.y < s->channel.b.y);
    free(s);
    TM_Photo *old = (TM_Photo *)calloc(1, sizeof(TM_Photo));
    char error[256];
    CHECK(old && tm_load_project(argv[2], old, 1, error, sizeof(error)) == 1);
    CHECK(old[0].state.count == 5 && old[0].state.region.valid);
    free(old);
    puts("automatic channel, dark bars, ruler rejection, tilted channel, rectangle geometry and "
         "TMC3 import: PASS");
    return 0;
}
