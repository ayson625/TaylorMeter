#ifndef TM_SPLASH_H
#define TM_SPLASH_H
#define TM_SPLASH_DURATION_MS 2000
/* Animation rendering is shared by the application and preview generator. */
typedef struct TM_Splash TM_Splash;
TM_Splash *tm_splash_create(void);
void *tm_splash_frame(TM_Splash *splash, double elapsed_ms);
void tm_splash_free(TM_Splash *splash);
#endif
