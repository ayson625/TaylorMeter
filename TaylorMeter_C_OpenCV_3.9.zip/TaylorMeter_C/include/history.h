#ifndef TM_HISTORY_H
#define TM_HISTORY_H
#include "tm.h"

typedef struct {
    int photo_index;
    TM_State state;
} TM_HistoryEntry;
typedef struct {
    TM_HistoryEntry *entries;
    TM_State *swap;
    int capacity, count, cursor;
} TM_History;

int tm_history_init(TM_History *history, int capacity);
void tm_history_clear(TM_History *history);
void tm_history_free(TM_History *history);
/* Record one complete edit. No-op edits preserve the redo branch. */
void tm_history_record(TM_History *history, int photo_index, const TM_State *before,
                       const TM_State *after);
int tm_history_undo(TM_History *history, TM_Photo *photos, int count, int *photo_index);
int tm_history_redo(TM_History *history, TM_Photo *photos, int count, int *photo_index);
#endif
