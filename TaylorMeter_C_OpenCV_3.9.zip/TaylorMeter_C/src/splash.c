#include "splash.h"
#include "cv_bridge.h"
#include <math.h>
#include <stdlib.h>

extern const unsigned char tm_logo_png[];
extern const size_t tm_logo_png_size;
struct TM_Splash {
    void *background, *plain, *logo;
    int title_width;
};
static double unit(double t) { return t < 0 ? 0 : (t > 1 ? 1 : t); }
static double smooth(double t) { t = unit(t); return t * t * (3 - 2 * t); }
static double ease_out(double t) { t = 1 - unit(t); return 1 - t*t*t; }
static int fade_color(int color, double amount) {
    int result = 0, background = 0x131a25;
    for (int shift = 0; shift <= 16; shift += 8) {
        double a = (background >> shift) & 255, b = (color >> shift) & 255;
        result |= (int)lround(a + (b-a)*unit(amount)) << shift;
    }
    return result;
}
TM_Splash *tm_splash_create(void) {
    TM_Splash *s = calloc(1, sizeof(*s));
    if (!s) return NULL;
    s->background = cvb_create(1280, 800, 0x131a25);
    s->plain = cvb_create(1280, 800, 0x131a25);
    s->logo = cvb_decode_rgba(tm_logo_png, tm_logo_png_size);
    s->title_width = cvb_text_width("TaylorMeter", 58);
    if (!s->background || !s->plain || !s->logo) { tm_splash_free(s); return NULL; }
    cvb_radial_glow(s->background, 640, 300, 235, 0x37516a, 0.42);
    return s;
}
void *tm_splash_frame(TM_Splash *s, double ms) {
    if (!s || !isfinite(ms)) return NULL;
    double appear = smooth(ms / 650), move = ease_out(ms / 850);
    double title = smooth((ms - 260) / 650);
    double leave = smooth((ms - 1740) / 260);
    void *frame = cvb_clone(s->plain);
    if (!frame) return NULL;
    cvb_composite(frame, s->background, 0, 0, 1280, 800, appear);
    int size = (int)lround(238 + 22*move);
    int center_y = 306 + (int)lround(16*(1-move));
    cvb_composite(frame, s->logo, 640-size/2, center_y-size/2, size, size, appear);
    cvb_text(frame, 640-s->title_width/2, 508+(int)lround(12*(1-title)),
             "TaylorMeter", 58, fade_color(0xf3f6fa, title));
    /* A travelling highlight, not a percentage or a claim about loading progress. */
    double line = smooth((ms - 540) / 500);
    cvb_line(frame, 550, 550, 730, 550, fade_color(0x314458, line), 1);
    double position = unit((ms - 600) / 1040);
    double pulse = sin(3.141592653589793 * position) * line;
    double head = 560 + 160*position;
    for (int i = 18; i >= 0; i--)
        cvb_line(frame, head-i, 550, head-i+1, 550,
                 fade_color(0x9dd4ed, pulse*(1.0-i/20.0)), 2);
    cvb_composite(frame, s->plain, 0, 0, 1280, 800, leave);
    return frame;
}
void tm_splash_free(TM_Splash *s) {
    if (!s) return;
    cvb_free(s->background); cvb_free(s->plain); cvb_free(s->logo); free(s);
}
