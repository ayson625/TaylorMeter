# TaylorMeter 3.9

A two-second startup animation introduces the app icon and TaylorMeter name.
Press a key or click to skip directly to language selection. Windows animation
preferences are respected; headless processing has no splash screen.
The logo is embedded in the executable, so shortcuts need no external assets.

Extract the whole ZIP and run TaylorMeter.exe or start_windows.cmd. Choose English
or Russian at startup. create_shortcut.cmd creates a desktop shortcut with the app icon.

Open a photo, enter the two flow values, inspect the channel and calibration, and
correct the drop boundaries. Mark the measurements reviewed before exporting.
New photos inherit the most recently applied flow values. The flow button at the
bottom right edits the current photo and the default for future photos; earlier
photos keep their values. Flow units are user-defined and must be consistent.

Close photo excludes the current photo from viewing and export. Ctrl+Z restores it,
including its measurements; Ctrl+Y repeats closing. Source image files are never deleted.
Closed records remain in the project and count toward the 128-record limit.

Save Excel + images writes spreadsheets to saves/excel and all other export files
to a matching timestamped folder in saves/photo beside the executable. Image output
names preserve the original shot number. Adjacent photos sharing a flow pair are
grouped in the top Excel row. Flow headers use dark blue-gray, photo headers light
blue-gray, drop headers pale pink and slug headers pale blue. Numerical data stay
white and arithmetic mean formulas green.

TaylorMeter.exe now uses the Windows GUI entry point and opens without a console.
On a startup error, check saves/photo/TaylorMeter_startup.log. If the window never
appears, run diagnose_windows.cmd and send its TaylorMeter_launch.txt report.
Read-only folders use %TEMP% for the startup log. Windows 10/11 x64 is the binary target.
Actual Windows GUI execution was not available in the build environment.

Open older TMC3/TMC4 projects directly. TMC5 stores flow and excluded-photo state and
requires TaylorMeter 3.7 or newer. Keep original photos with the project or in its
originals subfolder when moving it. Old projects have no flow value until you set one.

The detection algorithm remains that of 3.6. Saving images does not train a neural
network. Fit to reviewed boundaries adjusts sensitivity using a checked example.
