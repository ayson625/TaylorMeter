#include "recognition.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(x)                                                                                   \
    do {                                                                                           \
        if (!(x)) {                                                                                \
            fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #x);                                   \
            return 1;                                                                              \
        }                                                                                          \
    } while (0)

static const double lefts[] = {30, 94, 160, 270, 370, 475};
static const double rights[] = {90, 155, 225, 340, 455, 570};

static void capsules(uint8_t *gray, int w, int h, int stride) {
    memset(gray, 180, (size_t)stride * h);
    for (int i = 0; i < 6; i++)
        for (int y = 4; y < h - 4; y++) {
            double t = (y - (h - 1) * .5) / 12;
            if (fabs(t) > 1)
                continue;
            double dx = 12 * (1 - sqrt(1 - t * t));
            for (int x = 0; x < w; x++) {
                double l = lefts[i] + dx, r = rights[i] - dx;
                if (x >= l && x <= r)
                    gray[y * stride + x] = 210;
                if (fabs(x - l) < 1 || fabs(x - r) < 1)
                    gray[y * stride + x] = 50;
            }
        }
}

static void wide_capsules(uint8_t *gray, int w, int h) {
    const double left[] = {40, 400, 780}, right[] = {300, 680, 1100};
    memset(gray, 180, (size_t)w * h);
    for (int i = 0; i < 3; i++)
        for (int y = 0; y < h; y++) {
            double t = (y - (h - 1) * .5) / 82;
            if (fabs(t) > 1)
                continue;
            double dx = 82 * (1 - sqrt(1 - t * t));
            for (int x = 0; x < w; x++) {
                double l = left[i] + dx, r = right[i] - dx;
                if (x >= l && x <= r)
                    gray[y * w + x] = 210;
                if (fabs(x - l) < 1 || fabs(x - r) < 1)
                    gray[y * w + x] = 50;
            }
        }
}

int main(void) {
    const int w = 700, h = 33, stride = 707;
    uint8_t *gray = (uint8_t *)malloc((size_t)stride * h);
    uint8_t *pixels_before = (uint8_t *)malloc((size_t)stride * h);
    TM_State *s = (TM_State *)calloc(1, sizeof(TM_State));
    TM_State *truth = (TM_State *)calloc(1, sizeof(TM_State));
    TM_State *before = (TM_State *)malloc(sizeof(TM_State));
    CHECK(gray && pixels_before && s && truth && before);
    capsules(gray, w, h, stride);
    memcpy(pixels_before, gray, (size_t)stride * h);
    s->channel = (TM_Channel){{0, 16}, {699, 16}, 16, 1};
    s->sensitivity = 50;
    s->min_length_px = 3;
    TM_RecognitionReport check;
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) == 6);
    CHECK(check.runs == 3 && check.min_count == 6 && check.max_count == 6);
    CHECK(check.agreement > .99 && check.unstable == 0 && !check.recovered);
    for (int i = 0; i < s->count; i++) {
        CHECK(fabs(s->bubbles[i].left - lefts[i]) < 3);
        CHECK(fabs(s->bubbles[i].right - rights[i]) < 3);
    }
    CHECK(s->bubbles[1].left > s->bubbles[0].right);
    CHECK(!memcmp(gray, pixels_before, (size_t)stride * h));
    *before = *s;
    CHECK(tm_detect_checked(NULL, w, h, stride, s, &check) == -1);
    CHECK(!memcmp(before, s, sizeof(TM_State)));
    CHECK(tm_detect_checked(gray, w, h, w - 1, s, &check) == -1);
    CHECK(!memcmp(before, s, sizeof(TM_State)));
    CHECK(tm_detect_checked(gray, w, h, stride, NULL, &check) == -1);
    s->sensitivity = 0;
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) >= 0 && check.runs == 2);
    s->sensitivity = 100;
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) >= 0 && check.runs == 2);

    truth->channel = (TM_Channel){{0, 16}, {1398, 16}, 16, 1};
    truth->sensitivity = 53;
    truth->min_length_px = 3;
    /* These labels are generated from known geometry, NOT detector output.
       Doubling source coordinates also verifies tolerance/metric units. */
    for (int i = 0; i < 6; i++)
        CHECK(tm_add_bubble(truth, 2 * lefts[i], 2 * rights[i], TM_MANUAL, 1) == i);
    truth->reviewed = 1;
    *before = *truth;
    TM_TrainingReport training;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 1);
    CHECK(training.trials == 12 && training.accepted);
    CHECK(training.matched == 6 && !training.missed && !training.extra);
    CHECK(training.mean_error_px < 6 && training.tolerance_px == 6);
    CHECK(training.sensitivity >= 0 && training.sensitivity <= 100);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    CHECK(!memcmp(gray, pixels_before, (size_t)stride * h));

    /* An incomplete reference cannot pass merely because all its labelled
       bubbles were found: the additional predictions count against precision. */
    truth->count = 3;
    *before = *truth;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 1);
    CHECK(!training.accepted && training.matched == 3 && training.extra == 3);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    truth->count = 6;

    /* A shape with the correct left endpoint but a wrong right endpoint must
       not pass. Labels are still structurally valid, so trials run and fail. */
    for (int i = 0; i < truth->count; i++)
        truth->bubbles[i].right -= 30;
    *before = *truth;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 1);
    CHECK(!training.accepted && training.matched == 0 && training.missed == 6);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    truth->reviewed = 0;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 0);
    truth->reviewed = 1;
    truth->count = 2;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 0);
    truth->count = 6;
    truth->bubbles[1].left = truth->bubbles[0].left;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 0);
    *truth = *before;
    truth->bubbles[0].right = NAN;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 0);

    /* A repeatable absence must stay empty. Fitting cannot hallucinate
       positive examples into a blank picture to agree with the labels. */
    memset(gray, 180, (size_t)stride * h);
    *truth = *before;
    CHECK(tm_tune_recognition(gray, w, h, stride, truth, &training) == 1);
    CHECK(!training.accepted && !training.matched && training.missed == 6 && !training.extra);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    s->sensitivity = 50;
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) == 0);
    CHECK(check.runs == 3 && !check.max_count && !check.recovered && !check.unstable);
    CHECK(isfinite(check.agreement) && check.agreement >= 0 && check.agreement <= 1);
    memset(gray, 0, (size_t)stride * h);
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) == 0 && !check.recovered);
    *before = *s;
    s->sensitivity = NAN;
    before->sensitivity = NAN;
    CHECK(tm_detect_checked(gray, w, h, stride, s, &check) == -1);
    CHECK(!memcmp(before, s, sizeof(TM_State)));

    /* A 220-pixel-tall ROI previously implied a 22-pixel matching tolerance.
       The same clear image must accept correct labels, but reject a 20-pixel
       endpoint error; mere agreement in object count cannot pass the fit. */
    uint8_t *wide = (uint8_t *)malloc(1200 * 220);
    CHECK(wide);
    wide_capsules(wide, 1200, 220);
    memset(truth, 0, sizeof(*truth));
    truth->channel = (TM_Channel){{0, 109.5}, {1199, 109.5}, 109.5, 1};
    truth->sensitivity = 50;
    truth->min_length_px = 3;
    CHECK(tm_add_bubble(truth, 40, 300, TM_MANUAL, 1) == 0);
    CHECK(tm_add_bubble(truth, 400, 680, TM_MANUAL, 1) == 1);
    CHECK(tm_add_bubble(truth, 780, 1100, TM_MANUAL, 1) == 2);
    truth->reviewed = 1;
    *before = *truth;
    CHECK(tm_tune_recognition(wide, 1200, 220, 1200, truth, &training) == 1);
    CHECK(training.accepted && training.trials == 11 && training.matched == 3);
    CHECK(training.tolerance_px == 6 && training.mean_error_px < 6);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    for (int i = 0; i < truth->count; i++)
        truth->bubbles[i].right -= 20;
    *before = *truth;
    CHECK(tm_tune_recognition(wide, 1200, 220, 1200, truth, &training) == 1);
    CHECK(!training.accepted && !training.matched && training.missed == 3);
    CHECK(training.tolerance_px == 6);
    CHECK(!memcmp(before, truth, sizeof(TM_State)));
    free(wide);
    free(before);
    free(truth);
    free(s);
    free(pixels_before);
    free(gray);
    puts("repeatability, source-pixel matching, reviewed-label fitting, bad labels and empty "
         "images: PASS");
    return 0;
}
