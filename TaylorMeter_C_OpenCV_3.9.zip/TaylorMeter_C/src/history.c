#include "history.h"
#include <stdlib.h>
#include <string.h>

int tm_history_init(TM_History *h, int capacity) {
    memset(h, 0, sizeof(*h));
    if (capacity < 1 || capacity > 1000)
        return 0;
    h->entries = (TM_HistoryEntry *)calloc((size_t)capacity, sizeof(TM_HistoryEntry));
    h->swap = (TM_State *)malloc(sizeof(TM_State));
    if (!h->entries || !h->swap) {
        tm_history_free(h);
        return 0;
    }
    h->capacity = capacity;
    return 1;
}
void tm_history_clear(TM_History *h) { h->count = h->cursor = 0; }
void tm_history_free(TM_History *h) {
    free(h->entries);
    free(h->swap);
    memset(h, 0, sizeof(*h));
}
void tm_history_record(TM_History *h, int index, const TM_State *before, const TM_State *after) {
    if (!h->entries || index < 0 || !memcmp(before, after, sizeof(*before)))
        return;
    h->count = h->cursor;
    if (h->count == h->capacity) {
        memmove(h->entries, h->entries + 1, (size_t)(h->count - 1) * sizeof(TM_HistoryEntry));
        h->count--;
    }
    TM_HistoryEntry *e = h->entries + h->count++;
    e->photo_index = index;
    e->state = *before;
    h->cursor = h->count;
}
static int exchange(TM_History *h, TM_Photo *photos, int count, int at, int *index) {
    TM_HistoryEntry *e = h->entries + at;
    if (e->photo_index < 0 || e->photo_index >= count)
        return 0;
    TM_State *s = &photos[e->photo_index].state;
    *h->swap = *s;
    *s = e->state;
    e->state = *h->swap;
    *index = e->photo_index;
    return 1;
}
int tm_history_undo(TM_History *h, TM_Photo *photos, int count, int *index) {
    if (!h->cursor || !exchange(h, photos, count, h->cursor - 1, index))
        return 0;
    h->cursor--;
    return 1;
}
int tm_history_redo(TM_History *h, TM_Photo *photos, int count, int *index) {
    if (h->cursor >= h->count || !exchange(h, photos, count, h->cursor, index))
        return 0;
    h->cursor++;
    return 1;
}
