@echo off
setlocal EnableExtensions DisableDelayedExpansion
pushd "%~dp0" >nul 2>&1
if errorlevel 1 goto folder_error
if not exist "%~dp0TaylorMeter.exe" goto missing_file
if not exist "%~dp0examples\demo.tmc" goto missing_file
"%~dp0TaylorMeter.exe" "examples\demo.tmc"
set "tm_demo_exit=%errorlevel%"
popd
if not "%tm_demo_exit%"=="0" goto launch_error
exit /b 0

:missing_file
echo ERROR: The program or demo project is missing.
echo Extract the entire ZIP archive into a folder before running the demo.
popd
pause
exit /b 1

:folder_error
echo ERROR: Unable to open the program folder.
pause
exit /b 1

:launch_error
echo ERROR: TaylorMeter exited with code %tm_demo_exit%.
pause
exit /b %tm_demo_exit%
